// Static content for FBSPL website
import { 
  ServiceCategory, 
  ClientLogo, 
  WhyChooseUsItem, 
  ServiceItem, 
  TestimonialItem,
  InsightItem
} from '../types';

export const SERVICES_MENU: ServiceCategory[] = [
  {
    title: "Insurance Outsourcing",
    items: [
      { name: "New Business Setup", description: "Expedite quote preparation and policy setup." },
      { name: "Policy Processing", description: "Comprehensive policy checking and renewals." },
      { name: "Claims Management", description: "Optimize dispatch and notification processing." },
      { name: "Insurance Accounting", description: "Commission reconciliations and premium accounting." },
      { name: "Agency Consultation", description: "Maximize operational workflows of retail agencies." },
      { name: "Insurance Customer Support", description: "Dual-shore expert tier customer care." },
      { name: "Employee Benefits Support", description: "Manage group accounts and enrollment lifecycles." }
    ]
  },
  {
    title: "Accounting & Bookkeeping",
    items: [
      { name: "Payable Management", description: "Invoice processing, approvals, and dynamic auditing." },
      { name: "Receivable Management", description: "Maximize collections and dispatch billing statements." },
      { name: "Financial Reporting", description: "P&L compilations, balance sheets, and custom analytics." },
      { name: "Payroll Processing", description: "Salary disbursements, tax withholdings, and reporting." },
      { name: "Reconciliation Services", description: "Accurate bank, credit, and general ledger matching." },
      { name: "General Ledger Accounting", description: "Month-end closures and adjustments." }
    ]
  },
  {
    title: "Data Annotation",
    items: [
      { name: "Text Annotation", description: "NLP tagging, entity translation, and intent mapping." },
      { name: "Video Annotation", description: "Dynamic bounding boxes and pixel-level tracking." },
      { name: "Image Annotation", description: "Semantic segmentation, polygons, and key-points." },
      { name: "Audio Annotation", description: "Phonetic transcripts and audio file labeling." },
      { name: "Synthetic Data Generation", description: "Seed training sets engineered for deep models." }
    ]
  },
  {
    title: "Digital Marketing",
    items: [
      { name: "Content Marketing", description: "Engage targets with articles, guides, and visual content." },
      { name: "Graphic Designing", description: "Premium UI materials, branding vectors, and print layouts." },
      { name: "SEO Services", description: "Boost search engine visibility and capture organic intent." },
      { name: "UI/UX Designing", description: "Develop modern, high-fidelity user flows and web views." },
      { name: "Paid Marketing", description: "Targeted PPC, social ads, and performance audits." },
      { name: "Social Media Marketing", description: "Drive engagement and build loyal digital communities." }
    ]
  },
  {
    title: "Business Intelligence",
    items: [
      { name: "Data Warehousing", description: "Unify business logs into highly accessible structures." },
      { name: "Custom Dashboards", description: "Visualize core operations through real-time telemetry." },
      { name: "Predictive Analytics", description: "Determine future volumes and customer behaviors." }
    ]
  },
  {
    title: "AI Automation Services",
    items: [
      { 
        name: "Data Intelligence Platform", 
        description: "Transform fragmented business data into a unified, actionable asset. Enable seamless data collection, integration, governance, and quality management to support faster and more informed decision-making." 
      },
      { 
        name: "Business Intelligence & Analytics", 
        description: "Convert operational data into meaningful insights through real-time reporting, predictive analytics, and performance monitoring. Empower leadership teams with visibility into key business metrics and trends." 
      },
      { 
        name: "Document Intelligence", 
        description: "Automate the extraction, classification, and processing of business documents using AI. Reduce manual effort, improve accuracy, and accelerate document-driven workflows across the organization." 
      },
      { 
        name: "Customer Experience AI", 
        description: "Enhance customer engagement with intelligent support, conversational AI, and personalized interactions. Deliver faster resolutions, improved satisfaction, and consistent experiences across all channels." 
      },
      { 
        name: "Workflow Automation Platform", 
        description: "Streamline complex business processes through intelligent workflow orchestration and automation. Eliminate repetitive tasks, improve operational efficiency, and increase organizational productivity." 
      },
      { 
        name: "Knowledge Management AI", 
        description: "Unlock the value of enterprise knowledge through AI-powered search, discovery, and information retrieval. Help teams access critical information instantly and make better decisions with confidence." 
      },
      { 
        name: "AI Agents & Copilots", 
        description: "Deploy intelligent AI assistants that support employees, automate routine activities, and enhance decision-making. Increase productivity by augmenting teams with specialized AI-driven capabilities." 
      },
      { 
        name: "Training Data & Annotation Platform", 
        description: "Accelerate AI model development with scalable data annotation, validation, and dataset management solutions. Ensure high-quality training data that improves model accuracy and performance." 
      }
    ]
  }
];

export const CLIENT_LOGOS: ClientLogo[] = [
  { name: "All Care Consultants, Inc", color: "#001A7D", fallbackLogo: "All Care" },
  { name: "Alternative Claim Management", color: "#002CCE", fallbackLogo: "ACM" },
  { name: "Chapman Insurance Group", color: "#030285", fallbackLogo: "Chapman" },
  { name: "CRS Insurance Brokerage", color: "#001A7D", fallbackLogo: "CRS" },
  { name: "CHRP", color: "#002CCE", fallbackLogo: "chrp" },
  { name: "Western Gold Insurance Agency", color: "#030285", fallbackLogo: "Western Gold" }
];

export const WHY_CHOOSE_US: WhyChooseUsItem[] = [
  {
    id: "support",
    title: "AI + human = growth",
    description: "A powerful blend of AI tools and real human expertise to bring you exceptional operations.",
    iconName: "support"
  },
  {
    id: "form",
    title: "Your business, your way",
    description: "Services customized for your operation with teams fully synchronized with your local time zone.",
    iconName: "form"
  },
  {
    id: "domain",
    title: "All-in-one support",
    description: "Multi-layered operational support with dedicated backup staff to maintain flawless service continuity.",
    iconName: "domain"
  },
  {
    id: "scope",
    title: "Client first, always",
    description: "We work as a strategic extension of your company, actively invested in your growth and success.",
    iconName: "scope"
  }
];

export const SERVICES_SERVICES: ServiceItem[] = [
  {
    id: "insurance",
    title: "Insurance Outsourcing",
    description: "Enhance operations, from policy processing and claims management to new business setup, with our specialized insurance BPO services.",
    href: "/services/insurance"
  },
  {
    id: "accounting",
    title: "Accounting & Bookkeeping",
    description: "Accounting services that don’t just keep your business compliant but keep you growing. Built for modern businesses like yours.",
    href: "/services/accounting"
  },
  {
    id: "annotation",
    title: "Data Annotation",
    description: "From data labeling and tagging to synthetic data generation, train your AI/ML models with accurate, reliable data annotation support.",
    href: "/services/annotation"
  },
  {
    id: "bi",
    title: "Business Intelligence",
    description: "Your data holds the answers to your biggest questions! Are you making the most of it? With our business intelligence services, gain a holistic view of your operations.",
    href: "/services/bi"
  },
  {
    id: "marketing",
    title: "Digital Marketing",
    description: "Shining out in today’s digital space requires smart and strategic digital marketing solutions. Whether you are trying to boost your visibility or gain traffic.",
    href: "/services/marketing"
  },
  {
    id: "ai",
    title: "AI Automation Services",
    description: "Transform your core processes and scale productivity using bespoke AI integrations, workflow automation, intelligent copilots, and data platforms.",
    href: "/services/ai-automation-services"
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: "t1",
    text: "FBSPL has transformed how we handle policy processing. Their team is reliable, quick, and functions entirely in our time zone. They've saved us substantial overhead while increasing quality.",
    author: "Richard Chapman",
    position: "Managing Partner",
    company: "Chapman Insurance Group",
    rating: 5
  },
  {
    id: "t2",
    text: "The accounting and bookkeeping support we receive is second to none. They are meticulous and understand the modern financial regulatory framework perfectly.",
    author: "Elena Sorokina",
    position: "Director of Accounts",
    company: "All Care Consultants, Inc",
    rating: 5
  },
  {
    id: "t3",
    text: "We utilized their Data Annotation team for our autonomous driving telemetry. The accuracy of their bounding boxes and semantic segmentation surpassed our rigorous internally audited standards.",
    author: "Alex Rivers",
    position: "VP Artificial Intelligence",
    company: "chrp",
    rating: 5
  },
  {
    id: "t4",
    text: "Working with FBSPL has streamlined our claims management lifecycle. Turnaround times dropped from 5 days to less than 24 hours. They are a legendary operations partner.",
    author: "Thomas Wright",
    position: "Chief Operations Officer",
    company: "Alternative Claim Management",
    rating: 5
  },
  {
    id: "t5",
    text: "Highly adaptive and thoroughly professional. Their dual-shore staffing model keeps our agency customer support operating 24/7 without a single hiccup.",
    author: "Sarah Jenkins",
    position: "General Manager",
    company: "Western Gold Insurance Agency",
    rating: 5
  },
  {
    id: "t6",
    text: "Our data reconciliations were a weekly bottleneck. FBSPL set up standard schemas, automated checks, and took over daily processing. Complete control is back in our hands.",
    author: "Marcus Vance",
    position: "Financial Controller",
    company: "CRS Insurance Brokerage",
    rating: 5
  }
];

export const BRIEF_INSIGHTS = {
  caseStudies: [
    {
      id: "cs1",
      title: "How an Insurance Agency Reduced Policy Checking Time by 60%",
      snippet: "Discover the specific automation and validation framework we integrated to accelerate policy reviews, ensuring compliance and cutting manual labor in half.",
      readTime: "6 min read",
      date: "May 2026",
      category: "Case Studies"
    },
    {
      id: "cs2",
      title: "Scaling Bookkeeping Support for a Growing SaaS Enterprise",
      snippet: "How FBSPL restructured cashflow processing and standard ledger reconciliations to handle a 300% growth in transaction volumes without increasing in-house overhead.",
      readTime: "8 min read",
      date: "Apr 2026",
      category: "Case Studies"
    }
  ],
  clientStories: [
    {
      id: "s1",
      title: "Chapman Insurance Group: A Story of High-Speed Automation",
      snippet: "Chapman Group wanted to enhance client response ratings during peak hurricane seasons. Our standby processing team helped them clear claim file backlog effortlessly.",
      readTime: "5 min read",
      date: "May 2026",
      category: "Client Stories"
    },
    {
      id: "s2",
      title: "Transitioning to 24/7 Operations with Western Gold",
      snippet: "How a hybrid human+AI virtual agent setup allowed Western Gold to secure continuous coverage options for clients in every time zone, driving a 30% revenue boost.",
      readTime: "7 min read",
      date: "Mar 2026",
      category: "Client Stories"
    }
  ],
  podcasts: [
    {
      id: "p1",
      title: "Episode 45: The AI + Human Core",
      snippet: "Our CEO sits down with tech analysts to dissect why stand-alone AI agents fail without expert human-in-the-loop validation.",
      readTime: "24 min listen",
      date: "May 2026",
      category: "Podcast"
    },
    {
      id: "p2",
      title: "Episode 46: Accelerating Growth with Time-Zone Aligned Teams",
      snippet: "Tune in to hear how global businesses leverage 100% overlapping schedules to maintain real-time updates and seamless continuity across borders.",
      readTime: "18 min listen",
      date: "May 2026",
      category: "Podcast"
    }
  ],
  events: [
    {
      id: "e1",
      title: "FBSPL at NetVU Annual Conference 2026",
      snippet: "Join our insurance outsourcing veterans as they demonstrate advanced agency optimization strategies live on stage.",
      readTime: "Conference",
      date: "June 2026",
      category: "Events"
    }
  ],
  blogs: [
    {
      id: "b1",
      title: "5 Outsourcing Pitfalls to Avoid in 2026",
      snippet: "Operational leaders outline critical factors for successful global staffing transitions, highlighting governance and cultural integrations.",
      readTime: "5 min read",
      date: "May 2026",
      category: "Blogs"
    },
    {
      id: "b2",
      title: "The Ultimate Guide to Human-in-the-Loop Back-Office Security",
      snippet: "A breakdown of best practices for maintaining continuous SOC-2 and ISO compliance when scaling your bookkeeping and data operational pipelines.",
      readTime: "6 min read",
      date: "Apr 2026",
      category: "Blogs"
    }
  ]
};
