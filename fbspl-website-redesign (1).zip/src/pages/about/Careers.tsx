import React, { useState } from 'react';
import { 
  Briefcase, 
  Clock, 
  MapPin, 
  Users, 
  Award, 
  TrendingUp, 
  Upload, 
  X, 
  Check, 
  ArrowRight,
  ShieldCheck,
  Zap,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Position {
  id: string;
  title: string;
  department: string;
  location: string;
  type: string;
  experience: string;
  description: string;
  requirements: string[];
}

const JOBS_DATA: Position[] = [
  {
    id: "job-1",
    title: "Insurance Process Operations Analyst",
    department: "Insurance Outsourcing",
    location: "Udaipur, India (Global Delivery Center)",
    type: "Full-Time",
    experience: "1 - 3 Years",
    description: "Analyze quote submissions, manage policy updates, check coverage parameters, and ensure rigorous SLA accuracy for our North American retail agency partners.",
    requirements: [
      "Excellent written & spoken English communication",
      "Prior BPO experience, preferably in Insurance or Finance operations",
      "Proficient in Agency Management Systems (AMS360, Applied Epic, or similar)",
      "High attention to detail and ability to work in overlapping US timezone shifts"
    ]
  },
  {
    id: "job-2",
    title: "Accounting & Bookkeeping Associate",
    department: "Accounting & Finance",
    location: "Hybrid (Remote / Udaipur Office)",
    type: "Full-Time",
    experience: "2 - 4 Years",
    description: "Handle AP/AR processing, maintain bank reconciliations, consolidate multi-ledger balances, and construct monthly financial statements for client reviews.",
    requirements: [
      "Bachelor's degree in Commerce, Accounting, or relative field",
      "Familiarity with QuickBooks Online, Xero, or NetSuite packages",
      "Strong conceptual grasp of accrual vs. cash book processes",
      "Ability to complete month-end reconciliation independently and accurately"
    ]
  },
  {
    id: "job-3",
    title: "Data Annotation & ML Tagging Specialist",
    department: "Data Intelligence",
    location: "Udaipur, India",
    type: "Full-Time",
    experience: "0 - 2 Years",
    description: "Label video paths, segment semantic pixel grids, map entity tags, and compile gold-standard training data inputs for complex generative AI visual models.",
    requirements: [
      "Strong visual observation and analytic reasoning skills",
      "Familiarity with standard computer interface annotation platforms",
      "Consistent throughput metrics matching high quality guidelines (99%+)",
      "Tech-savvy attitude with enthusiasm to train emerging models"
    ]
  },
  {
    id: "job-4",
    title: "AI Automation & Workflow Engineer",
    department: "Custom AI Solutions",
    location: "Hybrid (Remote OK)",
    type: "Full-Time",
    experience: "3+ Years",
    description: "Develop automated server workflows, connect REST APIs, implement OCR parsing engines, and deploy tailored AI Agents using the Google GenAI SDK.",
    requirements: [
      "Proficiency in Python/TypeScript and custom API integrations",
      "Experience with workflow automation (n8n, Make, or custom Node.js frameworks)",
      "Familiarity with Vector Databases (Pinecone, Chroma) and LLM orchestration (LangChain)",
      "A proactive problem solver with passion for streamlining legacy systems"
    ]
  }
];

export default function CareersPage() {
  const [selectedJob, setSelectedJob] = useState<Position | null>(null);
  const [applicationSuccess, setApplicationSuccess] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    linkedin: "",
    experienceDisclaimer: "1-2 years",
    resumeName: ""
  });

  const handleApplyClick = (job: Position) => {
    setSelectedJob(job);
    setApplicationSuccess(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileUploadMock = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({
        ...prev,
        resumeName: e.target.files![0].name
      }));
    }
  };

  const submitApplication = (e: React.FormEvent) => {
    e.preventDefault();
    // Real, state-bound confirmation flow
    setApplicationSuccess(true);
    setTimeout(() => {
      setSelectedJob(null);
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        linkedin: "",
        experienceDisclaimer: "1-2 years",
        resumeName: ""
      });
      setApplicationSuccess(false);
    }, 4000);
  };

  return (
    <div className="pt-32 pb-24 bg-[#F8FAFC]">
      <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
        
        {/* HERO HEADER */}
        <div className="text-center space-y-4 max-w-3xl mx-auto mb-16">
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-[#001D9D]/10 text-[#001A7D] text-xs font-black uppercase tracking-widest rounded-full">
            <Globe className="w-3.5 h-3.5" /> Work With Us
          </span>
          <h1 className="text-4xl md:text-5xl font-extrabold text-[#001A7D] tracking-tight">
            Empowering Talent, Scaling The Future
          </h1>
          <p className="text-sm md:text-base text-slate-600 leading-relaxed">
            At FBSPL, we nurture an environment of collaboration, state-of-the-art tools, and professional up-skilling. Be a part of a global team that supports international industry leaders around the clock.
          </p>
        </div>

        {/* WORK CULTURE CORE BENEFITS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
          <div className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100/80 hover:shadow-md transition duration-300 text-left space-y-4">
            <div className="w-12 h-12 rounded-xl bg-[#002CCE]/10 flex items-center justify-center text-[#002CCE]">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-extrabold uppercase tracking-wider text-slate-900">Continuous Growth</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              We offer structured certification tracks, training sponsorships, and direct mentorship plans to help expand your strategic and analytical horizons.
            </p>
          </div>

          <div className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100/80 hover:shadow-md transition duration-300 text-left space-y-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-600">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-extrabold uppercase tracking-wider text-slate-900">Inclusive Workplace</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Our diverse, vibrant culture rewards collaborative milestone success, balanced personal mental health, and community participation.
            </p>
          </div>

          <div className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100/80 hover:shadow-md transition duration-300 text-left space-y-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-600">
              <TrendingUp className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-extrabold uppercase tracking-wider text-slate-900">Strategic Exposure</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Work as an integral extension of Tier-1 businesses located across the UK, USA, and Europe to gain rich transactional context.
            </p>
          </div>
        </div>

        {/* DYNAMIC OPEN ROLES HEADER */}
        <div className="border-b border-slate-200/80 pb-3 mb-8 text-left flex items-center justify-between">
          <h2 className="text-xl font-extrabold text-[#001D9D] tracking-wide uppercase flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-[#002CCE]" /> Active Career Openings
          </h2>
          <span className="text-xs text-slate-500 font-bold bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
            {JOBS_DATA.length} Opportunities
          </span>
        </div>

        {/* JOBS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
          {JOBS_DATA.map((job) => (
            <div 
              key={job.id} 
              className="p-6 bg-white hover:bg-slate-50/50 rounded-2xl border border-slate-200/60 shadow-sm hover:shadow-md hover:border-[#002CCE]/30 transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2 items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 border border-slate-250">
                    {job.department}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-600 font-extrabold">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                    <span>{job.type}</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-base font-extrabold text-[#001A7D] leading-snug">
                    {job.title}
                  </h3>
                  <div className="flex flex-wrap gap-4 text-xs font-bold text-slate-500 mt-2">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-[#002CCE]" /> {job.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-amber-500" /> Exp: {job.experience}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">
                  {job.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-end">
                <button
                  onClick={() => handleApplyClick(job)}
                  className="px-5 py-2.5 bg-[#001A7D] hover:bg-[#F29001] text-white font-bold text-xs uppercase tracking-widest rounded-xl transition-all duration-300 flex items-center gap-1.5 cursor-pointer shadow-sm group"
                >
                  Apply to Role <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* WORK CULTURE CALLOUT */}
        <div className="mt-16 p-8 rounded-3xl bg-gradient-to-r from-[#00104E] to-[#001D9D] text-white text-left relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#002CCE]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="space-y-3 relative z-10 max-w-2xl">
            <h3 className="text-lg md:text-xl font-extrabold text-white tracking-wide">
              Don't see a position matching your track?
            </h3>
            <p className="text-xs text-white/85 leading-relaxed">
              We are constantly seeking outstanding analysts, digital specialists, translators, and automation developers to join our world-class dual-shore pipeline. Send your profile directly to our talent acquisition team.
            </p>
          </div>
          <a
            href="mailto:solutions@fbspl.com"
            className="px-6 py-3.5 bg-gradient-to-r from-[#F29001] to-[#F2994A] hover:from-[#F2994A] hover:to-[#F29001] text-white font-bold text-xs uppercase tracking-widest rounded-xl transition duration-300 shrink-0 select-none shadow-lg text-center cursor-pointer border border-[#F29001]"
          >
            Submit General Resume
          </a>
        </div>

      </div>

      {/* DETAILED INTERACTIVE APPLICATION DRAWER / MODAL */}
      <AnimatePresence>
        {selectedJob && (
          <div className="fixed inset-0 bg-[#00104E]/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-xl w-full max-h-[90vh] overflow-y-auto"
            >
              {/* MODAL HEADER */}
              <div className="bg-[#00104E] text-white p-6 relative">
                <button
                  type="button"
                  onClick={() => setSelectedJob(null)}
                  className="absolute top-4 right-4 p-2 text-white/75 bg-white/10 hover:bg-white/20 hover:text-white rounded-full transition-all duration-200 cursor-pointer"
                  aria-label="Close"
                >
                  <X className="w-4 h-4" />
                </button>
                <span className="text-[10px] font-black uppercase tracking-widest text-[#F2994A] block mb-1">
                  Applying for
                </span>
                <h3 className="text-base font-extrabold pr-8">
                  {selectedJob.title}
                </h3>
                <p className="text-xs text-white/70 mt-1 flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {selectedJob.location}
                </p>
              </div>

              {/* MODAL BODY */}
              <div className="p-6 space-y-6 text-left">
                {applicationSuccess ? (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="py-12 text-center space-y-4"
                  >
                    <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border-2 border-emerald-500 shadow-md">
                      <Check className="w-8 h-8" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-base font-bold text-slate-900">Application Received Successfully!</h4>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                        Thank you for your interest, <span className="font-extrabold text-slate-700">{formData.fullName}</span>. Our recruitment experts will evaluate your profile and contact you within 3 business days.
                      </p>
                    </div>
                  </motion.div>
                ) : (
                  <form onSubmit={submitApplication} className="space-y-4">
                    
                    {/* Requirements summary checklist */}
                    <div className="bg-[#F8FAFC] border border-slate-200/50 p-4 rounded-2xl">
                      <h4 className="text-xs font-black uppercase text-[#001A7D] tracking-wider mb-2 flex items-center gap-1">
                        <ShieldCheck className="w-4 h-4" /> Role Checklist
                      </h4>
                      <ul className="space-y-1 text-[11px] text-slate-600">
                        {selectedJob.requirements.map((req, rid) => (
                          <li key={rid} className="flex gap-2 items-start leading-relaxed">
                            <span className="text-emerald-500 text-xs shrink-0 select-none font-bold">✔</span>
                            <span>{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-extrabold text-[#001D9D] uppercase tracking-wide">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          required
                          name="fullName"
                          value={formData.fullName}
                          onChange={handleInputChange}
                          placeholder="e.g. Sid Sastri"
                          className="w-full text-xs py-3 px-4 border border-slate-200 focus:border-[#002CCE] rounded-xl focus:outline-none transition bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-slate-800"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-extrabold text-[#001D9D] uppercase tracking-wide">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          required
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="e.g. applicant@domain.com"
                          className="w-full text-xs py-3 px-4 border border-slate-200 focus:border-[#002CCE] rounded-xl focus:outline-none transition bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-slate-800"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-extrabold text-[#001D9D] uppercase tracking-wide">
                          Contact Phone *
                        </label>
                        <input
                          type="tel"
                          required
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="e.g. +1 (123) 456-7890"
                          className="w-full text-xs py-3 px-4 border border-slate-200 focus:border-[#002CCE] rounded-xl focus:outline-none transition bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-slate-800"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-extrabold text-[#001D9D] uppercase tracking-wide">
                          LinkedIn URL (Optional)
                        </label>
                        <input
                          type="url"
                          name="linkedin"
                          value={formData.linkedin}
                          onChange={handleInputChange}
                          placeholder="e.g. linkedin.com/in/profile"
                          className="w-full text-xs py-3 px-4 border border-slate-200 focus:border-[#002CCE] rounded-xl focus:outline-none transition bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-slate-800"
                        />
                      </div>
                    </div>

                    {/* Resume Upload Box */}
                    <div className="space-y-2">
                      <label className="text-xs font-extrabold text-[#001D9D] uppercase tracking-wide block">
                        Resume Upload *
                      </label>
                      <div className="relative border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50 hover:bg-slate-100/30 transition p-6 text-center cursor-pointer">
                        <input
                          type="file"
                          required={!formData.resumeName}
                          accept=".pdf,.doc,.docx"
                          onChange={handleFileUploadMock}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                        <div className="flex flex-col items-center justify-center space-y-1 text-slate-500">
                          <Upload className="w-6 h-6 text-[#002CCE] animate-bounce" />
                          <p className="text-[11px] font-extrabold uppercase tracking-wide text-slate-700">
                            {formData.resumeName || "Drag, drop, or select document"}
                          </p>
                          <p className="text-[10px] text-slate-400">
                            PDF, DOC, or DOCX up to 5MB
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Submit action buttons */}
                    <div className="flex gap-3 justify-end pt-4 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => setSelectedJob(null)}
                        className="px-4 py-2.5 hover:bg-slate-100 text-slate-500 font-bold text-xs uppercase tracking-wide rounded-xl transition cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-6 py-2.5 bg-gradient-to-r from-[#001A7D] to-[#002CCE] text-white font-bold text-xs uppercase tracking-widest rounded-xl transition shadow-md hover:shadow-lg hover:scale-103 active:scale-97 cursor-pointer border border-[#001A7D]"
                      >
                        Submit Application
                      </button>
                    </div>

                  </form>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
