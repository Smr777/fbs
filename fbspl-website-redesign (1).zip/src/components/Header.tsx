import { useState, useRef, useEffect } from 'react';
import { 
  Menu, 
  X, 
  ChevronDown, 
  ArrowRight, 
  Cpu, 
  Sparkles, 
  Users, 
  Award, 
  TrendingUp, 
  BookOpen, 
  ShieldCheck, 
  ArrowUpRight,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import fbsplLogo from '../Images/Logo.svg';
import { SERVICES_MENU } from '../data/websiteContent';

const INSIGHTS_NAV_MENU = [
  {
    title: "Blogs",
    subtitle: "Insights & best practices",
    description: "Industry news, tips, trends and best practices for modern enterprise scaling.",
    path: "/insights/blogs",
    items: [
      { name: "5 Outsourcing Pitfalls to Avoid in 2026", description: "Critical factors for successful staffing transitions." },
      { name: "Back-Office Security Checklist", description: "Maintaining continuous SOC-2 and ISO compliance." },
      { name: "Scaling Your Workflows", description: "Optimize operations and metrics without quality dilution." }
    ]
  },
  {
    title: "Client Stories",
    subtitle: "Real-world impact",
    description: "In-depth case stories and testimonials of operational conversion and strategic growth.",
    path: "/insights/client-stories",
    items: [
      { name: "Chapman Insurance Group", description: "Eliminating backlogs during peak natural disaster seasons." },
      { name: "Western Gold Insurance Agency", description: "Setting up a 24/7 client-facing virtual + human desk." },
      { name: "All Care Consultants Growth", description: "High-volume bookkeeping and ledger synchronization." }
    ]
  },
  {
    title: "Guides",
    subtitle: "Actionable playbooks",
    description: "Actionable guidelines and operational templates for restructuring cost-centers.",
    path: "/insights/guides",
    items: [
      { name: "Insourcing vs. BPO Calculator", description: "A detailed framework to weigh cost metrics." },
      { name: "Workflow Optimization Blueprint", description: "Our proprietary 5-step operational pipeline." }
    ]
  },
  {
    title: "Newsroom",
    subtitle: "FBSPL updates",
    description: "Official press announcements, brand milestones, and corporate notifications.",
    path: "/insights/newsroom",
    items: [
      { name: "FBSPL Global Center Expansion", description: "Scaling physical infrastructure to assist dual-shoring." },
      { name: "Best Operations Partner Award", description: "Recognized for service quality in complex BPO delivery." }
    ]
  },
  {
    title: "Podcast",
    subtitle: "Operational audio",
    description: "Audio discussions with operational leaders, technology officers, and specialists.",
    path: "/insights/podcast",
    items: [
      { name: "Episode 45: The AI + Human Core", description: "CEO discusses when and how standalone AI models crash." },
      { name: "Episode 46: Schedule Overlaps", description: "Succeeding with 100% real-time timezone alignment." }
    ]
  },
  {
    title: "Events",
    subtitle: "Meet our experts live",
    description: "Check our upcoming speaker slots, corporate conferences, and dynamic webinars.",
    path: "/insights/events",
    items: [
      { name: "NetVU Annual Summit 2026", description: "Join our insurance outsourcing veterans live." },
      { name: "InsurTech Boston Meetup", description: "Transforming retail agency policy lifecycles through BPO." }
    ]
  },
  {
    title: "Testimonials",
    subtitle: "Partner opinions",
    description: "Feedback and ratings collected direct from long-term operational partners.",
    path: "/insights/testimonials",
    items: [
      { name: "Richard Chapman (Chapman Group)", description: "Read the managing partner's experience." },
      { name: "Elena Sorokina (All Care Consultants)", description: "Detailed review of our bookkeeping service quality." }
    ]
  }
];

const ABOUT_NAV_MENU = [
  {
    title: "Who we are",
    subtitle: "FBSPL identity",
    description: "Learn about our extensive history, unique values, and passion for scale.",
    path: "/about/who-we-are",
    items: [
      { name: "Our Core Culture", description: "A balance of human psychology, robust governance, and tech." },
      { name: "Over 18 Years of Experience", description: "Enabling complete control over daily business operations." },
      { name: "Global Delivery Grid", description: "The locations keeping our client support running indefinitely." }
    ]
  },
  {
    title: "Leadership",
    subtitle: "Executive team",
    description: "Meet the seasoned industry veterans and operators leading the charge.",
    path: "/about/leadership",
    items: [
      { name: "The Executive Board", description: "Strategic directors behind the dual-shore scale architecture." },
      { name: "Operational Heads", description: "The leadership team supervising daily SLA check-boxes." }
    ]
  },
  {
    title: "Social Responsibility",
    subtitle: "FBSPL impact",
    description: "Our long-term green strategies, community outreach, and philanthropic efforts.",
    path: "/about/social-responsibility",
    items: [
      { name: "EcoGuard Office Program", description: "Carbon-neutral practices deployed across our delivery facilities." },
      { name: "EduGrow Skill Foundation", description: "Sponsoring professional skill-focused training circles." }
    ]
  },
  {
    title: "Life at FBSPL",
    subtitle: "Culture in action",
    description: "Discover our dynamic team environments, social calendars, and employee benefits.",
    path: "/about/life-at-fbspl",
    items: [
      { name: "Workplace Psychology", description: "Why FBSPL ranks consistently high for employee satisfaction." },
      { name: "Career Openings", description: "Positions ready for hungry analysts and operational minds." }
    ]
  },
  {
    title: "FAQs",
    subtitle: "Solutions answered",
    description: "Get answers to your initial operational questions regarding service setup, pricing, or compliance.",
    path: "/about/faqs",
    items: [
      { name: "SLA & Onboarding Questions", description: "How fast can dedicated backup support be established?" },
      { name: "Security & Governance Protocols", description: "Ensuring secure desktop procedures and SOC-2 standard checks." }
    ]
  },
  {
    title: "Careers",
    subtitle: "Grow with FBSPL",
    description: "Build an exceptional career with global operational leaders and technology experts.",
    path: "/careers",
    items: [
      { name: "Open Positions", description: "Find role specifications and apply to join our high-performing teams." },
      { name: "Global Work Culture", description: "Learn about dual-shored models and personal career development plans." }
    ]
  }
];

interface HeaderProps {
  onNavigate: (view: string) => void;
  currentView: string;
}

export default function Header({ onNavigate, currentView }: HeaderProps) {
  const [activeDropdown, setActiveDropdown] = useState<'services' | 'insights' | 'about' | null>(null);
  const [selectedServiceIdx, setSelectedServiceIdx] = useState<number>(0);
  const [selectedInsightIdx, setSelectedInsightIdx] = useState<number>(0);
  const [selectedAboutIdx, setSelectedAboutIdx] = useState<number>(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [sticky, setSticky] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Handle scroll detection for sticky glassmorphism
  useEffect(() => {
    const handleScroll = () => {
      const isSticky = window.scrollY > 20;
      setSticky(prev => {
        if (prev !== isSticky) return isSticky;
        return prev;
      });
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setActiveDropdown(null);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleDropdown = (menu: 'services' | 'insights' | 'about') => {
    if (activeDropdown === menu) {
      setActiveDropdown(null);
    } else {
      setActiveDropdown(menu);
      if (menu === 'services') {
        setSelectedServiceIdx(0);
      } else if (menu === 'insights') {
        setSelectedInsightIdx(0);
      } else if (menu === 'about') {
        setSelectedAboutIdx(0);
      }
    }
  };

  const handleSubpageClick = (path: string) => {
    setActiveDropdown(null);
    setMobileMenuOpen(false);
    onNavigate(path);
  };

  const aiToolkitLink = "https://www.fbsplai.com/?__hstc=234797825.699a9a9946128c01a024c5baf3c2b45d.1775552622332.1779414264179.1779508014611.4&__hssc=234797825.1.1779508014611&__hsfp=e21838a5d5dfce8b2405978dfb0876e6";

  return (
    <>
      <header 
        className={`fixed top-0 left-0 right-0 transition-all duration-300 ${
          mobileMenuOpen ? 'z-[101]' : 'z-50'
        } ${
          sticky 
            ? 'bg-white/95 backdrop-blur-md py-3 border-b border-gray-300' 
            : 'bg-transparent py-5'
        }`}
        id="fbspl-header"
      >
        <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* LOGO */}
            <div 
              className="flex-shrink-0 cursor-pointer flex items-center gap-2 group"
              onClick={() => handleSubpageClick('home')}
              id="header-logo"
            >
              <img 
                src={fbsplLogo} 
                alt="FBSPL" 
                width="159"
                height="40"
                className="h-10 w-auto object-contain select-none transition-transform group-hover:scale-[1.02]" 
              />
            </div>

            {/* DESKTOP NAVIGATION */}
            <nav className="hidden lg:flex items-center space-x-8" ref={dropdownRef}>
              {/* SERVICES DROPDOWN */}
              <div className="relative">
                <button
                  onClick={() => toggleDropdown('services')}
                  onDoubleClick={() => handleSubpageClick('/services')}
                  title="Double click to view all services"
                  className={`flex items-center gap-1.5 text-sm font-semibold tracking-wide transition-colors cursor-pointer ${
                    activeDropdown === 'services' || currentView.startsWith('/services')
                      ? 'text-[#002CCE]'
                      : 'text-black-text hover:text-[#002CCE]'
                  }`}
                  id="nav-services-btn"
                >
                  Services
                  <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${activeDropdown === 'services' ? 'rotate-180' : ''}`} />
                </button>

                {/* SERVICES MEGA DROPDOWN */}
                <AnimatePresence>
                  {activeDropdown === 'services' && (
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 15 }}
                      transition={{ duration: 0.25, ease: "easeOut" }}
                      className="absolute left-1/2 -translate-x-1/2 mt-4 w-[860px] bg-white rounded-2xl shadow-xl border-2 border-lavender p-6 z-50 text-left grid grid-cols-12 gap-6"
                    >
                      {/* Left Column: Main Services Selector */}
                      <div className="col-span-5 space-y-3 border-r border-lavender pr-6">
                        <h4 className="text-[11px] font-bold uppercase text-black-text/60 tracking-wider">
                          Main Services
                        </h4>
                        <div className="grid grid-cols-1 gap-1">
                          {SERVICES_MENU.map((category, idx) => (
                            <button
                              key={category.title}
                              onMouseEnter={() => setSelectedServiceIdx(idx)}
                              onClick={() => setSelectedServiceIdx(idx)}
                              className={`w-full text-left font-semibold text-sm py-2.5 px-3 rounded-lg transition-all duration-205 flex items-center justify-between group cursor-pointer ${
                                selectedServiceIdx === idx 
                                  ? 'bg-lavender text-[#001A7D] shadow-sm font-extrabold' 
                                  : 'text-black-text hover:bg-lavender/40 hover:text-[#002CCE]'
                              }`}
                            >
                              <span>{category.title}</span>
                              <ChevronRight className={`w-4 h-4 transition-transform duration-200 ${selectedServiceIdx === idx ? 'translate-x-1 opacity-100 text-[#002CCE]' : 'opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5'}`} />
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Right Column: Sub Services Showcase */}
                      <div className="col-span-7 flex flex-col justify-between h-full min-h-[380px]">
                        <div className="space-y-4">
                          <div className="border-b-2 pb-2 border-lavender">
                            <button
                              onClick={() => {
                                const mapping: Record<string, string> = {
                                  "Insurance Outsourcing": "/services/insurance",
                                  "Accounting & Bookkeeping": "/services/accounting",
                                  "Data Annotation": "/services/annotation",
                                  "Business Intelligence": "/services/bi",
                                  "Digital Marketing": "/services/marketing",
                                  "AI Automation Services": "/services/ai-automation-services"
                                };
                                const path = mapping[SERVICES_MENU[selectedServiceIdx].title] || `/services/${SERVICES_MENU[selectedServiceIdx].title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
                                handleSubpageClick(path);
                              }}
                              className="group/head text-left flex items-center gap-1.5 focus:outline-none cursor-pointer"
                            >
                              <h4 className="text-xs font-bold uppercase tracking-wider text-[#002CCE] group-hover/head:underline group-hover/head:text-[#001A7D]">
                                {SERVICES_MENU[selectedServiceIdx].title}
                              </h4>
                              <ArrowUpRight className="w-3.5 h-3.5 text-[#002CCE] opacity-60 group-hover/head:opacity-100 group-hover/head:translate-x-0.5 group-hover/head:-translate-y-0.5 transition-all" />
                            </button>
                            <p className="text-[11px] text-black-text/70 mt-1">
                              Explore our specialized back-office capabilities and intelligent workflows.
                            </p>
                          </div>
                          
                          <div className="grid grid-cols-1 gap-2.5 max-h-[290px] overflow-y-auto pr-1">
                             {SERVICES_MENU[selectedServiceIdx].items.map((sub, sIdx) => (
                              <button
                                key={sIdx}
                                onClick={() => handleSubpageClick(`/services/${sub.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`)}
                                className="group flex flex-col items-start text-left w-full rounded-xl p-2.5 hover:bg-lavender/40 hover:text-[#002CCE] transition-all duration-200 cursor-pointer"
                              >
                                <div className="flex items-center gap-1">
                                  <span className="text-sm font-semibold text-midnight-blue group-hover:text-[#002CCE] transition-colors">
                                    {sub.name}
                                  </span>
                                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all text-[#002CCE]" />
                                </div>
                                {sub.description && (
                                  <span className="text-[11px] text-black-text/80 mt-0.5 leading-relaxed line-clamp-1 group-hover:line-clamp-none transition-all">
                                    {sub.description}
                                  </span>
                                )}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Bottom Action Strip */}
                        <div className="mt-4 pt-4 border-t-2 border-lavender flex items-center justify-between">
                          <span className="text-[11px] text-black-text/60">
                            Custom solutions designed for your operational needs.
                          </span>
                          <button
                            onClick={() => handleSubpageClick('/services')}
                            className="flex items-center gap-1.5 text-xs font-bold text-[#002CCE] hover:text-[#001A7D] hover:underline uppercase tracking-wider cursor-pointer"
                          >
                            All Services
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* INSIGHTS DROPDOWN */}
              <div className="relative">
                <button
                  onClick={() => toggleDropdown('insights')}
                  onDoubleClick={() => handleSubpageClick('/insights')}
                  title="Double click to view all insights"
                  className={`flex items-center gap-1.5 text-sm font-semibold tracking-wide transition-colors cursor-pointer ${
                    activeDropdown === 'insights' || currentView.startsWith('/insights')
                      ? 'text-[#002CCE]'
                      : 'text-black-text hover:text-[#002CCE]'
                  }`}
                  id="nav-insights-btn"
                >
                  Insights
                  <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${activeDropdown === 'insights' ? 'rotate-180' : ''}`} />
                </button>
 
                {/* INSIGHTS MEGA MENU (Split Layout) */}
                <AnimatePresence>
                  {activeDropdown === 'insights' && (
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 15 }}
                      transition={{ duration: 0.25, ease: "easeOut" }}
                      className="absolute left-1/2 -translate-x-1/2 mt-4 w-[860px] bg-white rounded-2xl shadow-xl border-2 border-lavender p-6 z-50 text-left grid grid-cols-12 gap-6"
                    >
                      {/* Left Column: Categories Selector */}
                      <div className="col-span-5 space-y-3 border-r border-lavender pr-6">
                        <h4 className="text-[11px] font-bold uppercase text-black-text/60 tracking-wider">
                          Categories
                        </h4>
                        <div className="grid grid-cols-1 gap-1">
                          {INSIGHTS_NAV_MENU.map((category, idx) => (
                            <button
                              key={category.title}
                              onMouseEnter={() => setSelectedInsightIdx(idx)}
                              onClick={() => setSelectedInsightIdx(idx)}
                              className={`w-full text-left font-semibold text-sm py-2.5 px-3 rounded-lg transition-all duration-200 flex items-center justify-between group cursor-pointer ${
                                selectedInsightIdx === idx 
                                  ? 'bg-lavender text-[#001A7D] shadow-sm font-extrabold' 
                                  : 'text-black-text hover:bg-lavender/40 hover:text-[#002CCE]'
                              }`}
                            >
                              <div className="flex flex-col items-start text-left">
                                <span>{category.title}</span>
                                <span className={`text-[10px] font-medium leading-none ${selectedInsightIdx === idx ? 'text-[#002CCE]' : 'text-black-text/60'}`}>
                                  {category.subtitle}
                                </span>
                              </div>
                              <ChevronRight className={`w-4 h-4 transition-transform duration-200 ${selectedInsightIdx === idx ? 'translate-x-1 opacity-100 text-[#002CCE]' : 'opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5'}`} />
                            </button>
                          ))}
                        </div>
                      </div>
 
                      {/* Right Column: Sub-Category Showcase */}
                      <div className="col-span-7 flex flex-col justify-between h-full min-h-[380px]">
                        <div className="space-y-4">
                          <div className="border-b-2 pb-2 border-lavender">
                            <button
                              onClick={() => handleSubpageClick(INSIGHTS_NAV_MENU[selectedInsightIdx].path)}
                              className="group/head text-left flex items-center gap-1.5 focus:outline-none cursor-pointer"
                            >
                              <h4 className="text-xs font-bold uppercase tracking-wider text-[#002CCE] group-hover/head:underline group-hover/head:text-[#001A7D]">
                                {INSIGHTS_NAV_MENU[selectedInsightIdx].title}
                              </h4>
                              <ArrowUpRight className="w-3.5 h-3.5 text-[#002CCE] opacity-60 group-hover/head:opacity-100 group-hover/head:translate-x-0.5 group-hover/head:-translate-y-0.5 transition-all" />
                            </button>
                            <p className="text-[11px] text-black-text/70 mt-1">
                              {INSIGHTS_NAV_MENU[selectedInsightIdx].description}
                            </p>
                          </div>
                          
                          <div className="grid grid-cols-1 gap-2.5 max-h-[290px] overflow-y-auto pr-1">
                            {INSIGHTS_NAV_MENU[selectedInsightIdx].items.map((sub, sIdx) => (
                              <button
                                key={sIdx}
                                onClick={() => handleSubpageClick(INSIGHTS_NAV_MENU[selectedInsightIdx].path)}
                                className="group flex flex-col items-start text-left w-full rounded-xl p-2.5 hover:bg-lavender/40 hover:text-[#002CCE] transition-all duration-200 cursor-pointer"
                              >
                                <div className="flex items-center gap-1">
                                  <span className="text-sm font-semibold text-midnight-blue group-hover:text-[#002CCE] transition-colors line-clamp-1">
                                    {sub.name}
                                  </span>
                                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all text-[#002CCE]" />
                                </div>
                                {sub.description && (
                                  <span className="text-[11px] text-black-text/80 mt-0.5 leading-relaxed line-clamp-1 group-hover:line-clamp-none transition-all">
                                    {sub.description}
                                  </span>
                                )}
                              </button>
                            ))}
                          </div>
                        </div>
 
                        {/* Bottom Action Strip */}
                        <div className="mt-4 pt-4 border-t-2 border-lavender flex items-center justify-between">
                          <span className="text-[11px] text-black-text/60">
                            Our insights deliver direct business metrics to formulate client strategy.
                          </span>
                          <button
                            onClick={() => handleSubpageClick('/insights')}
                            className="flex items-center gap-1.5 text-xs font-bold text-[#002CCE] hover:text-[#001A7D] hover:underline uppercase tracking-wider cursor-pointer"
                          >
                            All Insights
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
 
              {/* ABOUT DROPDOWN */}
              <div className="relative">
                <button
                  onClick={() => toggleDropdown('about')}
                  onDoubleClick={() => handleSubpageClick('/about')}
                  title="Double click to view about us"
                  className={`flex items-center gap-1.5 text-sm font-semibold tracking-wide transition-colors cursor-pointer ${
                    activeDropdown === 'about' || currentView.startsWith('/about')
                      ? 'text-[#002CCE]'
                      : 'text-black-text hover:text-[#002CCE]'
                  }`}
                  id="nav-about-btn"
                >
                  About Us
                  <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${activeDropdown === 'about' ? 'rotate-180' : ''}`} />
                </button>
 
                {/* ABOUT MEGA MENU (Split Layout) */}
                <AnimatePresence>
                  {activeDropdown === 'about' && (
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 15 }}
                      transition={{ duration: 0.25, ease: "easeOut" }}
                      className="absolute left-1/2 -translate-x-1/2 mt-4 w-[860px] bg-white rounded-2xl shadow-xl border-2 border-lavender p-6 z-50 text-left grid grid-cols-12 gap-6"
                    >
                      {/* Left Column: Sections Selector */}
                      <div className="col-span-5 space-y-3 border-r border-lavender pr-6">
                        <h4 className="text-[11px] font-bold uppercase text-black-text/60 tracking-wider">
                          Sections
                        </h4>
                        <div className="grid grid-cols-1 gap-1">
                          {ABOUT_NAV_MENU.map((category, idx) => (
                            <button
                              key={category.title}
                              onMouseEnter={() => setSelectedAboutIdx(idx)}
                              onClick={() => setSelectedAboutIdx(idx)}
                              className={`w-full text-left font-semibold text-sm py-2.5 px-3 rounded-lg transition-all duration-200 flex items-center justify-between group cursor-pointer ${
                                selectedAboutIdx === idx 
                                  ? 'bg-lavender text-[#001A7D] shadow-sm font-extrabold' 
                                  : 'text-black-text hover:bg-lavender/40 hover:text-[#002CCE]'
                              }`}
                            >
                              <div className="flex flex-col items-start text-left">
                                <span>{category.title}</span>
                                <span className={`text-[10px] font-medium leading-none ${selectedAboutIdx === idx ? 'text-[#002CCE]' : 'text-black-text/60'}`}>
                                  {category.subtitle}
                                </span>
                              </div>
                              <ChevronRight className={`w-4 h-4 transition-transform duration-200 ${selectedAboutIdx === idx ? 'translate-x-1 opacity-100 text-[#002CCE]' : 'opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5'}`} />
                            </button>
                          ))}
                        </div>
                      </div>
 
                      {/* Right Column: Section Showcase */}
                      <div className="col-span-7 flex flex-col justify-between h-full min-h-[380px]">
                        <div className="space-y-4">
                          <div className="border-b-2 pb-2 border-lavender">
                            <button
                              onClick={() => handleSubpageClick(ABOUT_NAV_MENU[selectedAboutIdx].path)}
                              className="group/head text-left flex items-center gap-1.5 focus:outline-none cursor-pointer"
                            >
                              <h4 className="text-xs font-bold uppercase tracking-wider text-[#002CCE] group-hover/head:underline group-hover/head:text-[#001A7D]">
                                {ABOUT_NAV_MENU[selectedAboutIdx].title}
                              </h4>
                              <ArrowUpRight className="w-3.5 h-3.5 text-[#002CCE] opacity-60 group-hover/head:opacity-100 group-hover/head:translate-x-0.5 group-hover/head:-translate-y-0.5 transition-all" />
                            </button>
                            <p className="text-[11px] text-black-text/70 mt-1">
                              {ABOUT_NAV_MENU[selectedAboutIdx].description}
                            </p>
                          </div>
                          
                          <div className="grid grid-cols-1 gap-2.5 max-h-[290px] overflow-y-auto pr-1">
                            {ABOUT_NAV_MENU[selectedAboutIdx].items.map((sub, sIdx) => (
                              <button
                                key={sIdx}
                                onClick={() => handleSubpageClick(ABOUT_NAV_MENU[selectedAboutIdx].path)}
                                className="group flex flex-col items-start text-left w-full rounded-xl p-2.5 hover:bg-lavender/40 hover:text-[#002CCE] transition-all duration-200 cursor-pointer"
                              >
                                <div className="flex items-center gap-1">
                                  <span className="text-sm font-semibold text-midnight-blue group-hover:text-[#002CCE] transition-colors">
                                    {sub.name}
                                  </span>
                                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all text-[#002CCE]" />
                                </div>
                                {sub.description && (
                                  <span className="text-[11px] text-black-text/80 mt-0.5 leading-relaxed line-clamp-1 group-hover:line-clamp-none transition-all">
                                    {sub.description}
                                  </span>
                                )}
                              </button>
                            ))}
                          </div>
                        </div>
 
                        {/* Bottom Action Strip */}
                        <div className="mt-4 pt-4 border-t-2 border-lavender flex items-center justify-between">
                          <span className="text-[11px] text-black-text/60">
                            Transforming back-offices and workflows with absolute precision.
                          </span>
                          <button
                            onClick={() => handleSubpageClick('/about/who-we-are')}
                            className="flex items-center gap-1.5 text-xs font-bold text-[#002CCE] hover:text-[#001A7D] hover:underline uppercase tracking-wider cursor-pointer"
                          >
                            About Us
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </nav>

            {/* HEADER INTERACTION ACTIONS */}
            <div className="hidden lg:flex items-center space-x-4">
              {/* CTA button: Explore our AI Toolkit */}
              <button
                onClick={() => handleSubpageClick('/services/ai-automation-services')}
                className="relative inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#001A7D] to-[#002CCE] px-5 py-2.5 rounded-full shadow-lg hover:shadow-xl hover:scale-103 active:scale-98 transition-all duration-300 group border-2 border-transparent hover:border-[#F29001] cursor-pointer"
                id="header-ai-toolkit-cta"
              >
                <Cpu className="w-3.5 h-3.5 animate-pulse text-white group-hover:text-[#F29001] transition-colors duration-300" />
                <span className="group-hover:text-[#F29001] transition-colors duration-300">Explore our AI Toolkit</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-white group-hover:text-[#F29001] transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>
            </div>

            {/* MOBILE INTERACTIVE CONTROLS */}
            <div className="flex lg:hidden items-center space-x-3">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-midnight-blue hover:text-[#002CCE] hover:bg-lavender/30 rounded-lg transition cursor-pointer"
                aria-label="Menu"
                id="header-mobile-hamburger"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* MOBILE FULLSCREEN DRAWER */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="fixed inset-0 bg-white z-[100] overflow-y-auto pt-24 pb-8 px-6 flex flex-col justify-between"
          >
            <div className="space-y-6">
              {/* Category 1: Services */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#001A7D] border-b-2 border-lavender pb-1.5">
                  Services
                </h4>
                <div className="grid grid-cols-2 gap-2 pl-2">
                  {['Insurance BPO', 'Bookkeeping', 'Data Annotation', 'Digital Marketing', 'Business Intelligence', 'AI Automation Services'].map((val) => (
                    <button
                      key={val}
                      onClick={() => handleSubpageClick(`/services/${val.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`)}
                      className="text-left text-xs font-semibold text-black-text hover:text-[#002CCE] py-1 transition cursor-pointer"
                    >
                      {val}
                    </button>
                  ))}
                  <button
                    onClick={() => handleSubpageClick('/services')}
                    className="col-span-2 text-left text-xs font-bold text-[#002CCE] hover:text-[#001A7D] hover:underline mt-1 cursor-pointer"
                  >
                    View All Services &rarr;
                  </button>
                </div>
              </div>

              {/* Category 2: Insights */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#001A7D] border-b-2 border-lavender pb-1.5">
                  Insights
                </h4>
                <div className="grid grid-cols-2 gap-2 pl-2">
                  {['Blogs', 'Client Stories', 'Guides', 'Newsroom', 'Podcast', 'Events', 'Testimonials'].map((val) => (
                    <button
                      key={val}
                      onClick={() => handleSubpageClick(`/insights/${val.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`)}
                      className="text-left text-xs font-semibold text-black-text hover:text-[#002CCE] py-1 transition cursor-pointer"
                    >
                      {val}
                    </button>
                  ))}
                  <button
                    onClick={() => handleSubpageClick('/insights')}
                    className="col-span-2 text-left text-xs font-bold text-[#002CCE] hover:text-[#001A7D] hover:underline mt-1 cursor-pointer"
                    id="mobile-view-all-insights"
                  >
                    View All Insights &rarr;
                  </button>
                </div>
              </div>

              {/* Category 3: About */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#001A7D] border-b-2 border-lavender pb-1.5">
                  About Us
                </h4>
                <div className="grid grid-cols-2 gap-2 pl-2">
                  {['Who we are', 'Leadership', 'Social Responsibility', 'Life at FBSPL', 'FAQs', 'Careers'].map((val) => (
                    <button
                      key={val}
                      onClick={() => handleSubpageClick(
                        val === 'Careers' ? '/careers' : 
                        `/about/${val.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`
                      )}
                      className="text-left text-xs font-semibold text-black-text hover:text-[#002CCE] py-1 transition cursor-pointer"
                    >
                      {val}
                    </button>
                  ))}
                  <button
                    onClick={() => handleSubpageClick('/about')}
                    className="col-span-2 text-left text-xs font-bold text-[#002CCE] hover:text-[#001A7D] hover:underline mt-1 cursor-pointer"
                    id="mobile-view-about-us"
                  >
                    View About Us &rarr;
                  </button>
                </div>
              </div>
            </div>

            {/* Footer level actions on mobile */}
            <div className="mt-12 space-y-4 border-t pt-6 border-lavender">
              <button
                onClick={() => handleSubpageClick('/services/ai-automation-services')}
                className="w-full flex items-center justify-center gap-2 text-xs font-bold uppercase py-3 border-2 border-[#002CCE] text-white bg-[#002CCE] hover:border-[#F29001] rounded-full transition-all duration-300 text-center cursor-pointer"
              >
                <Cpu className="w-4 h-4" />
                Explore our AI Toolkit
              </button>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  const contactEl = document.getElementById('contact-form-section');
                  if (contactEl) {
                    contactEl.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="w-full text-center bg-[#001A7D] border-2 border-[#001A7D] hover:bg-[#F29001] hover:border-[#F29001] hover:text-white font-bold py-3 text-xs uppercase tracking-wide rounded-full shadow-md transition-all duration-300 pointer-events-auto cursor-pointer"
              >
                Inquire Now
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
