import React, { useState } from 'react';
import { 
  Facebook, 
  Twitter, 
  Youtube, 
  Instagram, 
  Linkedin, 
  ArrowRight, 
  Mail, 
  Phone, 
  Check, 
  Award,
  ArrowUp,
  ChevronDown
} from 'lucide-react';
import fbsplLogo from '../Images/Logo.svg';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const [emailValue, setEmailValue] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [showAllFaqs, setShowAllFaqs] = useState(false);
  const [openFaqQ, setOpenFaqQ] = useState<string | null>(null);

  const faqs = [
    {
      q: "What core services does FBSPL offer?",
      a: "We specialize in Insurance Back Office Support, Accounting & Bookkeeping, Data Annotation, Business Intelligence, Agency Optimization, Digital Marketing, and custom AI Automation Services."
    },
    {
      q: "Are FBSPL operations secure and compliant?",
      a: "Yes, we are ISO 27001:2013 certified for Information Security and ISO 9001:2015 certified for Quality Management Systems, providing robust protection for all client data."
    },
    {
      q: "How do we initiate a consultation?",
      a: "Simply click 'Book a consultation' or reach out to solutions@fbspl.com. Our operations experts will analyze your process logic and map out an optimized dual-shore blueprint."
    },
    {
      q: "What industries does FBSPL serve?",
      a: "We provide strategic leadership and operational support tailored to multiple major global sectors, including Insurance Agencies, Financial Institutions, Logistics, Healthcare Billing, and AI Research projects."
    },
    {
      q: "What is the typical onboarding timeline for new partners?",
      a: "Most process transfers are initiated within 2 to 4 weeks. This includes detailed standard operating procedure (SOP) documentation, dual-shoring validation, and pilot phase metrics tracking."
    },
    {
      q: "Does FBSPL offer tailored customization for different business scales?",
      a: "Absolutely. We serve both high-growth startups and established multinational enterprises with scalable resource allocation that responds dynamically to operational demand peaks."
    },
    {
      q: "How does FBSPL handle quality assurance and performance monitoring?",
      a: "We utilize a dedicated quality team paired with real-time BI dashboards. This ensures SLA compliance is tracked live and continuous training interventions are enacted proactively."
    }
  ];

  const displayedFaqs = showAllFaqs ? faqs : faqs.slice(0, 4);

  const toggleFaq = (question: string) => {
    setOpenFaqQ(openFaqQ === question ? null : question);
  };

  const handleSubscribeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailValue.trim()) {
      setSubscribed(true);
      setEmailValue('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  const handleLinkClick = (view: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    onNavigate(view);
  };

  return (
    <footer className="bg-[#001A7D] text-white/90 mt-0 pt-6 pb-12 border-t border-lavender-alt/20" id="fbspl-footer">
      <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8">
        
        {/* NEW HORIZONTAL 2-COLUMN NEWSLETTER SECTION */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-0 border-b border-lavender-alt/20 items-center">
          <div className="lg:col-span-7 space-y-2">
            <h3 className="text-xl font-extrabold text-white tracking-wide">
              Subscribe to our Insights Newsletter
            </h3>
            <p className="text-xs sm:text-sm text-white/80 max-w-xl leading-relaxed">
              Receive premium operations research, automation case studies, and digital marketing reports directly to your inbox every fortnight.
            </p>
          </div>
          <div className="lg:col-span-5 w-full">
            <form onSubmit={handleSubscribeSubmit} className="flex flex-col sm:flex-row gap-2 w-full">
              <div className="relative flex-1">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-white/70" />
                <input
                  type="email"
                  placeholder="Enter email address"
                  required
                  value={emailValue}
                  onChange={(e) => setEmailValue(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-white/10 rounded-lg text-sm text-white placeholder-white/55 border border-white/20 focus:outline-none focus:border-[#F2994A] transition"
                />
              </div>
              <button
                type="submit"
                className="px-6 py-3 bg-gradient-to-r from-[#F29001] to-[#F2994A] hover:bg-none hover:bg-[#002CCE] text-white font-bold text-xs uppercase tracking-wider rounded-lg active:scale-98 transition duration-300 flex items-center justify-center gap-1.5 shrink-0 cursor-pointer border border-[#F29001]"
              >
                {subscribed ? (
                  <>
                    <Check className="w-4.5 h-4.5" /> Subscribed
                  </>
                ) : (
                  <>
                    Join List <ArrowRight className="w-4 h-4" />
                  </>
                )
                }
              </button>
            </form>
          </div>
        </div>

      </div>

      {/* FULL-VIEWPORT WIDTH CONTRASTING FAQ SECTION STRIP */}
      <div className="w-full bg-[#F4F7FC] border-y border-slate-200/50 pt-[18px] pb-[18px] mt-[10px] mb-[10px]" id="footer-faqs">
        <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8">
          {/* WHITE CANOPIED FAQ PANEL */}
          <div className="p-6 sm:p-8 bg-white text-slate-800 rounded-2xl shadow-[0_12px_42px_rgba(0,26,125,0.06)] border border-slate-100/80 max-w-6xl mx-auto">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-5 pb-4 border-b border-slate-100">
              
              {/* BRAND HIGHLIGHTED TITLE BLOCK WITH AMBER/ORANGE INDICATOR */}
              <div className="flex items-center gap-2.5">
                <div className="w-1.5 h-5 bg-gradient-to-b from-[#F29001] to-[#F2994A] rounded-full" />
                <h4 className="text-xs sm:text-xs font-extrabold uppercase tracking-widest text-[#001A7D]">
                  Operations & Partnership FAQ
                </h4>
              </div>

              {/* TOGGLE SWITCH - RIGHT MOST SIDE */}
              <div className="flex items-center gap-2 bg-slate-100/80 border border-slate-200/50 p-1 rounded-full shadow-inner shrink-0 select-none">
                <span className={`text-[9px] font-extrabold uppercase tracking-widest px-2.5 py-1 transition-colors duration-200 rounded-full ${!showAllFaqs ? 'bg-[#001A7D] text-white shadow-sm' : 'text-slate-400'}`}>
                  4 FAQs
                </span>
                <button 
                  type="button"
                  onClick={() => setShowAllFaqs(!showAllFaqs)}
                  className={`w-11 h-6 rounded-full p-0.5 transition-all duration-300 relative focus:outline-none cursor-pointer border border-transparent outline-none ${
                    showAllFaqs ? 'bg-[#001A7D]' : 'bg-slate-300/70'
                  }`}
                  aria-label="Toggle FAQs view size"
                >
                  <div className={`w-4.5 h-4.5 bg-white rounded-full shadow transition-transform duration-300 flex items-center justify-center transform ${showAllFaqs ? 'translate-x-5' : 'translate-x-0'}`}>
                    <div className={`w-1.5 h-1.5 rounded-full transition-colors duration-200 ${showAllFaqs ? 'bg-[#F2994A]' : 'bg-slate-300'}`} />
                  </div>
                </button>
                <span className={`text-[9px] font-extrabold uppercase tracking-widest px-2.5 py-1 transition-colors duration-200 rounded-full ${showAllFaqs ? 'bg-[#001A7D] text-white shadow-sm' : 'text-slate-400'}`}>
                  All FAQs
                </span>
              </div>
            </div>

            {/* COMPACT BLUES ACCORDION GRID WITH HIGH-CONTRAST GOLD-ORANGE ACTIVE BORDERS */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {displayedFaqs.map((faq) => {
                const isOpen = openFaqQ === faq.q;
                return (
                  <div 
                    key={faq.q} 
                    className={`rounded-xl overflow-hidden transition-all duration-300 group shadow-sm border-2 ${
                      isOpen 
                        ? 'bg-[#001A7D] border-[#F2994A] shadow-[0_8px_20px_rgba(242,153,74,0.18)] scale-[1.01]' 
                        : 'bg-[#001A7D] border-[#001A7D] hover:border-[#F2994A]/60 hover:bg-[#0024B0] hover:shadow-md'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => toggleFaq(faq.q)}
                      className="w-full text-left px-4 py-3 flex items-center justify-between gap-3 cursor-pointer select-none focus:outline-none"
                    >
                      <span className="text-[11px] sm:text-xs font-bold text-white group-hover:text-amber-200 transition-colors duration-200 leading-snug">
                        {faq.q}
                      </span>
                      <ChevronDown 
                        className={`w-3.5 h-3.5 text-[#F2994A] shrink-0 transition-transform duration-350 ${
                          isOpen ? 'rotate-180 text-white' : 'rotate-0'
                        }`} 
                      />
                    </button>
                    
                    <div 
                      className={`transition-all duration-305 ease-in-out overflow-hidden ${
                        isOpen ? 'max-h-72 opacity-100 border-t-2 border-white/20' : 'max-h-0 opacity-0 pointer-events-none'
                      }`}
                    >
                      <div className="p-3.5 text-[11px] sm:text-xs text-white/90 leading-relaxed bg-[#030285]/55 font-medium">
                        {faq.a}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* FOOTER NAVIGATION & BOTTOM ACCREDITATIONS */}
      <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8">

        {/* LOGO BLOCK + REUSABLE COLUMNS IN HORIZONTAL FLOW */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pt-12 pb-0">
          {/* LOGO & SOCIO COLUMN */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2 cursor-pointer group" onClick={() => handleLinkClick('home')}>
              <img 
                src={fbsplLogo} 
                alt="FBSPL" 
                width="159"
                height="40"
                className="h-10 w-auto object-contain select-none transition-transform group-hover:scale-[1.02] brightness-0 invert" 
                style={{ filter: 'brightness(0) invert(1)' }}
                loading="lazy"
              />
            </div>
            
            <p className="text-sm text-white/80 leading-relaxed max-w-md">
              Fusion Business Solutions (P) Limited (FBSPL) is a leading B2B organization specializing in business process management and consulting. Since 2006, we’ve been streamlining operations and driving growth for businesses of all sizes.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/10 hover:bg-[#F29001] rounded-full text-white/90 hover:text-white transition-all duration-300" aria-label="Facebook">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/10 hover:bg-[#F29001] rounded-full text-white/90 hover:text-white transition-all duration-300" aria-label="Twitter">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/10 hover:bg-[#F29001] rounded-full text-white/90 hover:text-white transition-all duration-300" aria-label="YouTube">
                <Youtube className="w-4 h-4" />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/10 hover:bg-[#F29001] rounded-full text-white/90 hover:text-white transition-all duration-300" aria-label="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-white/10 hover:bg-[#F29001] rounded-full text-white/90 hover:text-white transition-all duration-300" aria-label="LinkedIn">
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* 4 REUSABLE LINKS COLS */}
          <div className="lg:col-span-8 grid grid-cols-2 md:grid-cols-4 gap-8">
            {/* COLUMN 1: About */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase text-white tracking-wider border-l-4 border-[#F29001] pl-2">
                About
              </h4>
              <ul className="space-y-2 text-xs">
                {['Who we are', 'Leadership', 'Social responsibility', 'Life at FBSPL', 'FBSPL at NetVU', 'Careers', 'Cookie Center'].map((link) => (
                  <li key={link}>
                    <button
                      onClick={() => handleLinkClick(
                        link === 'Careers' ? '/careers' : 
                        link === 'Cookie Center' ? '/cookie-portal' :
                        `/about/${link.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`
                      )}
                      className="hover:text-[#F2994A] text-white/80 transition text-left cursor-pointer"
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* COLUMN 2: Services */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase text-white tracking-wider border-l-4 border-[#F29001] pl-2">
                Services
              </h4>
              <ul className="space-y-2 text-xs">
                {[
                  { name: 'Insurance', val: 'insurance' },
                  { name: 'Accounting & Bookkeeping', val: 'accounting-bookkeeping' },
                  { name: 'Data Annotation', val: 'data-annotation' },
                  { name: 'Business Intelligence', val: 'business-intelligence' },
                  { name: 'Agency Optimization', val: 'agency-optimization' },
                  { name: 'Digital Marketing', val: 'digital-marketing' },
                  { name: 'AI Automation Services', val: 'ai-automation-services' }
                ].map((link) => (
                  <li key={link.name}>
                    <button
                      onClick={() => handleLinkClick(`/services/${link.val}`)}
                      className="hover:text-[#F2994A] text-white/80 transition text-left cursor-pointer"
                    >
                      {link.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* COLUMN 3: Resources */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase text-white tracking-wider border-l-4 border-[#F29001] pl-2">
                Resources
              </h4>
              <ul className="space-y-2 text-xs">
                {['Blogs', 'Client stories', 'Guides', 'Newsroom', 'Podcast', 'Events', 'Testimonials'].map((link) => (
                  <li key={link}>
                    <button
                      onClick={() => handleLinkClick(`/insights/${link.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`)}
                      className="hover:text-[#F2994A] text-white/80 transition text-left cursor-pointer"
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* COLUMN 4: Connect */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase text-white tracking-wider border-l-4 border-[#F29001] pl-2">
                Connect
              </h4>
              <ul className="space-y-2 text-xs">
                {[
                  { name: 'Book a consultation', val: 'consultation' },
                  { name: 'Contact Us', val: 'contact' },
                  { name: 'Terms & Condition', val: 'terms' },
                  { name: 'Sitemap', val: 'sitemap' },
                  { name: 'Privacy Policy', val: 'privacy' },
                  { name: 'Security Measures', val: 'security' },
                  { name: 'CSR Event', val: 'csr' },
                  { name: 'ISO 27001', val: 'iso-27001' },
                  { name: 'ISO 9001', val: 'iso-9001' }
                ].map((link) => (
                  <li key={link.name}>
                    <button
                      onClick={() => {
                        if (link.val === 'contact') {
                          const contactEl = document.getElementById('contact-form-section');
                          if (contactEl) {
                            contactEl.scrollIntoView({ behavior: 'smooth' });
                          }
                        } else {
                          handleLinkClick(`/connect/${link.val}`);
                        }
                      }}
                      className="hover:text-[#F2994A] text-white/80 transition text-left cursor-pointer"
                    >
                      {link.name}
                    </button>
                  </li>
                ))}
                <li className="pt-2 border-t border-white/20 mt-2">
                  <button
                    onClick={() => handleLinkClick('/careers')}
                    className="flex items-center gap-1.5 text-[#F2994A] hover:underline hover:text-[#F29001] font-extrabold text-xs cursor-pointer"
                  >
                    Careers (Work With Us) <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* BOTTOM BLOCK: CONTACT DETAILS & ACCREDITATIONS & LEGAL */}
        <div className="mt-8 pt-4 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-wrap justify-center md:justify-start gap-6 text-xs text-white/95 font-medium">
            <span className="flex items-center gap-1.5">
              <Mail className="w-4 h-4 text-[#F2994A]" /> solutions@fbspl.com
            </span>
            <span className="flex items-center gap-1.5">
              <Phone className="w-4 h-4 text-[#F2994A]" /> +1 (234) 567-8901
            </span>
          </div>

          {/* ISO Accreditations and Badges */}
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 rounded text-[10px] font-bold text-white tracking-wider border border-white/25">
              <Award className="w-3.5 h-3.5 text-[#F2994A]" /> ISO 27001:2013 SECURE
            </span>
            <span className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 rounded text-[10px] font-bold text-white tracking-wider border border-white/25">
              <Award className="w-3.5 h-3.5 text-[#F2994A]" /> ISO 9001:2015 QUALITY
            </span>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-white/20 relative flex flex-col sm:flex-row items-center justify-center min-h-[48px] gap-4">
          <p className="text-xs text-white/70 text-center px-12 mx-auto">© 2026 All Rights Reserved - Fusion Business Solutions (P) Limited</p>
          <div className="sm:absolute sm:left-0">
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="group p-3 bg-white/10 hover:bg-[#F29001] border border-white/20 hover:border-[#F29001] rounded-full text-white/95 shadow-lg transition-all duration-300 hover:scale-110 active:scale-95 flex items-center justify-center shrink-0 cursor-pointer"
              title="Scroll to Top"
              id="scroll-to-top-btn"
            >
              <ArrowUp className="w-4 h-4 transition-transform group-hover:-translate-y-0.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}
