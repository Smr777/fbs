import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini client with proper options specified in system instruction
  const apiKey = process.env.GEMINI_API_KEY;
  let ai: GoogleGenAI | null = null;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini API Client initialized successfully.");
  } else {
    console.warn("GEMINI_API_KEY environment variable is not defined - AI capabilities will return a warning.");
  }

  // API router endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      if (!ai) {
        return res.status(503).json({
          error: "Gemini API key is not configured on the server. Please define GEMINI_API_KEY in your environment settings/secrets."
        });
      }

      // System instruction as requested: answer in English on behalf of FBSPL
      const systemInstruction = 
        "You are 'FBSPL AI Assistant', a professional, friendly, and helpful virtual support assistant for FBSPL (Fusion Business Solutions (P) Limited).\n\n" +
        "Company Details:\n" +
        "- Fusion Business Solutions (P) Limited (FBSPL) is an international private limited company with over 19+ years of experience.\n" +
        "- Core Specialization: Business Process Management (BPM) and outsourcing services.\n" +
        "- It serves clients globally, providing virtual assistants, accounting support, data processing, recruiting assistance, and custom IT/automation solutions.\n\n" +
        "Guidelines:\n" +
        "1. You must answer all queries in English. Be concise, professional, warm, and corporate-aligned.\n" +
        "2. If a user asks how to start, request a consult, or get help with their specific business needs, suggest they use the 'Book a Consultation' link/button in the chat interface to take them directly to the Consultation Request Form in FBSPL Homepage.\n" +
        "3. If a user asks what services FBSPL offers, mention key services like Virtual Assistant, Accounting & Bookkeeping, Insurance Back-Office, Data Annotation & Mining, Recruitment Support, etc. Suggest they click 'View Our Services' to explore the services listing page.\n" +
        "4. Avoid making up numerical guarantees (other than the 19+ year metrics or standard SLA rates) or talking about internal server infrastructure.";

      // Structure contents with user/model roles for Gemini API format
      const contents = [];
      if (history && Array.isArray(history)) {
        for (const msg of history) {
          const role = msg.role === 'user' || msg.role === 'client' ? 'user' : 'model';
          contents.push({
            role: role,
            parts: [{ text: msg.text }]
          });
        }
      }
      contents.push({
        role: 'user',
        parts: [{ text: message }]
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contents,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.7,
        }
      });

      const responseText = response.text || "I apologize, I could not generate a response. Please rephrase or try again.";
      res.json({ reply: responseText });
    } catch (err: any) {
      console.error("Express /api/chat error:", err);
      res.status(500).json({ error: err.message || "An error occurred with the GenAI assistant" });
    }
  });

  // Vite development vs production asset serving middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite dev server middleware mounted.");
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log("Serving compiled production assets from dist.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
