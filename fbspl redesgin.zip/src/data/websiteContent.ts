// Static content for FBSPL website
import { 
  ServiceCategory, 
  ClientLogo, 
  WhyChooseUsItem, 
  ServiceItem, 
  TestimonialItem,
  InsightItem
} from '../types';

export const SERVICES_MENU: ServiceCategory[] = [
  {
    title: "Insurance Outsourcing",
    items: [
      { name: "New Business Setup", description: "Expedite quote preparation and policy setup." },
      { name: "Policy Processing", description: "Comprehensive policy checking and renewals." },
      { name: "Claims Management", description: "Optimize dispatch and notification processing." },
      { name: "Insurance Accounting", description: "Commission reconciliations and premium accounting." },
      { name: "Agency Consultation", description: "Maximize operational workflows of retail agencies." },
      { name: "Insurance Customer Support", description: "Dual-shore expert tier customer care." },
      { name: "Employee Benefits Support", description: "Manage group accounts and enrollment lifecycles." }
    ]
  },
  {
    title: "Accounting & Financial Consulting",
    items: [
      { name: "Payable Management", description: "Invoice processing, approvals, and dynamic auditing." },
      { name: "Receivable Management", description: "Maximize collections and dispatch billing statements." },
      { name: "Financial Reporting", description: "P&L compilations, balance sheets, and custom analytics." },
      { name: "Payroll Processing", description: "Salary disbursements, tax withholdings, and reporting." },
      { name: "Reconciliation Services", description: "Accurate bank, credit, and general ledger matching." },
      { name: "General Ledger Accounting", description: "Month-end closures and adjustments." }
    ]
  },
  {
    title: "Data Annotation",
    items: [
      { name: "Text Annotation", description: "NLP tagging, entity translation, and intent mapping." },
      { name: "Video Annotation", description: "Dynamic bounding boxes and pixel-level tracking." },
      { name: "Image Annotation", description: "Semantic segmentation, polygons, and key-points." },
      { name: "Audio Annotation", description: "Phonetic transcripts and audio file labeling." },
      { name: "Synthetic Data Generation", description: "Seed training sets engineered for deep models." }
    ]
  },
  {
    title: "Digital Marketing",
    items: [
      { name: "Content Marketing", description: "Engage targets with articles, guides, and visual content." },
      { name: "Graphic Designing", description: "Premium UI materials, branding vectors, and print layouts." },
      { name: "SEO Services", description: "Boost search engine visibility and capture organic intent." },
      { name: "UI/UX Designing", description: "Develop modern, high-fidelity user flows and web views." },
      { name: "Paid Marketing", description: "Targeted PPC, social ads, and performance audits." },
      { name: "Social Media Marketing", description: "Drive engagement and build loyal digital communities." }
    ]
  },
  {
    title: "Business Intelligence",
    items: [
      { name: "Data Warehousing", description: "Unify business logs into highly accessible structures." },
      { name: "Custom Dashboards", description: "Visualize core operations through real-time telemetry." },
      { name: "Predictive Analytics", description: "Determine future volumes and customer behaviors." }
    ]
  },
  {
    title: "AI Automation Services",
    items: [
      { 
        name: "Data Intelligence Platform", 
        description: "Transform fragmented business data into a unified, actionable asset. Enable seamless data collection, integration, governance, and quality management to support faster and more informed decision-making." 
      },
      { 
        name: "Business Intelligence & Analytics", 
        description: "Convert operational data into meaningful insights through real-time reporting, predictive analytics, and performance monitoring. Empower leadership teams with visibility into key business metrics and trends." 
      },
      { 
        name: "Document Intelligence", 
        description: "Automate the extraction, classification, and processing of business documents using AI. Reduce manual effort, improve accuracy, and accelerate document-driven workflows across the organization." 
      },
      { 
        name: "Customer Experience AI", 
        description: "Enhance customer engagement with intelligent support, conversational AI, and personalized interactions. Deliver faster resolutions, improved satisfaction, and consistent experiences across all channels." 
      },
      { 
        name: "Workflow Automation Platform", 
        description: "Streamline complex business processes through intelligent workflow orchestration and automation. Eliminate repetitive tasks, improve operational efficiency, and increase organizational productivity." 
      },
      { 
        name: "Knowledge Management AI", 
        description: "Unlock the value of enterprise knowledge through AI-powered search, discovery, and information retrieval. Help teams access critical information instantly and make better decisions with confidence." 
      },
      { 
        name: "AI Agents & Copilots", 
        description: "Deploy intelligent AI assistants that support employees, automate routine activities, and enhance decision-making. Increase productivity by augmenting teams with specialized AI-driven capabilities." 
      },
      { 
        name: "Training Data & Annotation Platform", 
        description: "Accelerate AI model development with scalable data annotation, validation, and dataset management solutions. Ensure high-quality training data that improves model accuracy and performance." 
      }
    ]
  }
];

export const CLIENT_LOGOS: ClientLogo[] = [
  { name: "All Care Consultants, Inc", color: "#001A7D", fallbackLogo: "All Care" },
  { name: "Alternative Claim Management", color: "#002CCE", fallbackLogo: "ACM" },
  { name: "Chapman Insurance Group", color: "#030285", fallbackLogo: "Chapman" },
  { name: "CRS Insurance Brokerage", color: "#001A7D", fallbackLogo: "CRS" },
  { name: "CHRP", color: "#002CCE", fallbackLogo: "chrp" },
  { name: "Western Gold Insurance Agency", color: "#030285", fallbackLogo: "Western Gold" }
];

export const WHY_CHOOSE_US: WhyChooseUsItem[] = [
  {
    id: "support",
    title: "AI + Human = Sustainable Scale",
    description: "A deliberate synergy of modern AI automation engines and senior human domain oversight ensuring 99.8% precision.",
    iconName: "support"
  },
  {
    id: "form",
    title: "Your Workflows, Your Time Zone",
    description: "Dedicated operational units custom-configured to your tech stack and 100% synchronized with your local business hours.",
    iconName: "form"
  },
  {
    id: "domain",
    title: "All-in-One Multi-Tier Continuity",
    description: "Enterprise-grade business continuity supported by cross-trained standby teams to guarantee uninterrupted throughput.",
    iconName: "domain"
  },
  {
    id: "scope",
    title: "Client-First Strategic Partnership",
    description: "We operate as an agile, long-term extension of your leadership team, proactively driving margin optimization.",
    iconName: "scope"
  }
];

export const SERVICES_SERVICES: ServiceItem[] = [
  {
    id: "insurance",
    title: "Insurance Outsourcing & Agency Operations",
    description: "Accelerate revenue growth from policy processing, loss run auditing, and COI issuance to full claims lifecycle management.",
    href: "/services/insurance"
  },
  {
    id: "accounting",
    title: "Accounting & Financial Consultancy",
    description: "Audit-ready financial management, advisory consulting, AP/AR automation, and multi-entity ledger reconciliations designed for modern growth enterprises.",
    href: "/services/accounting"
  },
  {
    id: "annotation",
    title: "Data Annotation & Human-in-the-Loop AI",
    description: "High-precision computer vision, LiDAR, NLP, and multimodal dataset labeling to fuel production-grade AI/ML models.",
    href: "/services/annotation"
  },
  {
    id: "bi",
    title: "Business Intelligence & Data Analytics",
    description: "Transform fragmented data silos into real-time operational executive dashboards and predictive revenue intelligence.",
    href: "/services/bi"
  },
  {
    id: "marketing",
    title: "Digital Marketing & Brand Operations",
    description: "Full-funnel organic search, technical copywriting, conversion optimization, and brand authority campaigns that deliver measurable ROI.",
    href: "/services/marketing"
  },
  {
    id: "ai",
    title: "AI Automation & Enterprise Copilots",
    description: "Deploy intelligent workflow orchestrators, document intelligence pipelines, and custom copilots to eliminate operational latency.",
    href: "/services/ai-automation-services"
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: "t1",
    text: "FBSPL has transformed how we handle policy processing. Their team is reliable, fast, and operates seamlessly within our US time zone. They have reduced our administrative overhead while elevating audit quality.",
    author: "Richard Chapman",
    position: "Managing Partner",
    company: "Chapman Insurance Group",
    rating: 5
  },
  {
    id: "t2",
    text: "The accounting and financial consultancy support we receive is world-class. They are meticulous, proactive, and understand the US regulatory and GAAP framework inside and out.",
    author: "Elena Sorokina",
    position: "Director of Accounts",
    company: "All Care Consultants, Inc",
    rating: 5
  },
  {
    id: "t3",
    text: "We utilized their Data Annotation specialists for our autonomous driving telemetry pipeline. The precision of their bounding boxes and semantic segmentation surpassed our strict internal benchmarks.",
    author: "Alex Rivers",
    position: "VP of Artificial Intelligence",
    company: "chrp",
    rating: 5
  },
  {
    id: "t4",
    text: "Partnering with FBSPL streamlined our claims management lifecycle. Turnaround times dropped from 5 business days to under 24 hours. They are an indispensable operations partner.",
    author: "Thomas Wright",
    position: "Chief Operations Officer",
    company: "Alternative Claim Management",
    rating: 5
  },
  {
    id: "t5",
    text: "Highly adaptive and thoroughly professional. Their dual-shored delivery model keeps our client support desk active 24/7/365 with flawless SLA adherence.",
    author: "Sarah Jenkins",
    position: "General Manager",
    company: "Western Gold Insurance Agency",
    rating: 5
  },
  {
    id: "t6",
    text: "Our monthly ledger reconciliations were a persistent bottleneck. FBSPL engineered standardized SOPs, automated checks, and took over daily processing. Full visibility is back in our hands.",
    author: "Marcus Vance",
    position: "Financial Controller",
    company: "CRS Insurance Brokerage",
    rating: 5
  }
];

export const BRIEF_INSIGHTS = {
  caseStudies: [
    {
      id: "cs1",
      title: "How a Leading US Insurance Brokerage Reduced Policy Audit Time by 60%",
      snippet: "Discover the specialized validation framework and AMS automation pipelines integrated to accelerate renewal reviews while cutting manual operating expenses in half.",
      readTime: "6 min read",
      date: "May 2026",
      category: "Case Studies"
    },
    {
      id: "cs2",
      title: "Scaling Financial Consultancy & AP/AR for a High-Volume Multi-Entity Enterprise",
      snippet: "How FBSPL restructured cashflow workflows and ledger reconciliations to absorb a 300% surge in transaction volume without expanding in-house administrative headcount.",
      readTime: "8 min read",
      date: "Apr 2026",
      category: "Case Studies"
    }
  ],
  clientStories: [
    {
      id: "s1",
      title: "Chapman Insurance Group: Accelerating Rapid Claims Throughput",
      snippet: "Chapman Group wanted to elevate client satisfaction ratings during peak hurricane seasons. Our standby processing team eliminated backlogs with sub-24-hour turnaround.",
      readTime: "5 min read",
      date: "May 2026",
      category: "Client Stories"
    },
    {
      id: "s2",
      title: "Transitioning to 24/7 Omni-Channel Operations with Western Gold",
      snippet: "How a hybrid AI + expert human virtual desk enabled continuous coverage assistance for policyholders across multiple time zones, generating a 30% revenue expansion.",
      readTime: "7 min read",
      date: "Mar 2026",
      category: "Client Stories"
    }
  ],
  podcasts: [
    {
      id: "p1",
      title: "Episode 45: The AI + Human-in-the-Loop Operational Engine",
      snippet: "Our executive leadership sits down with industry analysts to discuss why standalone AI workflows fail without domain-trained human verification.",
      readTime: "24 min listen",
      date: "May 2026",
      category: "Podcast"
    },
    {
      id: "p2",
      title: "Episode 46: Accelerating Growth with Time-Zone Aligned Dual Shoring",
      snippet: "Learn how modern global enterprises leverage 100% real-time operational schedule overlap to maintain continuity and instant responsiveness across borders.",
      readTime: "18 min listen",
      date: "May 2026",
      category: "Podcast"
    }
  ],
  events: [
    {
      id: "e1",
      title: "FBSPL at NetVU Annual Conference 2026",
      snippet: "Join our insurance BPO leadership live as they demonstrate practical agency workflow optimization and AMS automation blueprints.",
      readTime: "Conference",
      date: "June 2026",
      category: "Events"
    }
  ],
  blogs: [
    {
      id: "b1",
      title: "5 Critical Outsourcing Pitfalls Global Enterprises Must Avoid in 2026",
      snippet: "Operational leaders analyze key factors for seamless offshore transitions, focusing on governance, process documentation, and cultural alignment.",
      readTime: "5 min read",
      date: "May 2026",
      category: "Blogs"
    },
    {
      id: "b2",
      title: "The Enterprise Guide to Human-in-the-Loop Security & Compliance",
      snippet: "A detailed breakdown of best practices for maintaining continuous ISO 27001, SOC-2, and GDPR compliance when scaling data operations.",
      readTime: "6 min read",
      date: "Apr 2026",
      category: "Blogs"
    }
  ]
};
