import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Cookie, X, Settings, Shield, BarChart3, Sliders, Target, Check } from 'lucide-react';
import { collection, doc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

interface CookiePreferences {
  essential: boolean;
  performanceAnalytics: boolean; // Track site usage to improve performance
  functional: boolean; // Remember user preferences
  targetingAdvertising: boolean; // Build user profiles to deliver personalized ads
}

// SECURE COOKIE HELPER FUNCTIONS WITH CLIENT-SIDE SECURITY MEASURES
// 1. Secure: Ensures cookies are only transmitted over secure HTTPS connections.
// 2. SameSite=Strict: Restricts cross-site request forgery risks by not sending cookies on cross-origin requests.
// Note on HttpOnly: "HttpOnly" is a server-side Set-Cookie header option. Since this React UI needs to read 
// cookie consent state client-side to decide whether to hide the popup dynamically, it cannot be HttpOnly.
// If the application had sensitive session IDs or auth tokens, those would be set by the server as HttpOnly.
function setSecureCookie(name: string, value: string, days?: number) {
  let expires = "";
  if (days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    expires = "; expires=" + date.toUTCString();
  }
  document.cookie = `${name}=${encodeURIComponent(value)}${expires}; path=/; Secure; SameSite=Strict`;
}

function getSecureCookie(name: string): string | null {
  const nameEQ = name + "=";
  const ca = document.cookie.split(';');
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) === 0) {
      return decodeURIComponent(c.substring(nameEQ.length, c.length));
    }
  }
  return null;
}

function eraseSecureCookie(name: string) {
  document.cookie = `${name}=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT; Secure; SameSite=Strict`;
}

// Robust logger to capture consent configuration and push telemetry to Firestore database synchronously.
async function logCookieConsentToFirebase(consentStatus: 'accepted' | 'declined' | 'custom', prefs: CookiePreferences) {
  try {
    const cleanId = 'consent_' + Math.floor(Math.random() * 100000) + '_' + Date.now();
    await setDoc(doc(db, 'cookie_consents', cleanId), {
      consentId: cleanId,
      acceptedAt: new Date().toISOString(),
      essential: true,
      performanceAnalytics: prefs.performanceAnalytics,
      functional: prefs.functional,
      targetingAdvertising: prefs.targetingAdvertising,
      consentStatus,
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent.substring(0, 990) : 'Unknown_UA'
    });
    // Trigger custom window event to allow reactive lists on the page to automatically update
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('fbspl_consent_updated'));
    }
  } catch (err) {
    console.warn('Firebase sync offline or local-only deployment bypass:', err);
  }
}

export default function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [preferences, setPreferences] = useState<CookiePreferences>({
    essential: true,
    performanceAnalytics: true,
    functional: true,
    targetingAdvertising: false // Explicit, opt-in consent (defaults to false)
  });
  const [hasScrolledPastAbout, setHasScrolledPastAbout] = useState(false);

  // Check scroll position to trigger popup after "About Us" section is scrolled into or past
  useEffect(() => {
    // Check if user already consented (accepted or custom) via our secure cookies
    const consent = getSecureCookie('fbspl_cookie_consent');
    if (consent === 'accepted' || consent === 'custom') {
      // Consent already exists, so don't show the banner
      return;
    }

    const handleScroll = () => {
      // Find the about us section element
      const aboutElement = document.getElementById('about-us-section') || document.querySelector('[ref="aboutSecRef"]') || document.getElementById('about-video-container');
      
      if (aboutElement) {
        const rect = aboutElement.getBoundingClientRect();
        if (rect.top < window.innerHeight) {
          setHasScrolledPastAbout(true);
        }
      } else {
        // Fallback: If elements aren't immediately targetable, trigger after scrolling 600px
        if (window.scrollY > 600) {
          setHasScrolledPastAbout(true);
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Delay trigger slightly after meeting scroll condition
  useEffect(() => {
    if (hasScrolledPastAbout) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [hasScrolledPastAbout]);

  // Dispatch custom event to notify other components (like AIChatBot) to shift layouts dynamically
  useEffect(() => {
    const event = new CustomEvent('fbspl_cookie_visible', { detail: { visible: isVisible } });
    window.dispatchEvent(event);
    
    // Also dispatch on cleanup if component unmounts
    return () => {
      window.dispatchEvent(new CustomEvent('fbspl_cookie_visible', { detail: { visible: false } }));
    };
  }, [isVisible]);

  const handleAcceptAll = () => {
    setSecureCookie('fbspl_cookie_consent', 'accepted', 365);
    const prefs = {
      essential: true,
      performanceAnalytics: true,
      functional: true,
      targetingAdvertising: true
    };
    setSecureCookie('fbspl_cookie_preferences', JSON.stringify(prefs), 365);
    logCookieConsentToFirebase('accepted', prefs);
    setIsVisible(false);
  };

  const handleDeclineAll = () => {
    eraseSecureCookie('fbspl_cookie_consent');
    eraseSecureCookie('fbspl_cookie_preferences');
    const prefs = {
      essential: true,
      performanceAnalytics: false,
      functional: false,
      targetingAdvertising: false
    };
    logCookieConsentToFirebase('declined', prefs);
    setIsVisible(false);
  };

  const handleSavePreferences = () => {
    setSecureCookie('fbspl_cookie_consent', 'custom', 365);
    setSecureCookie('fbspl_cookie_preferences', JSON.stringify(preferences), 365);
    logCookieConsentToFirebase('custom', preferences);
    setIsVisible(false);
  };

  const togglePreference = (key: keyof CookiePreferences) => {
    if (key === 'essential') return;
    setPreferences(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          id="cookie-consent-popup"
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100, transition: { duration: 0.25 } }}
          transition={{ 
            type: "spring",
            damping: 28,
            stiffness: 190,
            mass: 0.95
          }}
          className="fixed bottom-0 left-0 right-0 z-50 w-full bg-[#00104E] text-white border-t border-white/10 shadow-[0_-12px_45px_rgba(0,18,90,0.22)] select-none overflow-hidden"
        >
          {/* Subtle design element */}
          <div className="absolute top-0 right-0 w-64 h-full bg-[#002CCE]/10 skew-x-12 pointer-events-none" />

          <div className="max-w-[1720px] mx-auto px-4 sm:px-6 md:px-8 pt-3 pb-3 md:py-2 md:ml-[97px] relative">
            <div className="flex flex-col lg:flex-row items-center justify-between gap-4 md:gap-6">
              
              {/* Info segment */}
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-3.5 max-w-4xl w-full">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white shrink-0 sm:mt-1 border border-white/10 shadow-sm">
                  <Cookie className="w-5.5 h-5.5 text-amber-300 animate-pulse" />
                </div>
                <div className="space-y-1.5 text-center sm:text-left flex-1">
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                    <h5 className="font-black text-[11px] text-white tracking-widest uppercase">
                      Cookie Consent Policy
                    </h5>
                    <span className="bg-amber-400/25 text-amber-300 text-[9px] font-black tracking-wider uppercase px-2 py-0.5 rounded-full border border-amber-400/20">
                      GDPR & CCPA
                    </span>
                  </div>
                  <p className="text-[11px] sm:text-xs leading-relaxed text-white/80 font-medium text-center sm:text-left">
                    At FBSPL, we use secure analytics, performance-tracking, and personalization cookies to ensure seamless navigation, preserve custom settings, and analyze site traffic to deliver a fully optimized enterprise experience. Under privacy legislation, you may choose your data preferences.
                  </p>
                </div>
              </div>
              
              {/* Action Buttons Zone */}
              <div className="flex flex-wrap items-center justify-center lg:justify-end gap-2.5 shrink-0 w-full lg:w-auto">
                <button
                  type="button"
                  onClick={() => setShowPreferences(!showPreferences)}
                  className="flex items-center gap-1 bg-white/5 hover:bg-white/15 text-white/90 hover:text-white border border-white/15 py-2.5 px-4 rounded-xl text-[10px] font-extrabold transition-all duration-300 uppercase tracking-widest cursor-pointer"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>Customize</span>
                </button>
                <button
                  type="button"
                  onClick={handleDeclineAll}
                  className="bg-white/5 hover:bg-white/10 text-white/80 hover:text-white border border-white/5 py-2.5 px-4 rounded-xl text-[10px] font-extrabold transition-all duration-300 uppercase tracking-widest cursor-pointer"
                >
                  Ignore All
                </button>
                <button
                  type="button"
                  onClick={handleAcceptAll}
                  className="bg-[#F29001] hover:bg-[#ff9c0d] text-white py-2.5 px-5.5 rounded-xl text-[10px] font-black transition-all duration-300 scale-100 hover:scale-105 active:scale-95 uppercase tracking-widest cursor-pointer shadow-lg shadow-[#F29001]/10"
                >
                  Accept & Save
                </button>
              </div>

            </div>

            {/* PREFERENCES PANEL INTERNALLY EXPANDED */}
            <AnimatePresence>
              {showPreferences && (
                <motion.div
                  initial={{ opacity: 0, height: 0, marginTop: 0 }}
                  animate={{ opacity: 1, height: "auto", marginTop: 20 }}
                  exit={{ opacity: 0, height: 0, marginTop: 0 }}
                  className="border-t border-white/10 pt-4 overflow-hidden"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h6 className="font-extrabold text-[10px] uppercase text-white/60 tracking-wider">Configure Custom Permissions</h6>
                    <button 
                      type="button"
                      onClick={() => setShowPreferences(false)}
                      className="text-[10px] font-extrabold text-amber-400 hover:underline cursor-pointer"
                    >
                      Close Panel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
                    {/* 1. Essential Option */}
                    <div className="flex items-start justify-between p-3 rounded-xl bg-white/5 border border-white/5 text-left">
                      <div className="flex flex-col pr-3">
                        <span className="text-[11px] font-extrabold text-white flex items-center gap-1.5 uppercase tracking-wider">
                          <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          Strictly Necessary
                        </span>
                        <span className="text-[10px] text-white/60 mt-1 leading-tight">
                          Essential security, CSRF defense, and user session management.
                        </span>
                      </div>
                      <Check className="w-3.5 h-3.5 text-emerald-400 mt-1 shrink-0" />
                    </div>

                    {/* 2. Performance & Analytics Option */}
                    <div 
                      onClick={() => togglePreference('performanceAnalytics')}
                      className="flex items-start justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:border-white/15 transition-all cursor-pointer text-left"
                    >
                      <div className="flex flex-col pr-3">
                        <span className="text-[11px] font-extrabold text-white flex items-center gap-1.5 uppercase tracking-wider">
                          <BarChart3 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          Performance & Metrics
                        </span>
                        <span className="text-[10px] text-white/60 mt-1 leading-tight">
                          Monitors application metrics & speeds. Your IP is anonymous.
                        </span>
                      </div>
                      <div className={`w-7 h-4 rounded-full p-0.5 transition-colors duration-200 shrink-0 mt-1 ${preferences.performanceAnalytics ? 'bg-emerald-400' : 'bg-white/10'}`}>
                        <div className={`w-3 h-3 bg-slate-900 rounded-full transition-transform duration-200 transform ${preferences.performanceAnalytics ? 'translate-x-3' : 'translate-x-0'}`} />
                      </div>
                    </div>

                    {/* 3. Functional Option */}
                    <div 
                      onClick={() => togglePreference('functional')}
                      className="flex items-start justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:border-white/15 transition-all cursor-pointer text-left"
                    >
                      <div className="flex flex-col pr-3">
                        <span className="text-[11px] font-extrabold text-white flex items-center gap-1.5 uppercase tracking-wider">
                          <Sliders className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                          Functional Choices
                        </span>
                        <span className="text-[10px] text-white/60 mt-1 leading-tight">
                          Saves custom support sessions and menu status across tabs.
                        </span>
                      </div>
                      <div className={`w-7 h-4 rounded-full p-0.5 transition-colors duration-200 shrink-0 mt-1 ${preferences.functional ? 'bg-emerald-400' : 'bg-white/10'}`}>
                        <div className={`w-3 h-3 bg-slate-900 rounded-full transition-transform duration-200 transform ${preferences.functional ? 'translate-x-3' : 'translate-x-0'}`} />
                      </div>
                    </div>

                    {/* 4. Targeting / Advertising Option */}
                    <div 
                      onClick={() => togglePreference('targetingAdvertising')}
                      className="flex items-start justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:border-white/15 transition-all cursor-pointer text-left"
                    >
                      <div className="flex flex-col pr-3">
                        <span className="text-[11px] font-extrabold text-white flex items-center gap-1.5 uppercase tracking-wider">
                          <Target className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                          Targeting & Marketing
                        </span>
                        <span className="text-[10px] text-white/60 mt-1 leading-tight">
                          We display curated, highly secure news updates for corporate clients.
                        </span>
                      </div>
                      <div className={`w-7 h-4 rounded-full p-0.5 transition-colors duration-200 shrink-0 mt-1 ${preferences.targetingAdvertising ? 'bg-emerald-400' : 'bg-white/10'}`}>
                        <div className={`w-3 h-3 bg-slate-900 rounded-full transition-transform duration-200 transform ${preferences.targetingAdvertising ? 'translate-x-3' : 'translate-x-0'}`} />
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap justify-center sm:justify-end gap-2.5 mt-4 w-full">
                    <button
                      type="button"
                      onClick={() => setShowPreferences(false)}
                      className="bg-white/10 hover:bg-white/15 text-white/80 hover:text-white py-2 px-4 rounded-xl text-[10px] font-extrabold uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleSavePreferences}
                      className="bg-amber-400 hover:bg-amber-550 text-slate-950 py-2 px-4.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all duration-300 transform active:scale-95 cursor-pointer shadow-md"
                    >
                      Save Configuration
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

