import React, { useRef, useEffect, useState } from 'react';
import { Globe, ArrowLeftRight, HelpCircle } from 'lucide-react';

interface Point3D {
  x: number;
  y: number;
  z: number;
  color?: string;
  name?: string;
  labelPosition?: 'left' | 'right' | 'top' | 'bottom';
}

export default function InteractiveEarth() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const currentAngle = useRef({ x: 0.3, y: 1.2 });

  // List of major corporate nodes of FBSPL and global synergy partners
  const locations: Point3D[] = [
    // Projected 3D spherical coordinates: x^2 + y^2 + z^2 = R^2
    // Let's model geographic points (approx. lat/long mapped to sphere)
    { ...getSphereCoords(20, 75), name: 'India Hub (Udaipur)', color: '#F29001', labelPosition: 'right' },
    { ...getSphereCoords(38, -97), name: 'US Head Office', color: '#002CCE', labelPosition: 'left' },
    { ...getSphereCoords(55, -2), name: 'UK Synergy Center', color: '#F29001', labelPosition: 'top' },
    { ...getSphereCoords(34, 138), name: 'APAC Client Relations', color: '#002CCE', labelPosition: 'right' },
    { ...getSphereCoords(-25, 133), name: 'Australia Operations', color: '#F29001', labelPosition: 'bottom' },
    { ...getSphereCoords(-30, -55), name: 'South America Support', color: '#002CCE', labelPosition: 'left' },
  ];

  // Helper to map Latitude & Longitude to 3D Sphere of Radius 1
  function getSphereCoords(lat: number, lon: number): { x: number; y: number; z: number } {
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lon + 180) * (Math.PI / 180);
    return {
      x: -(Math.sin(phi) * Math.sin(theta)),
      y: Math.cos(phi),
      z: Math.sin(phi) * Math.cos(theta),
    };
  }

  // Handle Drag / Rotate events
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStart.current.x;

    // Adjust sensitivity factors (only capture horizontal drag to rotate sideways)
    const sensitivity = 0.007;
    const targetY = currentAngle.current.y + dx * sensitivity;

    // Keep X fixed at 0.3 radians to lock the poles securely in place
    currentAngle.current = { x: 0.3, y: targetY };
    dragStart.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUpOrLeave = () => {
    setIsDragging(false);
  };

  // Touch triggers for mobile optimization
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      dragStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return;
    const dx = e.touches[0].clientX - dragStart.current.x;

    const sensitivity = 0.009;
    const targetY = currentAngle.current.y + dx * sensitivity;

    // Keep X fixed at 0.3 radians to lock the poles securely in place
    currentAngle.current = { x: 0.3, y: targetY };
    dragStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let autoRotationSpeed = 0.0025;

    const resizeCanvas = () => {
      const container = containerRef.current;
      if (container) {
        // High density dynamic width resolution
        const size = Math.min(container.clientWidth, 400);
        canvas.width = size * window.devicePixelRatio;
        canvas.height = size * window.devicePixelRatio;
        canvas.style.width = `${size}px`;
        canvas.style.height = `${size}px`;
        ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const size = canvas.width / window.devicePixelRatio;
      const radius = size * 0.38;
      const cx = size / 2;
      const cy = size / 2;

      // Auto-rotate if not holding drag trigger
      if (!isDragging) {
        currentAngle.current.y += autoRotationSpeed;
      }

      // Keep X tilt fixed at exactly 0.3 for a beautiful, static pole view
      const rotX = 0.3;
      const rotY = currentAngle.current.y;

      const cosX = Math.cos(rotX);
      const sinX = Math.sin(rotX);
      const cosY = Math.cos(rotY);
      const sinY = Math.sin(rotY);

      // Global coordinates projection function
      const project = (pt: Point3D) => {
        // Rotate around Y axis (sideways rotation)
        let x1 = pt.x * cosY - pt.z * sinY;
        let z1 = pt.x * sinY + pt.z * cosY;

        // Rotate around X axis (subtle vertical tilt, fixed poles)
        let y2 = pt.y * cosX - z1 * sinX;
        let z2 = pt.y * sinX + z1 * cosX;

        // Orthographic projection ensures no point coordinates ever exceed the boundary circle radius
        return {
          px: cx + x1 * radius,
          py: cy - y2 * radius,
          visible: z2 > 0.08, // Draw elements that face the front hemisphere
          depth: z2,
        };
      };

      // Draw Atmospheric Space Halo Backing glow
      const radialGlow = ctx.createRadialGradient(cx, cy, radius * 0.8, cx, cy, radius * 1.3);
      radialGlow.addColorStop(0, 'rgba(0, 44, 206, 0.12)');
      radialGlow.addColorStop(0.6, 'rgba(0, 26, 125, 0.05)');
      radialGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = radialGlow;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 1.3, 0, Math.PI * 2);
      ctx.fill();

      // Draw Earth Outer Ring Border Blueprint Outline
      ctx.strokeStyle = 'rgba(0, 44, 206, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.stroke();

      // Save context to apply a strict circular clipping path (ensures zero outline leakage)
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.clip();

      // Draw beautiful Latitude rings
      ctx.strokeStyle = 'rgba(0, 44, 206, 0.15)';
      ctx.lineWidth = 0.8;
      for (let lat = -60; lat <= 60; lat += 20) {
        ctx.beginPath();
        const segments = 60;
        let first = true;
        for (let i = 0; i <= segments; i++) {
          const lon = (i / segments) * 360 - 180;
          const pt = getSphereCoords(lat, lon);
          const { px, py, visible } = project(pt);
          if (visible) {
            if (first) {
              ctx.moveTo(px, py);
              first = false;
            } else {
              ctx.lineTo(px, py);
            }
          } else {
            first = true;
          }
        }
        ctx.stroke();
      }

      // Draw beautiful Longitude rings
      for (let lon = -180; lon < 180; lon += 30) {
        ctx.beginPath();
        const segments = 60;
        let first = true;
        for (let i = 0; i <= segments; i++) {
          const lat = (i / segments) * 180 - 90;
          const pt = getSphereCoords(lat, lon);
          const { px, py, visible } = project(pt);
          if (visible) {
            if (first) {
              ctx.moveTo(px, py);
              first = false;
            } else {
              ctx.lineTo(px, py);
            }
          } else {
            first = true;
          }
        }
        ctx.stroke();
      }

      // Draw Synergy Arc Lines between US and India/UK (MNC pathways)
      const pairs = [
        [0, 1], // India -> US
        [0, 2], // India -> UK
        [1, 2], // US -> UK
        [1, 3], // US -> APAC
        [0, 4], // India -> Australia
      ];

      ctx.lineWidth = 1.2;
      pairs.forEach(([i1, i2]) => {
        const pt1 = project(locations[i1]);
        const pt2 = project(locations[i2]);

        if (pt1.visible && pt2.visible) {
          // Semi-curved arc calculation
          const midX = (pt1.px + pt2.px) / 2;
          const midY = (pt1.py + pt2.py) / 2;
          const dx = pt2.px - pt1.px;
          const dy = pt2.py - pt1.py;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          const bendX = midX - (dy / dist) * (dist * 0.22);
          const bendY = midY + (dx / dist) * (dist * 0.22);

          // Render connecting synergy gradient lines with dashed animations
          ctx.beginPath();
          ctx.moveTo(pt1.px, pt1.py);
          ctx.quadraticCurveTo(bendX, bendY, pt2.px, pt2.py);
          
          const isIndiaInvolved = i1 === 0 || i2 === 0;
          ctx.strokeStyle = isIndiaInvolved ? 'rgba(242, 144, 1, 0.45)' : 'rgba(0, 44, 206, 0.35)';
          ctx.setLineDash([3, 4]);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      });

      // Restore clipping context to allow clean presentation of dots and texts beyond edge boundaries
      ctx.restore();

      // Project and render Corporate City nodes with pulsing halos
      locations.forEach((node) => {
        const { px, py, visible, depth } = project(node);
        if (!visible) return;

        // Size adapts slightly based on 3D depth perspective
        const dotSize = Math.max(3.5, 6.5 * (1 - depth * 0.35));

        // Pulsing circle highlight logic
        const pulseRatio = (Date.now() % 1600) / 1600;
        ctx.beginPath();
        ctx.arc(px, py, dotSize * (1 + pulseRatio * 1.5), 0, Math.PI * 2);
        ctx.fillStyle = node.color === '#F29001' 
          ? `rgba(242, 144, 1, ${0.45 * (1 - pulseRatio)})` 
          : `rgba(0, 44, 206, ${0.45 * (1 - pulseRatio)})`;
        ctx.fill();

        // Solid central nodes
        ctx.beginPath();
        ctx.arc(px, py, dotSize, 0, Math.PI * 2);
        ctx.fillStyle = node.color || '#F29001';
        ctx.fill();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1;
        ctx.stroke();

        // Node name tag text overlay
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.font = 'bold 9px sans-serif';
        const textWidth = ctx.measureText(node.name || '').width;

        // Positioning logic based on preset guidelines
        let tx = px + 8;
        let ty = py + 3;
        if (node.labelPosition === 'left') {
          tx = px - textWidth - 10;
        } else if (node.labelPosition === 'top') {
          tx = px - textWidth / 2;
          ty = py - 10;
        } else if (node.labelPosition === 'bottom') {
          tx = px - textWidth / 2;
          ty = py + 14;
        }

        // Drop shadow for text readability
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.fillText(node.name || '', tx + 1, ty + 1);
        ctx.fillStyle = node.color === '#F29001' ? '#D97706' : '#0F2CBE';
        ctx.fillText(node.name || '', tx, ty);
      });

      // Mini compass axis graphic in top left corner of canvas
      ctx.strokeStyle = 'rgba(0, 44, 206, 0.2)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(28, 28, 12, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(28, 20); ctx.lineTo(28, 36);
      ctx.moveTo(20, 28); ctx.lineTo(36, 28);
      ctx.stroke();

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [isDragging]);

  return (
    <div className="relative group w-full flex flex-col items-center justify-center p-3 sm:p-5 bg-gradient-to-br from-lavender/45 via-blue-50/20 to-white dark:to-transparent rounded-3xl border border-gray-150/85 shadow-sm transition hover:shadow-md">
      <div 
        ref={containerRef} 
        className="relative w-full flex justify-center items-center cursor-grab active:cursor-grabbing overflow-hidden h-[300px] sm:h-[320px]"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUpOrLeave}
        onMouseLeave={handleMouseUpOrLeave}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUpOrLeave}
      >
        <canvas ref={canvasRef} className="block select-none pointer-events-none" />
        
        {/* Helper overlay instruction sign */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-white/90 dark:bg-slate-900/90 text-[8px] font-bold tracking-widest text-[#001A7D] dark:text-white uppercase px-3 py-1.5 rounded-full border border-gray-100 flex items-center gap-1.5 opacity-75 group-hover:opacity-100 transition-opacity duration-300">
          <ArrowLeftRight className="w-2.5 h-2.5 text-[#F29001] animate-pulse" />
          <span>DRAG OR SWIPE GLOBE TO ROTATE</span>
        </div>
      </div>

      <div className="mt-2 w-full text-center px-4 space-y-1">
        <div className="flex items-center justify-center gap-2">
          <Globe className="w-4 h-4 text-[#F29001]" />
          <h5 className="text-[11px] font-extrabold tracking-widest text-[#001A7D] uppercase">Dual-Shore Synergy Matrix</h5>
        </div>
        <p className="text-[10px] text-gray-500 font-medium">
          Interactively rotate to view our worldwide delivery nodes bridging USA, Europe, UK & Udaipur Hubs.
        </p>
      </div>
    </div>
  );
}
