import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Sparkles, AlertCircle, Bot, BookOpen, Calendar, HelpCircle } from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

interface AIChatBotProps {
  onBookConsultation: () => void;
  onViewServices: () => void;
}

export default function AIChatBot({ onBookConsultation, onViewServices }: AIChatBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [hasNewWelcome, setHasNewWelcome] = useState(true);
  const [hasScrolled, setHasScrolled] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [isCookieVisible, setIsCookieVisible] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Initialize with initial conversation welcoming message and options
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: 'welcome-1',
          role: 'model',
          text: 'Hello! Welcome to FBSPL Support services.',
          timestamp: new Date(),
        }
      ]);
    }
  }, []);

  // Monitor window scroll status to trigger the welcome preview popup ONLY after scrolling down
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 150) {
        setHasScrolled(true);
      }
    };
    
    // Check initial scroll position immediately
    if (window.scrollY > 150) {
      setHasScrolled(true);
    }

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Listen to custom CookieConsent visibility events to avoid any overlapping
  useEffect(() => {
    const handleCookieVisibility = (e: Event) => {
      const customEvent = e as CustomEvent<{ visible: boolean }>;
      setIsCookieVisible(!!customEvent?.detail?.visible);
    };

    window.addEventListener('fbspl_cookie_visible', handleCookieVisibility);
    return () => {
      window.removeEventListener('fbspl_cookie_visible', handleCookieVisibility);
    };
  }, []);

  // Scroll to bottom of chat history when new message received
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputValue).trim();
    if (!text) return;

    if (!textToSend) {
      setInputValue('');
    }
    
    setApiError(null);

    // Add user message to history
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: text,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      // Map history for the API payload
      const chatHistory = messages.map(m => ({
        role: m.role,
        text: m.text
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: text,
          history: chatHistory,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Server error (${res.status})`);
      }

      const data = await res.json();
      
      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'model',
        text: data.reply,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, aiMsg]);
    } catch (err: any) {
      console.error('AIChatBot fetch error:', err);
      setApiError(err.message || 'Could not connect to the AI Assistant. Please see if the server environment is fully live.');
    } finally {
      setIsLoading(false);
    }
  };

  const parseMessageText = (text: string) => {
    if (!text) return '';
    // Format simple bold elements (**bold**) and double returns for paragraphs
    const paragraphs = text.split('\n\n');
    return paragraphs.map((para, pIdx) => {
      const parts = para.split(/(\*\*.*?\*\*)/g);
      return (
        <p key={pIdx} className="mb-2 last:mb-0 leading-relaxed text-xs">
          {parts.map((part, partIdx) => {
            if (part.startsWith('**') && part.endsWith('**')) {
              return <strong key={partIdx} className="font-bold text-slate-950">{part.slice(2, -2)}</strong>;
            }
            // Simple inline bullet point formatting
            if (part.trim().startsWith('* ')) {
              return <span key={partIdx} className="block pl-4 relative my-1 text-slate-700"><span className="absolute left-0 text-[#001A7D]">•</span> {part.slice(2)}</span>;
            }
            return part;
          })}
        </p>
      );
    });
  };

  return (
    <div 
      className={`fixed right-4 sm:right-6 z-40 flex flex-col items-end transition-all duration-500 ease-in-out ${
        isCookieVisible 
          ? 'bottom-[130px] lg:bottom-[80px]' 
          : 'bottom-4 sm:bottom-6'
      }`}
    >
      
      {/* COLLAPSED MESSAGE NOTIFICATION POPUP ABOVE THE BUTTON (EXCISE FOCUS STATE) */}
      <AnimatePresence>
        {!isOpen && hasNewWelcome && hasScrolled && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="mb-3 max-w-[250px] px-4 py-3 bg-white text-slate-800 rounded-2xl shadow-[0_6px_25px_rgba(0,18,90,0.12)] border border-slate-100 flex flex-col gap-1 text-left relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 right-0 h-1 bg-[#001A7D]" />
            <button
              onClick={(e) => {
                e.stopPropagation();
                setHasNewWelcome(false);
              }}
              className="absolute top-1.5 right-1.5 text-slate-400 hover:text-slate-600 transition-colors p-0.5 rounded-full hover:bg-slate-50 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="flex h-2.5 w-2.5 rounded-full bg-brand-cyan animate-pulse"></span>
              <span className="text-[10px] font-black uppercase tracking-wider text-[#001A7D]">FBSPL Support</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-600 font-medium">
              Welcome! Discover bespoke solutions or instantly schedule free business consultations.
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CHAT CONTAINER BOX */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            className="w-[calc(100vw-2rem)] sm:w-[380px] h-[520px] bg-white rounded-3xl shadow-[0_20px_55px_rgba(0,18,90,0.18)] border border-slate-100 flex flex-col overflow-hidden mb-4 mr-0"
          >
            {/* Header segment with corporate theme colors - Refined & Highly Professional */}
            <div className="bg-[#00104E] text-white px-5 py-4.5 flex items-center justify-between shadow-md shrink-0 border-b border-white/5 relative">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-brand-cyan via-[#002CCE] to-[#F29001]" />
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center border border-white/10 text-white shadow-inner">
                  <Sparkles className="w-4.5 h-4.5 text-brand-cyan animate-pulse" />
                </div>
                <div>
                  <h4 className="font-extrabold text-xs tracking-wider uppercase flex items-center gap-1">
                    <span>FBSPL virtual assistant</span>
                  </h4>
                  <div className="flex items-center gap-1.5 text-[9px] text-white/70">
                    <span className="relative flex h-1.5 w-1.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                    </span>
                    <span>Ready in English</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-white/70 hover:text-white transition-all bg-white/10 hover:bg-white/15 p-1.5 rounded-full cursor-pointer hover:scale-105 active:scale-95"
                aria-label="Minimize Chat"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            {/* MESSAGE SCROLL CONTAINER */}
            <div className="flex-1 overflow-y-auto p-4 bg-slate-50/50 space-y-4">
              {messages.map((msg, idx) => (
                <div key={msg.id || idx} className={`flex items-start gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.role === 'model' && (
                    <div className="w-8 h-8 rounded-xl bg-[#001A7D] text-white flex items-center justify-center shrink-0 shadow-sm border border-[#001A7D]/10">
                      <Bot className="w-4.5 h-4.5" />
                    </div>
                  )}
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 shadow-[0_2px_8px_rgba(0,18,90,0.04)] text-left ${
                    msg.role === 'user' 
                      ? 'bg-[#001A7D] text-white rounded-tr-none font-medium' 
                      : 'bg-white text-slate-800 rounded-tl-none border border-slate-100'
                  }`}>
                    {parseMessageText(msg.text)}
                    
                    {/* Render action options immediately with the first welcomed block */}
                    {msg.id === 'welcome-1' && (
                      <div className="mt-4 pt-4 border-t border-slate-100 space-y-2">
                        <button
                          onClick={() => {
                            onBookConsultation();
                            setIsOpen(false);
                          }}
                          className="w-full flex items-center justify-between bg-[#F29001] text-white hover:bg-[#ff9c0d] py-2.5 px-4 rounded-xl text-[11px] font-black tracking-widest transition-all duration-300 transform active:scale-95 cursor-pointer uppercase shadow-sm shadow-[#F29001]/10"
                        >
                          <span className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5" /> Book a Consultation
                          </span>
                          <span>→</span>
                        </button>
                        <button
                          onClick={() => {
                            onViewServices();
                            setIsOpen(false);
                          }}
                          className="w-full flex items-center justify-between bg-slate-100 hover:bg-[#00104E]/5 text-slate-700 hover:text-[#00104E] border border-slate-200 py-2.5 px-4 rounded-xl text-[11px] font-extrabold tracking-widest transition-all duration-300 transform active:scale-95 cursor-pointer uppercase"
                        >
                          <span className="flex items-center gap-1.5">
                            <BookOpen className="w-3.5 h-3.5" /> View Our Services
                          </span>
                          <span>→</span>
                        </button>
                      </div>
                    )}

                    <span className={`block text-[8px] mt-1.5 text-right ${msg.role === 'user' ? 'text-white/60' : 'text-slate-400'}`}>
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex items-start gap-2.5 justify-start">
                  <div className="w-8 h-8 rounded-xl bg-[#001A7D]/10 text-[#001A7D] flex items-center justify-center shrink-0">
                    <Bot className="w-4.5 h-4.5 animate-bounce" />
                  </div>
                  <div className="bg-white text-slate-400 rounded-2xl rounded-tl-none border border-slate-100 px-4 py-3 shadow-sm text-left flex items-center gap-1">
                    <span className="w-2.5 h-2.5 bg-slate-350 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2.5 h-2.5 bg-slate-350 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2.5 h-2.5 bg-slate-350 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}

              {apiError && (
                <div className="flex items-start gap-1.5 p-3.5 rounded-xl bg-rose-50 text-rose-700 border border-rose-100 text-[11px] leading-relaxed">
                  <AlertCircle className="w-4.5 h-4.5 shrink-0 text-rose-500 mt-0.5" />
                  <div>
                    <span className="font-extrabold block">Assistant Offline</span>
                    {apiError}
                  </div>
                </div>
              )}
              
              <div ref={chatEndRef} />
            </div>

            {/* PRE-DEFINED SMART SUGGESTION PILLS ABOVE INPUT */}
            <div className="bg-white border-t border-slate-50 pt-2 shrink-0">
              <div className="flex gap-2 overflow-x-auto px-4 pb-2.5 pt-0.5 scrollbar-none scroll-smooth">
                {[
                  { label: "Services", query: "What core outsourcing services, agency optimization workflows, and custom AI Automation solutions does FBSPL offer?" },
                  { label: "Careers", query: "What professional roles is FBSPL hiring for, how do I apply, and what is your workspace culture like?" },
                  { label: "About Us", query: "Who is FBSPL? Tell me about your 18-year corporate history, leadership team, and global location presence." }
                ].map((pill, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setInputValue(pill.query);
                      handleSendMessage(pill.query);
                    }}
                    className="text-[10px] font-extrabold bg-slate-100/75 hover:bg-[#001A7D] hover:text-white text-[#001A7D] border border-[#001A7D]/10 py-1.5 px-3 rounded-full whitespace-nowrap cursor-pointer transition-all duration-350 shrink-0 transform active:scale-95"
                  >
                    {pill.label}
                  </button>
                ))}
              </div>
            </div>

            {/* INPUT FORM FIELD ZONE */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="p-3.5 border-t border-slate-100 bg-white flex items-center gap-2 shrink-0"
            >
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Type your message about our services..."
                disabled={isLoading}
                className="flex-1 bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-slate-800 text-xs py-3 px-4 rounded-full border border-slate-200 focus:border-[#001A7D] focus:outline-none transition-all duration-200 placeholder:text-slate-400"
              />
              <button
                type="submit"
                disabled={!inputValue.trim() || isLoading}
                className="w-10 h-10 rounded-full bg-[#001A7D] hover:bg-[#F29001] disabled:bg-slate-100 text-white disabled:text-slate-400 flex items-center justify-center transition-all duration-300 cursor-pointer shrink-0 disabled:cursor-not-allowed shadow-md shadow-blue-900/10 hover:shadow-lg disabled:shadow-none"
                aria-label="Send Message"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FLOATING COLLAPSED ACTION BUTTON */}
      <button
        onClick={() => {
          setIsOpen(!isOpen);
          setHasNewWelcome(false);
        }}
        // Clean professional hover states: transitions its border on hover seamlessly (border-slate-100/0 hover:border-[#F2994A])
        className="group relative flex items-center justify-center w-14 h-14 bg-gradient-to-tr from-[#001A7D] to-[#002CCE] hover:from-[#002CCE] hover:to-[#001A7D] text-white rounded-full shadow-[0_8px_30px_rgba(0,18,90,0.22)] border-2 border-transparent hover:border-[#F29001] scale-100 hover:scale-110 active:scale-95 transition-all duration-300 cursor-pointer z-50 overflow-visible"
        title="Ask FBSPL AI Support"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close-icon"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              className="absolute"
            >
              <X className="w-6 h-6" />
            </motion.div>
          ) : (
            <motion.div
              key="chat-icon"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              className="absolute"
            >
              <MessageSquare className="w-6 h-6 animate-pulse" />
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Aggressive Wave Radar / Pulsing Halo Rings when chat is closed */}
        {!isOpen && (
          <div className="absolute inset-0 -z-20 flex items-center justify-center pointer-events-none scale-100">
            <span className="absolute w-16 h-16 rounded-full bg-[#F29001]/60 animate-ping" style={{ animationDuration: '1s' }} />
            <span className="absolute w-20 h-20 rounded-full bg-[#002CCE]/40 animate-ping" style={{ animationDuration: '1.6s', animationDelay: '0.3s' }} />
            <span className="absolute w-24 h-24 rounded-full bg-[#001D9D]/20 animate-ping" style={{ animationDuration: '2.2s', animationDelay: '0.6s' }} />
          </div>
        )}

        {/* Glow halo */}
        <div className="absolute inset-0 rounded-full bg-[#002CCE]/15 group-hover:scale-125 transition-transform duration-500 -z-10 animate-ping opacity-60 pointer-events-none" />
      </button>

    </div>
  );
}
