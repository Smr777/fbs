import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, Building2, User, Globe, MessageSquare, ArrowRight, CheckCircle2 } from 'lucide-react';
import InteractiveEarth from './InteractiveEarth';

export default function ContactUs() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    service: '',
    phone: '',
    country: '',
    state: '',
    source: '',
    requirement: '',
    smsOptIn: false
  });

  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const servicesOption = [
    "Insurance Outsourcing",
    "Accounting & Financial Consultancy",
    "Data Annotation",
    "Business Intelligence",
    "Digital Marketing",
    "AI Automation Services"
  ];

  const sourceOption = [
    "LinkedIn",
    "Facebook",
    "Twitter",
    "Instagram",
    "YouTube",
    "Google Search",
    "Referral / Word of mouth",
    "Other"
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // Field audits
    if (!formData.name || !formData.email || !formData.company || !formData.service || !formData.phone) {
      setErrorMsg('Please populate all required fields (*)');
      return;
    }

    setIsSubmitting(true);

    // Simulate reliable submitting delay
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 1200);
  };

  return (
    <section className="relative py-24 bg-white dark:bg-[#001A7D] overflow-hidden" id="contact-form-section">
      {/* Dynamic Background visual ornaments */}
      <div className="absolute right-0 top-0 w-96 h-96 bg-brand-cyan/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute left-0 bottom-0 w-96 h-96 bg-brand-blue/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Text Box: Business Funnel Values & Interactive Rotatable 3D Earth */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28 text-left pb-20">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#002CCE]/10 text-[#002CCE] text-xs font-bold uppercase tracking-widest">
                <span className="flex h-2 w-2 rounded-full bg-[#F29001] animate-pulse"></span>
                Consultation & Strategy
              </div>
              
              <h2 className="text-3xl sm:text-4xl font-extrabold text-midnight-blue dark:text-white tracking-tight leading-tight uppercase">
                Speak With Our Operational Architects
              </h2>
              
              <p className="text-sm sm:text-base text-black-text dark:text-gray-300 leading-relaxed font-normal">
                Ready to optimize your processes, integrate scalable AI automation, or augment your workforce? Connect with our senior solution leaders for a customized feasibility assessment and ROI blueprint.
              </p>
            </div>

            {/* INTERACTIVE ROTATABLE 3D EARTH MODEL */}
            <div className="pt-2">
              <InteractiveEarth />
            </div>

            <div className="hidden lg:block pt-4 border-t border-gray-150/80 dark:border-gray-800">
              <p className="text-[11px] text-gray-450 dark:text-gray-400 font-medium">
                Our secure data facilities operate standard ISO 27001/9001 certified physical & virtual network checkpoints.
              </p>
            </div>
          </div>

          {/* Right Box: Double Column Interactive Form */}
          <div className="lg:col-span-7 bg-gray-50/50 dark:bg-gray-850 p-6 sm:p-10 rounded-2xl border border-gray-200/60 dark:border-gray-800 shadow-xl">
            <AnimatePresence mode="wait">
              {!submitted ? (
                <motion.form 
                  key="form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onSubmit={handleSubmit} 
                  className="space-y-6 text-left"
                >
                  {errorMsg && (
                    <div className="p-3 bg-red-50 dark:bg-red-950/40 text-red-605 text-xs rounded-lg border border-red-200 uppercase tracking-wide font-semibold text-center">
                      {errorMsg}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Name */}
                    <div className="space-y-1.5">
                      <label htmlFor="contact-name" className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
                        Name <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                          type="text"
                          id="contact-name"
                          name="name"
                          required
                          value={formData.name}
                          onChange={handleInputChange}
                          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-[#001A7D] border border-gray-200 dark:border-white/10 rounded-lg text-sm text-gray-905 dark:text-gray-50 focus:outline-none focus:ring-2 focus:ring-brand-blue/25 focus:border-brand-blue transition"
                          placeholder="John Doe"
                        />
                      </div>
                    </div>

                    {/* Email */}
                    <div className="space-y-1.5">
                      <label htmlFor="contact-email" className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                          type="email"
                          id="contact-email"
                          name="email"
                          required
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-[#001A7D] border border-gray-200 dark:border-white/10 rounded-lg text-sm text-gray-905 dark:text-gray-50 focus:outline-none focus:ring-2 focus:ring-brand-blue/25 focus:border-brand-blue transition"
                          placeholder="johndoe@company.com"
                        />
                      </div>
                    </div>

                    {/* Company */}
                    <div className="space-y-1.5">
                      <label htmlFor="contact-company" className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
                        Company Name <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Building2 className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                          type="text"
                          id="contact-company"
                          name="company"
                          required
                          value={formData.company}
                          onChange={handleInputChange}
                          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-[#001A7D] border border-gray-200 dark:border-white/10 rounded-lg text-sm text-gray-905 dark:text-gray-50 focus:outline-none focus:ring-2 focus:ring-brand-blue/25 focus:border-brand-blue transition"
                          placeholder="Acme Corp"
                        />
                      </div>
                    </div>

                    {/* Phone */}
                    <div className="space-y-1.5">
                      <label htmlFor="contact-phone" className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
                        Phone <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                          type="tel"
                          id="contact-phone"
                          name="phone"
                          required
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-[#001A7D] border border-gray-200 dark:border-white/10 rounded-lg text-sm text-gray-905 dark:text-gray-50 focus:outline-none focus:ring-2 focus:ring-brand-blue/25 focus:border-brand-blue transition"
                          placeholder="+1 (555) 012-3456"
                        />
                      </div>
                    </div>

                    {/* Services Dropdown */}
                    <div className="space-y-1.5">
                      <label htmlFor="contact-service" className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
                        Services <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="contact-service"
                        name="service"
                        required
                        value={formData.service}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2.5 bg-white dark:bg-[#001A7D] border border-gray-200 dark:border-white/10 rounded-lg text-sm text-gray-905 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-brand-blue/25 focus:border-brand-blue transition"
                      >
                        <option value="">-- Choose Service --</option>
                        {servicesOption.map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>

                    {/* Where did you find us Dropdown */}
                    <div className="space-y-1.5">
                      <label htmlFor="contact-source" className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
                        Where did you find us?
                      </label>
                      <select
                        id="contact-source"
                        name="source"
                        value={formData.source}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2.5 bg-white dark:bg-[#001A7D] border border-gray-200 dark:border-white/10 rounded-lg text-sm text-gray-905 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-brand-blue/25 focus:border-brand-blue transition"
                      >
                        <option value="">-- Choose Option --</option>
                        {sourceOption.map(src => (
                          <option key={src} value={src}>{src}</option>
                        ))}
                      </select>
                    </div>

                    {/* Country */}
                    <div className="space-y-1.5">
                      <label htmlFor="contact-country" className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
                        Country
                      </label>
                      <div className="relative">
                        <Globe className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                          type="text"
                          id="contact-country"
                          name="country"
                          value={formData.country}
                          onChange={handleInputChange}
                          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-[#001A7D] border border-gray-200 road-lg border-gray-200 dark:border-white/10 rounded-lg text-sm text-gray-905 dark:text-gray-50 focus:outline-none focus:ring-2 focus:ring-brand-blue/25 focus:border-brand-blue transition"
                          placeholder="United States"
                        />
                      </div>
                    </div>

                    {/* State */}
                    <div className="space-y-1.5">
                      <label htmlFor="contact-state" className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
                        State
                      </label>
                      <input
                        type="text"
                        id="contact-state"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2.5 bg-white dark:bg-[#001A7D] border border-gray-200 dark:border-white/10 rounded-lg text-sm text-gray-905 dark:text-gray-50 focus:outline-none focus:ring-2 focus:ring-brand-blue/25 focus:border-brand-blue transition"
                        placeholder="California"
                      />
                    </div>
                  </div>

                  {/* Brief Requirement */}
                  <div className="space-y-1.5 col-span-2">
                    <label htmlFor="contact-requirement" className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
                      Brief requirement
                    </label>
                    <div className="relative">
                      <MessageSquare className="absolute left-3.5 top-3 w-4 h-4 text-gray-400" />
                      <textarea
                        id="contact-requirement"
                        name="requirement"
                        rows={4}
                        value={formData.requirement}
                        onChange={handleInputChange}
                        className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-[#001A7D] border border-gray-200 dark:border-white/10 rounded-lg text-sm text-gray-905 dark:text-gray-50 focus:outline-none focus:ring-2 focus:ring-brand-blue/25 focus:border-brand-blue transition"
                        placeholder="Please describe your business needs or operational bottleneck..."
                      />
                    </div>
                  </div>

                  {/* SMS Disclaimer Agreement opt-in */}
                  <div className="p-4 bg-gray-100 dark:bg-[#001A7D]/60 rounded-xl border border-gray-200/50 dark:border-white/10 text-[11px] text-gray-500 leading-relaxed space-y-3">
                    <div className="flex items-start gap-2">
                      <input
                        type="checkbox"
                        id="smsOptIn"
                        name="smsOptIn"
                        checked={formData.smsOptIn}
                        onChange={handleInputChange}
                        className="mt-0.5 h-4 w-4 text-brand-blue rounded border-gray-300 focus:ring-brand-blue transition"
                      />
                      <label htmlFor="smsOptIn" className="cursor-pointer select-none">
                        By opting in for text messages, you agree to receive messages from Fusion Global Business Solution Inc at the number provided. Message frequency varies. Msg & data rates may apply. Reply STOP to unsubscribe. Reply HELP for help. View our Privacy Policy and Terms & Conditions for more information.
                      </label>
                    </div>
                  </div>

                  {/* Submit Button with Dynamic arrow CTA */}
                  <div className="pt-2 text-right">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="group inline-flex items-center gap-2 bg-brand-blue border-2 border-brand-blue hover:bg-carrot-orange hover:border-carrot-orange text-white font-bold text-xs uppercase tracking-widest px-8 py-3 rounded-full transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-103 active:scale-98 disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4.5 h-4.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Inquiring...
                        </>
                      ) : (
                        <>
                          Submit now
                          <div className="w-5 h-5 bg-white group-hover:bg-sandy-brown text-brand-blue group-hover:text-white rounded-full flex items-center justify-center shadow transition-colors duration-300">
                            <ArrowRight className="w-3.5 h-3.5" />
                          </div>
                        </>
                      )}
                    </button>
                  </div>
                </motion.form>
              ) : (
                <motion.div 
                  key="success"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-12 px-6 text-center space-y-6"
                >
                  <div className="w-16 h-16 bg-green-100 dark:bg-green-950/50 text-green-600 rounded-full flex items-center justify-center mx-auto shadow-inner animate-bounce">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                      Thank You, {formData.name}!
                    </h3>
                    <p className="text-sm text-gray-500 max-w-md mx-auto mt-2 leading-relaxed">
                      Your proposal briefing regarding <span className="text-brand-blue font-semibold">{formData.service}</span> was dispatched successfully. Our solutions architects at FBSPL will review your requirements and reach out to you within the specified SLA.
                    </p>
                  </div>

                  <div className="p-4 bg-gray-100 dark:bg-[#001A7D] rounded-xl max-w-xs mx-auto border border-gray-200 dark:border-white/10 text-xs">
                    <div className="text-gray-400 font-medium">Session Inquiry Token</div>
                    <div className="text-base font-extrabold font-mono text-brand-cyan uppercase mt-1 tracking-wider">
                      FBP-{Math.floor(Math.random() * 89999 + 10000)}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        name: '',
                        email: '',
                        company: '',
                        service: '',
                        phone: '',
                        country: '',
                        state: '',
                        source: '',
                        requirement: '',
                        smsOptIn: false
                      });
                    }}
                    className="mt-4 px-6 py-2 bg-transparent hover:bg-carrot-orange border-2 border-brand-blue hover:border-carrot-orange text-brand-blue hover:text-white rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300"
                  >
                    Send Another message
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>
      </div>
    </section>
  );
}
