import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Star, Quote, ArrowUpRight, MessageSquare } from 'lucide-react';
import { TESTIMONIALS } from '../data/websiteContent';

// Visual filler assets imports for testimonials viewport edges and card interiors
// @ts-ignore
import blueSquareImg from '../Images/fillers/blue-square.svg';
// @ts-ignore
import rightArrowsImg from '../Images/fillers/right-arrows.svg';
// @ts-ignore
import squareVectorImg from '../Images/fillers/squarevector.svg';
// @ts-ignore
import triangleBlueImg from '../Images/fillers/triangle-blue1.svg';
// @ts-ignore
import whiteSnakeImg from '../Images/fillers/white-snake-vector.svg';

interface TestimonialsProps {
  onNavigate?: (view: string) => void;
}

export default function Testimonials({ onNavigate }: TestimonialsProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? TESTIMONIALS.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev === TESTIMONIALS.length - 1 ? 0 : prev + 1));
  };

  // Auto-scroll testimonials
  useEffect(() => {
    const timer = setInterval(() => {
      nextSlide();
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="pt-[90px] pb-[50px] mt-0 bg-brand-blue/5 dark:bg-brand-dark/40 overflow-hidden relative" id="testimonials-section">
      {/* Visual background grids & shapes */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-brand-cyan/5 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-brand-blue/5 rounded-full blur-2xl pointer-events-none" />

      {/* Professional structured edge-viewport visual fillers (Ref: Visual Mockups) */}
      <div className="absolute top-[8%] left-[-3%] w-[110px] h-[110px] opacity-[0.24] pointer-events-none select-none z-0 hidden lg:block">
        <img src={blueSquareImg} alt="" width="110" height="110" className="w-full h-full object-contain" loading="lazy" />
      </div>
      <div className="absolute bottom-[6%] right-[-3%] w-[130px] h-[130px] opacity-[0.22] pointer-events-none select-none z-0 hidden lg:block">
        <img src={triangleBlueImg} alt="" width="130" height="130" className="w-full h-full object-contain" loading="lazy" />
      </div>
      <div className="absolute top-[18%] right-[5%] w-[80px] h-[80px] opacity-[0.18] pointer-events-none select-none z-0 hidden lg:block animate-[spin_60s_linear_infinite]">
        <img src={squareVectorImg} alt="" width="80" height="80" className="w-full h-full object-contain text-brand-blue" loading="lazy" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 relative z-10 text-center">
        
        {/* Title Block */}
        <div className="space-y-3 mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold tracking-widest text-[#002CCE] dark:text-[#F29001] uppercase bg-[#002CCE]/10 dark:bg-[#F29001]/10 px-3.5 py-1 rounded-full mb-4">
            <Star className="w-3.5 h-3.5 fill-[#F29001] text-[#F29001] animate-pulse" /> Verified Client Endorsements
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-midnight-blue dark:text-white tracking-tight uppercase">
            What Global Market Leaders Say About FBSPL
          </h2>
          <p className="text-sm sm:text-base text-black-text/80 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Strategic long-term partnerships built on rigorous SLAs, 100% time-zone overlapping desks, and audited operational excellence.
          </p>
        </div>

        {/* Dynamic Card Container */}
        <div className="relative bg-white dark:bg-[#001A7D] rounded-3xl p-6 sm:p-10 md:p-14 shadow-2xl border border-gray-100 dark:border-white/10 text-left max-w-4xl mx-auto flex flex-col justify-between overflow-hidden">
          
          {/* Internal visual filler: Chevron indicators pointing horizontally (Ref: Mockup 2 & 5) */}
          <div className="absolute left-[38%] top-[12%] w-[55px] h-[35px] opacity-[0.16] dark:opacity-[0.25] pointer-events-none text-brand-blue dark:text-brand-cyan hidden sm:block">
            <img src={rightArrowsImg} alt="" width="55" height="35" className="w-full h-full object-contain text-brand-blue dark:text-brand-cyan" loading="lazy" />
          </div>

          {/* Internal visual filler: Zigzag squiggle vector integrated at the base profile backdrop */}
          <div className="absolute left-6 bottom-4 sm:left-14 sm:bottom-6 w-[120px] h-[24px] opacity-[0.14] dark:opacity-[0.25] pointer-events-none text-brand-blue dark:text-brand-cyan">
            <img src={whiteSnakeImg} alt="" width="120" height="24" className="w-full h-full object-contain text-brand-blue dark:text-brand-cyan" loading="lazy" />
          </div>

          {/* Quote icon accent */}
          <div className="absolute right-6 top-6 sm:right-10 sm:top-10 text-brand-blue/10 dark:text-brand-cyan/10 pointer-events-none">
            <Quote className="w-16 h-16 sm:w-24 sm:h-24 stroke-[1.5]" />
          </div>

          <div className="relative z-10 flex-1 flex flex-col justify-between">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="space-y-6 flex-1 flex flex-col justify-between"
              >
                <div>
                  {/* Star Rating */}
                  <div className="flex items-center gap-1 mb-4">
                    {Array.from({ length: TESTIMONIALS[currentIndex].rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 text-[#F29001] fill-[#F29001]" />
                    ))}
                  </div>

                  {/* Review Text */}
                  <blockquote className="text-sm sm:text-base md:text-lg text-gray-800 dark:text-gray-200 leading-relaxed italic font-medium mb-6">
                    "{TESTIMONIALS[currentIndex].text}"
                  </blockquote>
                </div>

                {/* Author & Profile credentials */}
                <div className="flex items-center gap-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-tr from-brand-blue to-brand-cyan rounded-full flex items-center justify-center font-bold text-xs sm:text-sm text-white select-none shrink-0">
                    {TESTIMONIALS[currentIndex].author.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="min-w-0">
                    <cite className="not-italic font-bold text-xs sm:text-sm text-gray-900 dark:text-white block truncate">
                      {TESTIMONIALS[currentIndex].author}
                    </cite>
                    <span className="text-[10px] sm:text-xs text-gray-500 block font-medium truncate">
                      {TESTIMONIALS[currentIndex].position}, <span className="text-brand-blue dark:text-brand-cyan font-semibold">{TESTIMONIALS[currentIndex].company}</span>
                    </span>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Dynamic Footer Controls Row in Standard Document Flow */}
          <div className="mt-8 pt-6 border-t border-gray-100/80 dark:border-gray-800/80 flex flex-row items-center justify-between gap-4 relative z-20">
            {/* Dots Indicator */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              {TESTIMONIALS.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-2.5 rounded-full transition-all duration-300 pointer-events-auto cursor-pointer ${
                    idx === currentIndex 
                      ? 'w-6 sm:w-8 bg-brand-blue dark:bg-brand-cyan' 
                      : 'w-2.5 bg-gray-200 dark:bg-gray-800 hover:bg-gray-300 dark:hover:bg-gray-700'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>

            {/* Nav Controls */}
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                onClick={prevSlide}
                className="p-2 sm:p-2.5 bg-gray-50 hover:bg-gray-100 active:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 dark:active:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-full transition shadow-sm border border-gray-100/50 dark:border-gray-800/50 pointer-events-auto cursor-pointer"
                aria-label="Previous Testimonial"
              >
                <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={nextSlide}
                className="p-2 sm:p-2.5 bg-gray-50 hover:bg-gray-100 active:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 dark:active:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-full transition shadow-sm border border-gray-100/50 dark:border-gray-800/50 pointer-events-auto cursor-pointer"
                aria-label="Next Testimonial"
              >
                <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            </div>
          </div>

        </div>

        {/* CTA Button */}
        {onNavigate && (
          <div className="mt-12 flex justify-center">
            <button
              onClick={() => onNavigate('/insights/testimonials')}
              className="relative inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#001A7D] to-[#002CCE] px-6 py-3 rounded-full shadow-lg hover:shadow-xl hover:scale-103 active:scale-98 transition-all duration-300 group border-2 border-transparent hover:border-[#F29001] cursor-pointer"
              id="testimonials-view-all-cta"
            >
              <MessageSquare className="w-3.5 h-3.5 animate-pulse text-white group-hover:text-[#F29001] transition-colors duration-300" />
              <span className="group-hover:text-[#F29001] transition-colors duration-300">View All Testimonials</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-white group-hover:text-[#F29001] transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>
        )}

      </div>
    </section>
  );
}
