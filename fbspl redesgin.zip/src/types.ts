export interface ServiceSubItem {
  name: string;
  href?: string;
  description?: string;
}

export interface ServiceCategory {
  title: string;
  icon?: string;
  items: ServiceSubItem[];
}

export interface ClientLogo {
  name: string;
  svgPath?: string; // Optional path
  color: string;
  fallbackLogo: string;
}

export interface WhyChooseUsItem {
  id: string;
  title: string;
  description: string;
  iconName: 'support' | 'form' | 'domain' | 'scope';
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  href: string;
}

export interface TestimonialItem {
  id: string;
  text: string;
  author: string;
  position: string;
  company: string;
  rating: number;
}

export interface InsightItem {
  id: string;
  title: string;
  category: string;
  readTime: string;
  date: string;
  snippet: string;
  imageUrl?: string;
}

export interface SubPageConfig {
  id: string;
  label: string;
  parent: 'services' | 'insights' | 'about';
}
