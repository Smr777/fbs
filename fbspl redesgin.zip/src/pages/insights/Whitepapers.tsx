export default function Whitepapers() {
  return null;
}
