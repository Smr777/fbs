export default function IndustryReports() {
  return null;
}
