export default function DataSolutions() {
  return null;
}
