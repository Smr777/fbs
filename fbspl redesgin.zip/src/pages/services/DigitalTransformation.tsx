export default function DigitalTransformation() {
  return null;
}
