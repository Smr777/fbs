export default function GlobalPresence() {
  return null;
}
