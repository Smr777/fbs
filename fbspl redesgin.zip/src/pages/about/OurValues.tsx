export default function OurValues() {
  return null;
}
