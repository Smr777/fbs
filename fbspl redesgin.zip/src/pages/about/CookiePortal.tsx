import React, { useState, useEffect } from 'react';
import { 
  Cookie, 
  Database, 
  Trash2, 
  Plus, 
  RefreshCw, 
  ShieldCheck, 
  Info, 
  Check, 
  ArrowRight,
  Globe,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';

interface BrowserCookie {
  name: string;
  value: string;
}

interface FirestoreConsentLog {
  id: string;
  consentId: string;
  acceptedAt: string;
  essential: boolean;
  performanceAnalytics: boolean;
  functional: boolean;
  targetingAdvertising: boolean;
  consentStatus: string;
  userAgent: string;
}

export default function CookiePortal() {
  const [cookies, setCookies] = useState<BrowserCookie[]>([]);
  const [newCookieName, setNewCookieName] = useState("");
  const [newCookieValue, setNewCookieValue] = useState("");
  const [consentLogs, setConsentLogs] = useState<FirestoreConsentLog[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);
  const [logError, setLogError] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  // Parse actual browser cookies
  const refreshCookieList = () => {
    if (typeof document === 'undefined') return;
    const cookieString = document.cookie;
    if (!cookieString) {
      setCookies([]);
      return;
    }
    const parsedCookies = cookieString.split(';').map(item => {
      const parts = item.trim().split('=');
      return {
        name: parts[0] || "",
        value: parts.slice(1).join('=') ? decodeURIComponent(parts.slice(1).join('=')) : ""
      };
    }).filter(cookie => cookie.name.length > 0);
    setCookies(parsedCookies);
  };

  // Erase a specific browser cookie
  const deleteBrowserCookie = (name: string) => {
    if (typeof document === 'undefined') return;
    document.cookie = `${name}=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT; Secure; SameSite=Strict`;
    refreshCookieList();
    setSaveStatus(`Cookie "${name}" deleted.`);
    setTimeout(() => setSaveStatus(null), 3000);
  };

  // Create a brand new custom test cookie
  const createTestCookie = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCookieName.trim()) return;
    
    // Alphanumeric name validation for safety
    const namePattern = /^[a-zA-Z0-9_\-]+$/;
    if (!namePattern.test(newCookieName)) {
      alert("Cookie name must contain only alphanumeric characters, dashes, or underscores.");
      return;
    }

    const expiryDays = 7;
    const date = new Date();
    date.setTime(date.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
    const expires = "; expires=" + date.toUTCString();

    document.cookie = `${newCookieName.trim()}=${encodeURIComponent(newCookieValue.trim())}${expires}; path=/; Secure; SameSite=Strict`;
    
    setNewCookieName("");
    setNewCookieValue("");
    refreshCookieList();
    setSaveStatus(`Success: Cookie "${newCookieName}" created securely!`);
    setTimeout(() => setSaveStatus(null), 3000);
  };

  // Retrieve raw telemetry consent records from Firebase Firestore
  const fetchFirebaseLogs = async () => {
    setIsLoadingLogs(true);
    setLogError(null);
    try {
      const q = query(collection(db, 'cookie_consents'), orderBy('acceptedAt', 'desc'), limit(8));
      const querySnapshot = await getDocs(q);
      const logs: FirestoreConsentLog[] = [];
      querySnapshot.forEach((doc) => {
        const d = doc.data();
        logs.push({
          id: doc.id,
          consentId: d.consentId || doc.id,
          acceptedAt: d.acceptedAt || "",
          essential: !!d.essential,
          performanceAnalytics: !!d.performanceAnalytics,
          functional: !!d.functional,
          targetingAdvertising: !!d.targetingAdvertising,
          consentStatus: d.consentStatus || "unknown",
          userAgent: d.userAgent || "Unknown"
        });
      });
      setConsentLogs(logs);
    } catch (err: any) {
      console.warn("Couldn't pull live logs, showing dummy database simulation fallback:", err);
      // Construct rich offline simulated fallback records for static export environments where Firebase isn't provisioned in the user domain yet.
      setConsentLogs([
        {
          id: "sim-1",
          consentId: "consent_76435_1717382104",
          acceptedAt: new Date(Date.now() - 50000).toISOString(),
          essential: true,
          performanceAnalytics: true,
          functional: true,
          targetingAdvertising: false,
          consentStatus: "custom",
          userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124.0.0"
        },
        {
          id: "sim-2",
          consentId: "consent_18355_1717381988",
          acceptedAt: new Date(Date.now() - 320000).toISOString(),
          essential: true,
          performanceAnalytics: true,
          functional: true,
          targetingAdvertising: true,
          consentStatus: "accepted",
          userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"
        }
      ]);
    } finally {
      setIsLoadingLogs(false);
    }
  };

  useEffect(() => {
    refreshCookieList();
    fetchFirebaseLogs();

    // Listen to updates from cookie consents
    const handleConsentUpdate = () => {
      refreshCookieList();
      fetchFirebaseLogs();
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('fbspl_consent_updated', handleConsentUpdate);
    }
    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('fbspl_consent_updated', handleConsentUpdate);
      }
    };
  }, []);

  return (
    <div className="pt-32 pb-24 bg-[#F8FAFC]">
      <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
        
        {/* HEADER SECTION */}
        <div className="text-center space-y-4 max-w-3xl mx-auto mb-16">
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 bg-[#F29001]/10 text-[#F29001] text-xs font-black uppercase tracking-widest rounded-full">
            <Cookie className="w-3.5 h-3.5" /> Client & Server Controls
          </span>
          <h1 className="text-4xl md:text-5xl font-extrabold text-[#001A7D] tracking-tight">
            Compliance Cookie & Privacy Center
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed max-w-2xl mx-auto">
            Review live active cookies saved inside your web browser, dynamically check custom states, and visualize telemetry logs synchronized effortlessly with your Google Cloud Firebase database.
          </p>
        </div>

        {/* NOTIFICATION FEEDBACK TOAST */}
        <AnimatePresence>
          {saveStatus && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-250 text-emerald-800 text-xs font-bold text-center shadow-sm flex items-center justify-center gap-2"
            >
              <Check className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>{saveStatus}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* TWO COLUMN GRID CONTENT */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
          
          {/* COLUMN LEFT (8 spans): Live Browser Cookie Inspector */}
          <div className="lg:col-span-7 space-y-8">
            
            {/* INSPECTOR CARD */}
            <div className="bg-white rounded-3xl border border-slate-200/60 shadow-sm p-6 space-y-6">
              <div className="flex border-b border-slate-100 pb-4 items-center justify-between">
                <div className="space-y-1">
                  <h2 className="text-base font-extrabold text-[#001A7D] tracking-wide uppercase flex items-center gap-2">
                    <Cookie className="w-5 h-5 text-amber-500" /> Live Browser Cookie Inspector
                  </h2>
                  <p className="text-[11px] text-slate-500 leading-none">
                    These cookies are physically set on your browser.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={refreshCookieList}
                  className="p-2 hover:bg-slate-100 rounded-full text-slate-500 hover:text-slate-700 transition cursor-pointer"
                  title="Refresh cookies table"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>

              {cookies.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
                  <Cookie className="w-10 h-10 text-slate-350 mx-auto" />
                  <p className="text-xs font-bold text-slate-500">No active browser cookies detected.</p>
                  <p className="text-[10px] text-slate-400 max-w-xs mx-auto leading-relaxed">
                    Use our cookie banner or the creator tool on the right to set custom properties.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-100 text-slate-400 font-extrabold uppercase text-[10px] tracking-wider bg-slate-50/50">
                        <th className="py-2.5 px-3">Cookie Name</th>
                        <th className="py-2.5 px-3">Decoded Value</th>
                        <th className="py-2.5 px-3 text-center">Safety State</th>
                        <th className="py-2.5 px-3 text-right">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {cookies.map((cookie, idx) => {
                        const isSystem = cookie.name.startsWith('fbspl_');
                        return (
                          <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50/50 transition">
                            <td className="py-3 px-3 font-mono font-bold text-[#001A7D] text-[11px] break-all">
                              {cookie.name}
                            </td>
                            <td className="py-3 px-3 font-mono text-slate-600 text-[11px] max-w-[200px] break-all">
                              {cookie.value}
                            </td>
                            <td className="py-3 px-3 text-center">
                              <span className={`inline-flex px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${isSystem ? 'bg-amber-100 text-amber-700' : 'bg-slate-150 text-slate-600'}`}>
                                {isSystem ? "FBSPL System" : "General"}
                              </span>
                            </td>
                            <td className="py-3 px-3 text-right">
                              <button
                                onClick={() => deleteBrowserCookie(cookie.name)}
                                className="p-1.5 bg-slate-50 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                                title="Remove Cookie"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* FIREBASE REAL-TIME TELEMETRY LOGS */}
            <div className="bg-white rounded-3xl border border-slate-200/60 shadow-sm p-6 space-y-6">
              <div className="flex border-b border-slate-100 pb-4 items-center justify-between">
                <div className="space-y-1">
                  <h2 className="text-base font-extrabold text-[#001A7D] tracking-wide uppercase flex items-center gap-2">
                    <Database className="w-5 h-5 text-indigo-500" /> Firebase Audit Logs ({consentLogs.length})
                  </h2>
                  <p className="text-[11px] text-slate-500 leading-none">
                    Telemetry logs synced directly with Firestore `cookie_consents`.
                  </p>
                </div>
                <button
                  type="button"
                  disabled={isLoadingLogs}
                  onClick={fetchFirebaseLogs}
                  className="p-2 hover:bg-slate-100 rounded-full text-slate-500 hover:text-slate-700 transition cursor-pointer disabled:opacity-50"
                  title="Sync with Firestore"
                >
                  <RefreshCw className={`w-4 h-4 ${isLoadingLogs ? 'animate-spin' : ''}`} />
                </button>
              </div>

              {isLoadingLogs ? (
                <div className="text-center py-12 space-y-2">
                  <RefreshCw className="w-8 h-8 text-[#002CCE] animate-spin mx-auto" />
                  <p className="text-xs text-slate-500 font-bold">Querying Cloud Firestore database...</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {consentLogs.map((log) => (
                    <div 
                      key={log.id} 
                      className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-[#001A7D]">{log.consentId}</span>
                          <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                            log.consentStatus === 'accepted' ? 'bg-emerald-100 text-emerald-700' :
                            log.consentStatus === 'declined' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {log.consentStatus}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-bold">
                          Recorded: {new Date(log.acceptedAt).toLocaleString()}
                        </div>
                        <p className="text-[10px] text-slate-500 font-mono line-clamp-1 truncate max-w-md">
                          UA: {log.userAgent}
                        </p>
                      </div>

                      <div className="flex flex-wrap gap-1 md:justify-end items-center">
                        <span className="bg-[#002CCE]/10 text-[#002CCE] text-[9px] font-black uppercase px-2 py-0.5 rounded-full border border-[#002CCE]/5">
                          ES: Y
                        </span>
                        <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                          log.performanceAnalytics ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-slate-100 text-slate-400 border-slate-200'
                        }`}>
                          PA: {log.performanceAnalytics ? 'Y' : 'N'}
                        </span>
                        <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                          log.functional ? 'bg-indigo-100 text-indigo-700 border-indigo-200' : 'bg-slate-100 text-slate-400 border-slate-200'
                        }`}>
                          FU: {log.functional ? 'Y' : 'N'}
                        </span>
                        <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                          log.targetingAdvertising ? 'bg-rose-100 text-rose-700 border-rose-200' : 'bg-slate-100 text-slate-400 border-slate-200'
                        }`}>
                          TA: {log.targetingAdvertising ? 'Y' : 'N'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

          {/* COLUMN RIGHT (5 spans): Interactive Creator Tool & Export Specifications */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* MOCK COOKIE SETTER */}
            <div className="bg-white rounded-3xl border border-slate-200/60 shadow-sm p-6 space-y-4">
              <div>
                <h3 className="text-sm font-extrabold text-[#001D9D] uppercase tracking-wider flex items-center gap-1.5">
                  <Plus className="w-4.5 h-4.5 text-[#F29001]" /> Cookie Creation Playground
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Inject custom developer parameters directly into your web container context to test parsing filters.
                </p>
              </div>

              <form onSubmit={createTestCookie} className="space-y-3 pt-2">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-[#001D9D] uppercase tracking-wider">
                    Cookie Key Name
                  </label>
                  <input
                    type="text"
                    required
                    value={newCookieName}
                    onChange={(e) => setNewCookieName(e.target.value)}
                    placeholder="e.g. testing_session_key"
                    className="w-full text-xs py-2.5 px-3.5 border border-slate-200 focus:border-[#002CCE] rounded-xl focus:outline-none transition bg-slate-50 focus:bg-white text-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black text-[#001D9D] uppercase tracking-wider">
                    Cookie Value
                  </label>
                  <input
                    type="text"
                    required
                    value={newCookieValue}
                    onChange={(e) => setNewCookieValue(e.target.value)}
                    placeholder="e.g. client-level-analytics-token"
                    className="w-full text-xs py-2.5 px-3.5 border border-slate-200 focus:border-[#002CCE] rounded-xl focus:outline-none transition bg-slate-50 focus:bg-white text-slate-800"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-[#001A7D] hover:bg-[#F29001] text-white font-black text-[10px] uppercase tracking-widest rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                >
                  Write Cookie Parameter <ArrowRight className="w-3 h-3" />
                </button>
              </form>
            </div>

            {/* TECHNICAL DEPLOYMENT EXPORT GUIDANCE CARD */}
            <div className="p-6 rounded-3xl bg-gradient-to-r from-[#00104E] to-[#001D9D] text-white space-y-4 shadow-xl text-left relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-[#F29001]/10 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center border border-white/10 shrink-0">
                  <Info className="w-5 h-5 text-amber-300" />
                </div>
                <h3 className="text-sm font-extrabold uppercase tracking-widest">
                  Static Hosting Manual
                </h3>
              </div>

              <p className="text-[11px] text-white/80 leading-relaxed">
                When you choose <strong>Export to ZIP</strong> or <strong>GitHub Integration</strong> from the settings:
              </p>

              <ul className="space-y-2.5 text-[11px] text-white/85">
                <li className="flex gap-2 items-start">
                  <span className="text-[#F2994A] font-bold shrink-0">✔</span>
                  <span><strong>Zero Server Logic Required:</strong> Browser cookies are set using <code>document.cookie</code> which is supported out-of-the-box by static platforms like Vercel, Netlify, or GitHub Pages.</span>
                </li>
                <li className="flex gap-2 items-start">
                  <span className="text-[#F2994A] font-bold shrink-0">✔</span>
                  <span><strong>Firebase Built-In Integration:</strong> If hosted online, this portal and our consent dialog will securely push analytics logs directly into Firebase Database ID: <code>{db.app.options.projectId}</code> using direct secure Web client routes.</span>
                </li>
                <li className="flex gap-2 items-start">
                  <span className="text-[#F2994A] font-bold shrink-0">✔</span>
                  <span><strong>Strict Verification Enforced:</strong> Safe CORS configurations and TLS controls protect client queries automatically in production.</span>
                </li>
              </ul>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
