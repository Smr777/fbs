import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { 
  Building2, 
  ChevronRight, 
  ChevronDown,
  ChevronUp,
  Check,
  ArrowLeft,
  ArrowUpRight, 
  Clock, 
  Network, 
  FileText, 
  CheckSquare, 
  Users2, 
  ShieldCheck, 
  HeartHandshake, 
  MessageSquare,
  Play,
  Award,
  BookOpen,
  Calendar,
  Volume2,
  FileSpreadsheet,
  Zap,
  CheckCircle,
  HelpCircle,
  TrendingUp,
  Briefcase,
  Sparkles,
  Rocket
} from 'lucide-react';

import Header from './components/Header';
import Footer from './components/Footer';
import ContactUs from './components/ContactUs';
import Testimonials from './components/Testimonials';
import CookieConsent from './components/CookieConsent';
import AIChatBot from './components/AIChatBot';
const CareersPage = React.lazy(() => import('./pages/about/Careers'));
const CookiePortal = React.lazy(() => import('./pages/about/CookiePortal'));

// Visual filler assets imports per user request
// @ts-ignore
import phoenixImg from './Images/fillers/phoenix.webp';
// @ts-ignore
import blueSquareImg from './Images/fillers/blue-square.svg';
// @ts-ignore
import rightArrowsImg from './Images/fillers/right-arrows.svg';
// @ts-ignore
import squareVectorImg from './Images/fillers/squarevector.svg';
// @ts-ignore
import triangleBlueImg from './Images/fillers/triangle-blue1.svg';
// @ts-ignore
import whiteSnakeImg from './Images/fillers/white-snake-vector.svg';

import { 
  CLIENT_LOGOS, 
  WHY_CHOOSE_US, 
  SERVICES_SERVICES, 
  SERVICES_MENU,
  BRIEF_INSIGHTS 
} from './data/websiteContent';

import logoAllCare from './Images/client logo/AllCare.svg';
import logoAlternative from './Images/client logo/alternative.svg';
import logoChapman from './Images/client logo/chapman.svg';
import logoCRS from './Images/client logo/CRS.svg';
import logoCHRP from './Images/client logo/chrp.svg';
import logoWG from './Images/client logo/wg.svg';
import fbsplLogo from './Images/Logo.svg';

const CLIENT_SVG_MAP: Record<string, string> = {
  "All Care Consultants, Inc": logoAllCare,
  "Alternative Claim Management": logoAlternative,
  "Chapman Insurance Group": logoChapman,
  "CRS Insurance Brokerage": logoCRS,
  "CHRP": logoCHRP,
  "Western Gold Insurance Agency": logoWG
};

// Custom CountUp Utility for interactive numerical values
function StatNumber({ value, suffix = '', duration = 1.5 }: { value: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number | null = null;
    let animId: number;
    
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const progress = Math.min(elapsed / (duration * 1000), 1);
      
      setCount(Math.floor(progress * value));
      
      if (progress < 1) {
        animId = requestAnimationFrame(animate);
      }
    };
    
    animId = requestAnimationFrame(animate);
    return () => {
      if (animId) {
        cancelAnimationFrame(animId);
      }
    };
  }, [value, duration]);

  return <span>{count}{suffix}</span>;
}

// Interactive infinite sliding and draggable client logo marquee loop
function ClientLogoMarquee() {
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef(0);
  
  // Auto scroll marquee effect
  useEffect(() => {
    if (isDragging) return;
    let animationFrameId: number;
    const updateAutoScroll = () => {
      setDragOffset(prev => prev - 0.75); // moves automatically to the left (smooth classic marquee direction)
      animationFrameId = requestAnimationFrame(updateAutoScroll);
    };
    animationFrameId = requestAnimationFrame(updateAutoScroll);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isDragging]);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    dragStart.current = e.clientX;
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const deltaX = e.clientX - dragStart.current;
    setDragOffset(prev => prev + deltaX);
    dragStart.current = e.clientX;
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    e.currentTarget.releasePointerCapture(e.pointerId);
  };

  const stepWidth = 273; // 241px card width + 32px gap
  const totalWidth = CLIENT_LOGOS.length * stepWidth; // 6 * 273 = 1638px
  const leftLimit = -stepWidth; // -273px

  return (
    <div 
      className="relative w-full h-[165px] overflow-hidden py-2 cursor-grab active:cursor-grabbing select-none"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      style={{ touchAction: 'none' }} // Crucial to prevent default mobile gestures from breaking drag
    >
      <div className="absolute inset-y-0 left-0 w-max h-full flex items-center">
        {CLIENT_LOGOS.map((logo, i) => {
          const val = i * stepWidth + dragOffset;
          // Mathematical modulo logic wrapping to stay inside the range [leftLimit, totalWidth + leftLimit]
          const wrapped = leftLimit + (((val - leftLimit) % totalWidth + totalWidth) % totalWidth);
          return (
            <div 
              key={i} 
              className="absolute bg-white dark:bg-slate-950 rounded-xl overflow-hidden hover:border-brand-blue dark:hover:border-brand-cyan transition duration-300 shadow-md flex items-center justify-center w-[241px] h-[149px] shrink-0 pointer-events-none"
              style={{ 
                left: `${wrapped}px`,
                transform: 'translateZ(0)', // GPU acceleration for high quality rendering
              }}
            >
              <img 
                src={CLIENT_SVG_MAP[logo.name]} 
                alt={logo.name} 
                width="241"
                height="149"
                loading="lazy"
                className="w-full h-full object-fill block" 
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function App() {
  const [currentView, setCurrentView] = useState<string>('home');
  const [isVideoLoaded, setIsVideoLoaded] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'caseStudies' | 'clientStories'>('caseStudies');
  const [activeServiceCategory, setActiveServiceCategory] = useState<number>(0);
  const [isServiceExpanded, setIsServiceExpanded] = useState<boolean>(false);
  const [isMobileCategoryOpen, setIsMobileCategoryOpen] = useState<boolean>(false);
  const [flippedCards, setFlippedCards] = useState<Record<number, boolean>>({});

  useEffect(() => {
    setIsServiceExpanded(false);
  }, [activeServiceCategory]);
  
  // Custom Floating Action / Quick Contact anchor state
  const [floatingActive, setFloatingActive] = useState(false);
  const targetProgressRef = useRef<number>(0);
  const smoothProgressRef = useRef<number>(0);
  const isAnimatingRef = useRef<boolean>(false);
  const [smoothScrollProgress, setSmoothScrollProgress] = useState<number>(0);
  const [indicatorOpacity, setIndicatorOpacity] = useState<number>(1);

  useEffect(() => {
    if (currentView !== 'home') return;

    let animeFrameId: number;
    
    const lerp = () => {
      const current = smoothProgressRef.current;
      const diff = targetProgressRef.current - current;
      const speed = 0.12;
      
      if (Math.abs(diff) < 0.0001) {
        smoothProgressRef.current = targetProgressRef.current;
        setSmoothScrollProgress(targetProgressRef.current);
        isAnimatingRef.current = false;
      } else {
        const next = current + diff * speed;
        smoothProgressRef.current = next;
        setSmoothScrollProgress(next);
        animeFrameId = requestAnimationFrame(lerp);
      }
    };

    const startLerp = () => {
      if (!isAnimatingRef.current) {
        isAnimatingRef.current = true;
        animeFrameId = requestAnimationFrame(lerp);
      }
    };

    const handleScrollProgress = () => {
      const contactSection = document.getElementById('contact-form-section');
      if (!contactSection) return;
      
      const contactTop = contactSection.offsetTop;
      const scrollTop = window.scrollY;
      const viewportHeight = window.innerHeight;
      
      // Stop exactly above contact us form.
      const maxScroll = contactTop - viewportHeight;
      if (maxScroll <= 0) return;
      
      const progress = Math.min(Math.max(scrollTop / maxScroll, 0), 1);
      if (progress !== targetProgressRef.current) {
        targetProgressRef.current = progress;
        startLerp();
      }

      // Gracefully fade out entirely before entering the Contact Us section on the home page
      if (scrollTop > maxScroll) {
        const fadeDistance = 150;
        const excess = scrollTop - maxScroll;
        const opacity = Math.max(0, 1 - (excess / fadeDistance));
        setIndicatorOpacity(prev => {
          if (prev !== opacity) return opacity;
          return prev;
        });
      } else {
        setIndicatorOpacity(prev => {
          if (prev !== 1) return 1;
          return prev;
        });
      }
    };
    
    window.addEventListener('scroll', handleScrollProgress, { passive: true });
    // Trigger on content ready
    const fallbackTimer = setTimeout(handleScrollProgress, 100);
    
    return () => {
      window.removeEventListener('scroll', handleScrollProgress);
      if (animeFrameId) cancelAnimationFrame(animeFrameId);
      clearTimeout(fallbackTimer);
    };
  }, [currentView]);

  const getServiceCategoryIcon = (title: string) => {
    switch (title) {
      case "Insurance Outsourcing":
        return <ShieldCheck className="w-5 h-5" />;
      case "Accounting & Bookkeeping":
      case "Accounting & Financial Consulting":
      case "Accounting & Financial Consultancy":
      case "Business Consulting":
        return <FileSpreadsheet className="w-5 h-5" />;
      case "Data Annotation":
        return <Network className="w-5 h-5" />;
      case "Digital Marketing":
        return <TrendingUp className="w-5 h-5" />;
      case "Data Analytics":
      case "Business Intelligence":
        return <Award className="w-5 h-5" />;
      case "Artificial Intelligence":
      case "AI Automation Services":
        return <Zap className="w-5 h-5" />;
      default:
        return <Briefcase className="w-5 h-5" />;
    }
  };

  // Parallax adjustment configuration
  const [parallaxStrength, setParallaxStrength] = useState<number>(1.0);
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [isDesktop, setIsDesktop] = useState<boolean>(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
      setIsDesktop(window.innerWidth >= 1024);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const htmlEl = document.documentElement;
    htmlEl.removeAttribute('data-theme');
  }, []);

  // Framer Motion Dynamic Parallax Trackers
  const { scrollY } = useScroll();
  const scaleFactor = isMobile ? 0.35 * parallaxStrength : 1.0 * parallaxStrength;

  const bgTranslation = useTransform(scrollY, [0, 800], [0, 150 * scaleFactor]);
  const gridTranslation = useTransform(scrollY, [0, 800], [0, 95 * scaleFactor]);
  const leftColTranslation = useTransform(scrollY, [0, 800], [0, 20 * scaleFactor]);
  
  // Custom micro-parallax translations per user request
  const h1Translation = useTransform(scrollY, [0, 800], [0, -25 * scaleFactor]);
  const card1Translation = useTransform(scrollY, [0, 800], [0, -35 * scaleFactor]);
  const card2Translation = useTransform(scrollY, [0, 800], [0, 25 * scaleFactor]);
  const card3Translation = useTransform(scrollY, [0, 800], [0, -50 * scaleFactor]);
  const card4Translation = useTransform(scrollY, [0, 800], [0, 15 * scaleFactor]);

  // Unique parallax speeds and specialized scroll axes/directions:
  // 1. Global Business Process Outsourcing badge goes RIGHT
  const managementProcessXTranslation = useTransform(scrollY, [0, 800], [0, isMobile ? 0 : 120 * scaleFactor]);

  // 2. AI Co-Pilot Active badge goes DOWN
  const aiCoPilotYTranslation = useTransform(scrollY, [0, 800], [0, 125 * scaleFactor]);

  // 3. SLA Quality Rate badge goes LEFT
  const slaXTranslation = useTransform(scrollY, [0, 800], [0, isMobile ? 0 : -90 * scaleFactor]);

  // 4. 24/7 Active Operations badge goes LEFT on desktop, UP on mobile
  const activeOpsXTranslation = useTransform(scrollY, [0, 800], [0, isMobile ? 0 : -110 * scaleFactor]);
  const activeOpsYTranslation = useTransform(scrollY, [0, 800], [0, -75 * scaleFactor]);

  // Premium multi-layered filler asset scroll transforms
  const rightArrowsYTrans = useTransform(scrollY, [0, 1000], [0, -70 * scaleFactor]);
  const rightArrowsXTrans = useTransform(scrollY, [0, 1000], [0, 35 * scaleFactor]);

  const triangleYTrans1 = useTransform(scrollY, [0, 1000], [0, -110 * scaleFactor]);
  const triangleXTrans1 = useTransform(scrollY, [0, 1000], [0, -25 * scaleFactor]);

  const blueSquareYTrans = useTransform(scrollY, [0, 1000], [0, 125 * scaleFactor]);
  const blueSquareXTrans = useTransform(scrollY, [0, 1000], [0, 45 * scaleFactor]);

  const squareVectorYTrans = useTransform(scrollY, [0, 1200], [0, 75 * scaleFactor]);
  const squareVectorRotate = useTransform(scrollY, [0, 2000], [0, 40]);

  const snakeSquiggleYTrans = useTransform(scrollY, [0, 1500], [0, -80 * scaleFactor]);
  const snakeSquiggleXTrans = useTransform(scrollY, [0, 1500], [0, 20 * scaleFactor]);

  // 5. About Us and Established badges sideways aggressive parallax scroll from middle to left alignment
  const aboutSecRef = useRef<HTMLElement>(null);
  const { scrollYProgress: aboutScrollProgress } = useScroll({
    target: aboutSecRef,
    offset: ["start end", "end start"]
  });

  const aboutUsXTranslation = useTransform(aboutScrollProgress, [0, 0.32], [120 * (isMobile ? 0.7 : 1), 0]);
  const establishedXTranslation = useTransform(aboutScrollProgress, [0, 0.35], [180 * (isMobile ? 0.7 : 1), 0]);

  // 6. Sideways progressive parallax tracking for numbers box cards
  const numbersLeftColXTranslation = useTransform(aboutScrollProgress, [0.02, 0.35], [-90 * (isMobile ? 0.8 : 1), 0]);
  const numbersRightColXTranslation = useTransform(aboutScrollProgress, [0.02, 0.35], [90 * (isMobile ? 0.8 : 1), 0]);

  // Animated background translations for the FBSPL Corporate Showcase section
  const showcaseSecRef = useRef<HTMLElement>(null);
  const { scrollYProgress: showcaseScrollProgress } = useScroll({
    target: showcaseSecRef,
    offset: ["start end", "end start"]
  });
  const showcaseBgTranslation = useTransform(showcaseScrollProgress, [0, 1], [-85 * scaleFactor, 85 * scaleFactor]);
  const showcaseGridTranslation = useTransform(showcaseScrollProgress, [0, 1], [-45 * scaleFactor, 45 * scaleFactor]);

  // Animated downward translation parallax for the Learning & Strategy section
  const learningSecRef = useRef<HTMLElement>(null);
  const { scrollYProgress: learningScrollProgress } = useScroll({
    target: learningSecRef,
    offset: ["start end", "end start"]
  });
  // Top-to-Bottom mapping, starts slightly higher, moves downwards as user scrolls through segment
  const learningYTranslation = useTransform(learningScrollProgress, [0, 1], [-55 * scaleFactor, 55 * scaleFactor]);

  // Monitor scroll height to show/hide bottom floating action button
  useEffect(() => {
    const handleScrollFab = () => {
      if (window.scrollY > 400) {
        setFloatingActive(true);
      } else {
        setFloatingActive(false);
      }
    };
    window.addEventListener('scroll', handleScrollFab);
    return () => window.removeEventListener('scroll', handleScrollFab);
  }, []);

  // Handle SPA Simulated View Change (with smooth scrolling to top)
  const handleNavigation = (view: string) => {
    if (view && view.toLowerCase().includes('faq')) {
      const faqEl = document.getElementById('footer-faqs');
      if (faqEl) {
        faqEl.scrollIntoView({ behavior: 'smooth' });
        return;
      }
    }
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  // Helper to resolve Icons in Why-Choose-Us
  const renderWhyUsIcon = (iconName: string) => {
    switch (iconName) {
      case 'support':
        return <Zap className="w-6 h-6 text-brand-cyan" />;
      case 'form':
        return <FileText className="w-6 h-6 text-brand-cyan" />;
      case 'domain':
        return <ShieldCheck className="w-6 h-6 text-brand-cyan" />;
      case 'scope':
        return <HeartHandshake className="w-6 h-6 text-brand-cyan" />;
      default:
        return <CheckSquare className="w-6 h-6 text-brand-cyan" />;
    }
  };

  return (
    <div className="min-h-screen bg-[var(--bg-page)] text-[var(--text-page)] font-sans transition-colors duration-400 relative">
      
      {/* GLOBAL HEADER */}
      <Header onNavigate={handleNavigation} currentView={currentView} />

      {/* PERSISTENT SCROLL PROGRESS INDICATOR (FLANKING THE RIGHT SIDE) */}
      {currentView === 'home' && (
        <div 
          className="fixed right-3 md:right-8 lg:right-10 top-[105px] bottom-16 w-64 z-[1] hidden sm:flex flex-col items-end pointer-events-none select-none transition-opacity duration-300"
          style={{ opacity: indicatorOpacity }}
        >
          {/* Main vertical track container */}
          <div className="h-full w-full relative">
            {/* Straight background trace line (Blue and high definition) */}
            <svg className="absolute top-0 right-3 h-full w-4 text-[#002CCE]" viewBox="0 0 20 100" preserveAspectRatio="none">
              <defs>
                <filter id="glow-effect" x="-100%" y="-100%" width="300%" height="300%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feColorMatrix type="matrix" values="
                    0 0 0 0 0.95
                    0 0 0 0 0.56
                    0 0 0 0 0.0
                    0 0 0 1.2 0" />
                  <feMerge>
                    <feMergeNode />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
                <linearGradient id="orbit-fill" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#002CCE" />
                  <stop offset="50%" stopColor="#001A7D" />
                  <stop offset="100%" stopColor="#F29001" />
                </linearGradient>
              </defs>

              {/* Blue printed system backing groove */}
              <line 
                x1="10" 
                y1="0" 
                x2="10" 
                y2="100" 
                stroke="#001A7D" 
                strokeWidth="4.5" 
                strokeOpacity="0.08"
                strokeLinecap="round"
              />
              <line 
                x1="10" 
                y1="0" 
                x2="10" 
                y2="100" 
                stroke="#002CCE" 
                strokeWidth="2.5" 
                strokeOpacity="0.15"
                strokeLinecap="round"
              />
              
              {/* Dynamic scroll progress line representing the filled part, glowing intensely */}
              <line 
                x1="10" 
                y1="0" 
                x2="10" 
                y2={`${smoothScrollProgress * 100}`} 
                stroke="url(#orbit-fill)" 
                strokeWidth="3.5" 
                strokeLinecap="round"
                filter="url(#glow-effect)"
              />
              
              {/* Technical interface visual hashes alongside the line */}
              <line x1="2" y1="10" stroke="#002CCE" strokeWidth="1" strokeOpacity="0.4" x2="8" y2="10" />
              <line x1="2" y1="30" stroke="#002CCE" strokeWidth="1" strokeOpacity="0.4" x2="8" y2="30" />
              <line x1="2" y1="50" stroke="#002CCE" strokeWidth="1" strokeOpacity="0.4" x2="8" y2="50" />
              <line x1="2" y1="70" stroke="#002CCE" strokeWidth="1" strokeOpacity="0.4" x2="8" y2="70" />
              <line x1="2" y1="90" stroke="#002CCE" strokeWidth="1" strokeOpacity="0.4" x2="8" y2="90" />

              {/* Glowing checkpoints and anchor indicator nodes with dynamic highlights */}
              <circle cx="10" cy="18" r="3.5" fill={smoothScrollProgress >= 0.18 ? "#F29001" : "#001A7D"} opacity={smoothScrollProgress >= 0.18 ? 1 : 0.4} />
              <circle cx="10" cy="48" r="3.5" fill={smoothScrollProgress >= 0.48 ? "#F29001" : "#002CCE"} opacity={smoothScrollProgress >= 0.48 ? 1 : 0.4} />
              <circle cx="10" cy="76" r="3.5" fill={smoothScrollProgress >= 0.76 ? "#F29001" : "#001A7D"} opacity={smoothScrollProgress >= 0.76 ? 1 : 0.4} />
              <circle cx="10" cy="94" r="3.5" fill={smoothScrollProgress >= 0.94 ? "#002CCE" : "#001A7D"} opacity={smoothScrollProgress >= 0.94 ? 1 : 0.4} />
            </svg>
            
            {/* FLOATING VISION & MISSION PHRASES (Consultancy + AI + People) */}
            {[
              { text: "Strategic Consultancy", progress: 0.18, label: "CONSULTANCY" },
              { text: "Cognitive AI Integration", progress: 0.48, label: "AI" },
              { text: "Empowered Global Talent", progress: 0.76, label: "PEOPLE" },
              { text: "Dual-Shore Synergy", progress: 0.94, label: "SYNTHESIS" }
            ].map((phrase, idx) => {
              const diff = Math.abs(smoothScrollProgress - phrase.progress);
              const isActive = diff < 0.08;
              
              const isEven = idx % 2 === 0;
              const inactiveColor = isEven 
                ? 'text-[#001A7D] dark:text-blue-300' 
                : 'text-[#002CCE] dark:text-blue-200';

              const textColor = isActive 
                ? 'text-[#F29001] font-extrabold text-[13px] md:text-base scale-110 tracking-wide brightness-110 shadow-sm transition-all duration-350' 
                : `${inactiveColor} font-bold text-[11px] md:text-[13px] opacity-80 scale-100 tracking-wide transition-all duration-350`;

              const labelColor = isActive
                ? 'bg-[#F29001]/10 text-[#F29001] border-[#F29001]/30 font-bold text-[10px]'
                : isEven 
                  ? 'bg-[#001A7D]/10 text-[#001A7D]/95 border-[#001A7D]/20 font-bold text-[9px] dark:bg-white/10 dark:text-white dark:border-white/20'
                  : 'bg-[#002CCE]/10 text-[#002CCE]/95 border-[#002CCE]/20 font-bold text-[9px] dark:bg-white/10 dark:text-white dark:border-white/20';

              return (
                <div 
                  key={idx}
                  className="absolute right-12 -translate-y-1/2 flex flex-col items-end text-right transition-all duration-300 pointer-events-none"
                  style={{ top: `${phrase.progress * 100}%` }}
                >
                  <span className={`text-[9px] tracking-widest uppercase border rounded px-1.5 py-0.5 transition-all duration-300 ${labelColor}`}>
                    {phrase.label}
                  </span>
                  <span className={`transition-all duration-300 leading-tight mt-1 whitespace-nowrap ${textColor}`}>
                    {phrase.text}
                  </span>
                </div>
              );
            })}
            
          </div>
        </div>
      )}

      {/* CORE ROUTER SWITCH */}
      <AnimatePresence mode="wait">
        {currentView === 'home' ? (
          <motion.main
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="pt-20 overflow-hidden"
          >
            {/* HER0 / PORTAL HEAD (Parallax Parallax) */}
            <section className="relative min-h-[90vh] flex items-center justify-center bg-gradient-to-br from-[var(--theme-hero-gradient-from)] via-[var(--bg-page)] to-[var(--theme-hero-gradient-to)] py-20 px-4 overflow-hidden select-none">
              
              {/* Dynamic Parallax Depth Layers (Layer 1: Ambient blur dots) */}
              <motion.div style={{ y: bgTranslation }} className="absolute top-20 left-10 w-96 h-96 bg-brand-blue/15 rounded-full blur-3xl opacity-60 pointer-events-none animate-pulse" />
              <motion.div style={{ y: bgTranslation, animationDuration: '6s' }} className="absolute bottom-10 right-10 w-[450px] h-[450px] bg-brand-cyan/15 rounded-full blur-3xl opacity-50 pointer-events-none animate-pulse" />

              {/* Parallax Layer 2: Scrolling wireframe lattice lines */}
              <motion.div style={{ y: gridTranslation }} className="absolute inset-0 bg-grid-pattern opacity-70 pointer-events-none" />

              {/* Layer A: Strategic Brand Watermark (Faint Golden/Blue-accented Phoenix logo) in background (lowest z-axis) */}
              <motion.div 
                style={{ y: bgTranslation, rotate: 6 }}
                className="hidden md:block absolute top-[8%] sm:top-[4%] right-[-10%] sm:right-[-5%] md:right-[2%] lg:right-[4%] w-[290px] sm:w-[550px] md:w-[700px] lg:w-[950px] opacity-[0.16] dark:opacity-[0.22] pointer-events-none z-0 select-none"
              >
                <img 
                  src={phoenixImg} 
                  alt="FBSPL Phoenix Watermark" 
                  width="950"
                  height="950"
                  className="w-full h-full object-contain filter drop-shadow-3xl"
                  referrerPolicy="no-referrer"
                />
              </motion.div>

              {/* === LAYERS & PARALLAX BRAND ASSETS (Ref: Circling Filled Designs) === */}
              {/* Layer B: Parallax Blue Square dot matrix grid (Top Left) */}
              <motion.div 
                style={{ y: blueSquareYTrans, x: blueSquareXTrans }}
                className="absolute top-[12%] left-[4%] w-[90px] h-[90px] opacity-[0.38] dark:opacity-[0.48] pointer-events-none z-0 select-none md:hidden"
              >
                <img src={blueSquareImg} alt="" width="90" height="90" loading="lazy" className="w-full h-full object-contain" />
              </motion.div>

              {/* Layer C: Parallax Triangular Blue Dot Grid (Bottom Left edge) */}
              <motion.div 
                style={{ y: triangleYTrans1, x: triangleXTrans1 }}
                className="absolute bottom-[4%] left-[1%] w-[130px] h-[130px] opacity-[0.32] dark:opacity-[0.42] pointer-events-none z-5 select-none"
              >
                <img src={triangleBlueImg} alt="" width="130" height="130" loading="lazy" className="w-full h-full object-contain" />
              </motion.div>

              {/* Layer F: Snake Squiggle Wave (Transitioning divider border) */}
              <motion.div 
                style={{ y: snakeSquiggleYTrans, x: snakeSquiggleXTrans }}
                className="absolute bottom-[3%] right-[12%] lg:right-[22%] w-[180px] h-[35px] opacity-[0.65] text-brand-blue dark:text-brand-cyan pointer-events-none z-20 select-none"
              >
                <img src={whiteSnakeImg} alt="" width="180" height="35" loading="lazy" className="w-full h-full object-contain text-brand-blue" />
              </motion.div>

              {/* High-fidelity Elegant Compass/Circuit Graphic Rings */}
              <div className="absolute top-[15%] left-[5%] w-[585px] h-[585px] border border-dashed border-midnight-blue/15 rounded-full pointer-events-none z-0 hidden lg:block animate-[spin_100s_linear_infinite]" />
              <div className="absolute top-[17%] left-[7%] w-[545px] h-[545px] border border-midnight-blue/24 rounded-full pointer-events-none z-0 hidden lg:block animate-[spin_180s_linear_reverse_infinite]" />
              <div className="absolute top-[25%] left-[13%] w-[425px] h-[425px] border border-double border-midnight-blue/15 rounded-full pointer-events-none z-0 hidden lg:block animate-[pulse_6s_ease-in-out_infinite]" />

              {/* Parallax Floating Aesthetic Badges representing distinct depth layers with responsive placement */}
              <motion.div 
                style={{ x: slaXTranslation }} 
                className="absolute bottom-[4%] left-[4%] md:left-[10%] lg:bottom-[10%] lg:right-[40%] lg:left-auto lg:translate-x-0 flex items-center gap-2 bg-white/95 backdrop-blur-md border border-[var(--theme-card-border)] py-2.5 px-4 rounded-xl shadow-lg z-25 pointer-events-none text-left"
              >
                <div className="w-6 h-6 rounded-full bg-persian-blue/10 flex items-center justify-center text-persian-blue font-bold text-[10px] font-mono">99%</div>
                <div>
                   <span className="block text-[11px] font-black text-black-text leading-tight">SLA Quality Rate</span>
                </div>
              </motion.div>

              <motion.div 
                style={{ 
                  x: activeOpsXTranslation,
                  y: 0 
                }} 
                className="absolute lg:top-[18%] lg:right-[8%] hidden lg:flex items-center gap-2 bg-white/95 backdrop-blur-md border border-[var(--theme-card-border)] py-2.5 px-4 rounded-xl shadow-lg z-25 pointer-events-none text-left"
              >
                <div className="w-6 h-6 rounded-full bg-midnight-blue/10 flex items-center justify-center text-midnight-blue font-bold text-[10px] font-mono">24/7</div>
                <div>
                  <span className="block text-[11px] font-black text-black-text leading-tight">Active Operations</span>
                </div>
              </motion.div>

              <motion.div 
                style={{ y: aiCoPilotYTranslation }} 
                className="absolute top-[3%] left-1/2 -translate-x-1/2 md:top-[5%] lg:top-[8%] lg:left-[45%] lg:translate-x-0 flex items-center gap-1.5 bg-gradient-to-r from-midnight-blue to-persian-blue text-white py-1 px-3 rounded-full shadow-lg z-25 text-[8px] sm:text-[9px] font-extrabold uppercase tracking-widest cursor-pointer hover:scale-105 active:scale-95 transition-all duration-300 whitespace-nowrap"
                onClick={() => handleNavigation('/services/ai-automation-services')}
                whileHover={{ scale: 1.05 }}
              >
                <motion.span
                  animate={{
                    color: ["#F29001", "#ffffff", "#F29001"]
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="inline-flex items-center"
                >
                  <Sparkles className="w-3 h-3 animate-spin" fill="currentColor" />
                </motion.span>
                <span className="ml-[1.5px]">AI Co-Pilot Active</span>
              </motion.div>

              <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-40 text-left">
                
                {/* Hero Slogan content area */}
                <motion.div 
                  style={{ y: leftColTranslation }}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                  className="space-y-6"
                >
                  <motion.div 
                    style={{ x: managementProcessXTranslation }}
                    className="inline-flex items-center gap-1.5 sm:gap-2 px-3.5 py-1.5 bg-midnight-blue/10 rounded-2xl sm:rounded-full text-midnight-blue text-[10px] sm:text-xs font-bold tracking-wider sm:tracking-widest uppercase max-w-full sm:w-max text-left leading-tight"
                  >
                    <span className="relative flex h-2 w-2">
                      <motion.span 
                        className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75"
                        animate={{
                          backgroundColor: ["#002CCE", "#F29001", "#002CCE"]
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />
                      <motion.span 
                        className="relative inline-flex rounded-full h-2 w-2"
                        animate={{
                          backgroundColor: ["#002CCE", "#F29001", "#002CCE"]
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />
                    </span>
                    INTELLIGENT CONSULTANCY & AI AUTOMATION
                  </motion.div>

                  <motion.h1 
                    style={{ y: h1Translation }}
                    className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-midnight-blue leading-[1.12] uppercase"
                  >
                    <span className="block text-midnight-blue">AI-POWERED PRECISION,</span>
                    <span className="block text-persian-blue mt-1 sm:mt-2">HUMAN-LED EXCELLENCE<span className="text-[#F29001]">.</span></span>
                  </motion.h1>

                  <p className="text-base sm:text-lg text-black-text leading-relaxed max-w-xl">
                    We bring together strategic consultancy, intelligent automation, and people who obsess over getting it right. From insight to execution, every layer of your operations is refined, supervised, and built to outperform.
                  </p>

                  <div className="flex flex-wrap gap-4 pt-2">
                    <button
                      onClick={() => {
                        const contactEl = document.getElementById('contact-form-section');
                        if (contactEl) contactEl.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="group inline-flex items-center gap-2 bg-midnight-blue border-2 border-midnight-blue hover:bg-carrot-orange hover:border-carrot-orange text-white px-7 py-3 rounded-full text-xs font-bold uppercase tracking-widest transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-102 cursor-pointer"
                    >
                      Request a Quote
                      <div className="w-5 h-5 bg-white group-hover:bg-sandy-brown rounded-full flex items-center justify-center text-midnight-blue group-hover:text-white transition-colors duration-300">
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </button>
                    <button
                      onClick={() => handleNavigation('/services')}
                      className="group inline-flex items-center gap-2 bg-white border-2 border-midnight-blue hover:border-carrot-orange hover:bg-carrot-orange text-midnight-blue hover:text-white px-7 py-3 rounded-full text-xs font-bold uppercase tracking-widest transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-102 cursor-pointer"
                    >
                      Our Services
                      <div className="w-5 h-5 bg-midnight-blue group-hover:bg-white rounded-full flex items-center justify-center text-white group-hover:text-carrot-orange transition-colors duration-300">
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </button>
                  </div>
                </motion.div>

                {/* Hero Numerical Statistics Cards (Parallax offset animations at different speed rates) */}
                <div className="grid grid-cols-2 gap-4 lg:pl-10 relative">
                  {[
                    { val: 60, suffix: '%', label: 'Reduction in resource overhead', color: 'border-l-4 border-midnight-blue', trans: card1Translation },
                    { val: 25, suffix: '%', label: 'Less turnaround time', color: 'border-l-4 border-persian-blue', trans: card2Translation },
                    { val: 50, suffix: '%', label: 'Increase in overall productivity', color: 'border-l-4 border-navy', trans: card3Translation },
                    { val: 80, suffix: '%', label: 'Better customer satisfaction', color: 'border-l-4 border-persian-blue', trans: card4Translation }
                  ].map((stat, i) => (
                    <motion.div 
                      key={i} 
                      style={{ y: stat.trans }}
                      className={`bg-lavender/90 backdrop-blur-md p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300 ${stat.color} flex flex-col justify-between`}
                    >
                      <div className="text-3xl sm:text-4xl font-extrabold text-midnight-blue">
                        <StatNumber value={stat.val} suffix={stat.suffix} />
                      </div>
                      <div className="text-xs font-semibold text-black-text mt-2 leading-snug">
                        {stat.label}
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Mobile-only 24/7 Operations Badge integrated below numbers */}
                <div className="block lg:hidden mt-8 flex justify-center w-full relative z-25">
                  <motion.div
                    style={{ y: activeOpsYTranslation }}
                    className="flex items-center gap-2 bg-white/95 backdrop-blur-md border border-lavender py-2.5 px-6 rounded-xl shadow-lg pointer-events-none text-left max-w-max"
                  >
                    <div className="w-6 h-6 rounded-full bg-midnight-blue/10 flex items-center justify-center text-midnight-blue font-bold text-[10px] font-mono">24/7</div>
                    <div>
                      <span className="block text-[11px] font-black text-black-text leading-tight">Active Operations</span>
                    </div>
                  </motion.div>
                </div>
                
              </div>
            </section>

            {/* OUR CLIENTS LOGO MARQUEE (Infinite scrolling as original) */}
            <section className="pt-[38px] pb-[38px] bg-lavender border-y-2 border-lavender-alt relative z-10 overflow-hidden">
              <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8">
                <div className="text-center mb-6">
                  <span className="text-xs font-black uppercase tracking-widest text-midnight-blue">
                    Trusted by industry leaders worldwide
                  </span>
                </div>
                
                {/* Continuous loop marquee with custom mathematical wrap-around draggable slider */}
                <ClientLogoMarquee />
              </div>
            </section>

            {/* ABOUT FBSPL (19 Years metrics segment) */}
            <section ref={aboutSecRef} id="about-us-section" className="pt-[64px] pb-[36px] bg-white relative z-10 overflow-hidden">
              {/* Premium edge-viewport visual fillers (Ref: Testimonials/Viewport Edges) */}
              <div className="absolute top-[12%] left-[-4%] w-[90px] h-[90px] opacity-[0.28] pointer-events-none select-none z-0 hidden lg:block animate-[spin_55s_linear_infinite]">
                <img src={squareVectorImg} alt="" width="90" height="90" className="w-full h-full object-contain text-brand-blue" loading="lazy" />
              </div>
              <div className="absolute bottom-[10%] right-[-3%] w-[120px] h-[120px] opacity-[0.24] pointer-events-none select-none z-0 hidden lg:block">
                <img src={triangleBlueImg} alt="" width="120" height="120" className="w-full h-full object-contain" loading="lazy" />
              </div>

              <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8 text-left">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  
                  {/* Left block information */}
                  <div className="lg:col-span-7 space-y-6">
                    <div className="flex flex-col items-start gap-2.5 mb-[24px] overflow-visible">
                      <motion.div 
                        style={{ x: aboutUsXTranslation }}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-persian-blue/10 text-persian-blue text-xs font-bold uppercase tracking-wider whitespace-nowrap"
                      >
                        About Us
                      </motion.div>
                      <motion.div 
                        style={{ x: establishedXTranslation }}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-midnight-blue/10 text-midnight-blue text-xs font-bold uppercase tracking-wider whitespace-nowrap"
                      >
                        Established in 2006
                      </motion.div>
                    </div>
                    
                    <h2 className="text-3xl sm:text-4xl font-extrabold text-midnight-blue tracking-tight block leading-[1.2]">
                      Architecting Global Operational Resilience Through AI-Driven Precision and Human Mastery
                    </h2>

                    <p className="text-base text-black-text leading-relaxed">
                      Since 2006, Fusion Business Solutions (FBSPL) has stood as the strategic consulting and BPM partner trusted by international market leaders. Specializing in Insurance BPO, Accounting & Financial Consultancy, Computer Vision Data Annotation, Business Intelligence, and Enterprise AI Automation — our certified specialists blend cutting-edge cognitive automation with meticulous human oversight to deliver operations that achieve 99.8% precision adherence.
                    </p>

                    {/* Learn More about us CTA button */}
                    <div className="pt-2 flex">
                      <button
                        onClick={() => handleNavigation('/about/who-we-are')}
                        className="relative inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#001A7D] to-[#002CCE] px-6 py-3 rounded-full shadow-lg hover:shadow-xl hover:scale-103 active:scale-98 transition-all duration-300 group border-2 border-transparent hover:border-[#F29001] cursor-pointer"
                        id="about-section-view-more-cta"
                      >
                        <span className="group-hover:text-[#F29001] transition-colors duration-300">More About FBSPL</span>
                        <ArrowUpRight className="w-3.5 h-3.5 text-white group-hover:text-[#F29001] transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </button>
                    </div>

                    {/* Quick video preview layout placeholder with play trigger */}
                    <div className="p-4 bg-lavender rounded-2xl flex items-center gap-4 border border-lavender-alt mt-4">
                      <div className="w-12 h-12 bg-midnight-blue hover:bg-carrot-orange text-white border-2 border-midnight-blue hover:border-carrot-orange rounded-full flex items-center justify-center shrink-0 shadow-lg cursor-pointer hover:scale-110 active:scale-95 transition-all duration-300 group"
                           onClick={() => {
                             const videoEl = document.getElementById('about-video-container');
                             if (videoEl) videoEl.scrollIntoView({ behavior: 'smooth' });
                           }}
                      >
                        <Play className="w-5 h-5 fill-current ml-0.5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-midnight-blue">Watch Our Corporate Reel</h4>
                        <p className="text-xs text-black-text/70">Discover our dual-shore operations models on stage (Vimeo Embedded).</p>
                      </div>
                    </div>
                  </div>

                  {/* Right block metrics */}
                  <div className="lg:col-span-5 grid grid-cols-2 gap-4 overflow-visible">
                    {[
                      { val: 19, suffix: '', label: 'Years of Experience' },
                      { val: 550, suffix: '+', label: 'Served clients' },
                      { val: 1050, suffix: '+', label: 'Employees worldwide' },
                      { val: 6, suffix: '', label: 'Countries served' }
                    ].map((m, i) => (
                      <motion.div 
                        key={i} 
                        style={{ x: i % 2 === 0 ? numbersLeftColXTranslation : numbersRightColXTranslation }}
                        className="bg-lavender p-6 rounded-2xl border-2 border-lavender-alt text-center relative overflow-hidden group hover:shadow-xl transition-all duration-300"
                      >
                        {/* Responsive two-sided brand-blue edge highlights on hover */}
                        <div className="absolute top-0 left-0 w-1.5 h-full bg-persian-blue scale-y-0 group-hover:scale-y-100 transition-transform duration-300 origin-top pointer-events-none" />
                        <div className="absolute top-0 right-0 w-1.5 h-full bg-persian-blue scale-y-0 group-hover:scale-y-100 transition-transform duration-300 origin-bottom pointer-events-none" />
                        
                        <div className="text-3xl sm:text-4xl font-extrabold text-midnight-blue">
                          <StatNumber value={m.val} suffix={m.suffix} />
                        </div>
                        <div className="text-xs font-bold text-black-text mt-2 uppercase tracking-wider">
                          {m.label}
                        </div>
                      </motion.div>
                    ))}
                  </div>

                </div>
              </div>
            </section>

            {/* CINEMATIC RECENT VIDEO segment (with high-fidelity animated parallax background matching the hero section) */}
            <section ref={showcaseSecRef} className="relative pt-[22px] pb-[60px] bg-lavender/30 overflow-hidden z-10 border-b-2 border-lavender" id="about-video-container">
              
              {/* Dynamic Parallax Depth Layers (Layer 1: Ambient blur dots) */}
              <motion.div style={{ y: showcaseBgTranslation }} className="absolute -top-10 -left-20 w-80 h-80 bg-midnight-blue/15 rounded-full blur-3xl opacity-60 pointer-events-none animate-pulse" />
              <motion.div style={{ y: showcaseBgTranslation, animationDuration: '7s' }} className="absolute -bottom-20 -right-20 w-[350px] h-[350px] bg-persian-blue/15 rounded-full blur-3xl opacity-50 pointer-events-none animate-pulse" />

              {/* Parallax Layer 2: Scrolling wireframe lattice lines */}
              <motion.div style={{ y: showcaseGridTranslation }} className="absolute inset-0 bg-grid-pattern opacity-60 pointer-events-none" />

              {/* High-fidelity Elegant Compass/Circuit Graphic Rings */}
              <div className="absolute top-[5%] left-[2%] w-[485px] h-[485px] border border-dashed border-midnight-blue/15 rounded-full pointer-events-none z-0 hidden lg:block animate-[spin_120s_linear_infinite]" />
              <div className="absolute top-[7%] left-[4%] w-[445px] h-[445px] border border-midnight-blue/20 rounded-full pointer-events-none z-0 hidden lg:block animate-[spin_200s_linear_reverse_infinite]" />
              <div className="absolute bottom-[5%] right-[2%] w-[385px] h-[385px] border border-double border-midnight-blue/15 rounded-full pointer-events-none z-0 hidden lg:block animate-[pulse_8s_ease-in-out_infinite]" />

              <div className="relative z-10 max-w-[1550px] mx-auto px-4 md:px-6 lg:px-8">
                <div className="text-center space-y-3 mb-10 flex flex-col items-center">
                  <h3 className="inline-flex items-center justify-center flex-wrap gap-2 text-2xl sm:text-3xl font-extrabold text-midnight-blue tracking-tight">
                    <img src={fbsplLogo} alt="FBSPL" width="135" height="34" className="h-[34px] w-auto inline-block object-contain" />
                    <span>Corporate Showcase</span>
                  </h3>
                  <p className="text-xs text-black-text max-w-lg mx-auto leading-relaxed">
                    Watch why we are recognized as a pioneer in digital workplace transitions and business logic outsourcing.
                  </p>
                </div>
                
                {/* Vimeo Live Embedded Player - ID 961113555 representing high quality core presentation */}
                <div className="w-full rounded-2xl overflow-hidden shadow-2xl border-4 border-white bg-black">
                   <div className="relative aspect-video w-full">
                    {isVideoLoaded ? (
                      <iframe 
                        src="https://player.vimeo.com/video/961113555?autoplay=1&title=0&byline=0&portrait=0" 
                        title="FBSPL Corporate Presentation Video"
                        className="absolute inset-0 w-full h-full border-0"
                        allow="autoplay; fullscreen; picture-in-picture" 
                        referrerPolicy="no-referrer"
                        id="cinematic-vimeo-player"
                      ></iframe>
                    ) : (
                      <div 
                        onClick={() => setIsVideoLoaded(true)}
                        className="absolute inset-0 w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#00104E] via-[#002CCE] to-[#030285] cursor-pointer group select-none"
                      >
                        {/* High-fidelity visual elements of the corporate brand */}
                        <div className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20 filter blur-sm" style={{ backgroundImage: `url(${phoenixImg})` }} />
                        <div className="absolute inset-0 bg-grid-pattern opacity-40 pointer-events-none" />
                        
                        {/* Animated glowing play button */}
                        <div className="relative w-20 h-20 bg-white hover:bg-carrot-orange rounded-full flex items-center justify-center text-[#002CCE] hover:text-white transition-all duration-300 shadow-2xl group-hover:scale-110 z-10">
                          <Play className="w-8 h-8 fill-currentColor ml-1" />
                          <div className="absolute inset-x-0 inset-y-0 w-20 h-20 rounded-full border border-white opacity-40 animate-ping" />
                        </div>
                        
                        <div className="mt-6 text-center z-10 px-4">
                          <span className="block text-[10px] uppercase font-bold tracking-[0.2em] text-[#F29001]">
                            Click to Stream Corporate Showcase
                          </span>
                          <span className="block text-white text-sm sm:text-base font-extrabold mt-1 tracking-tight">
                            FBSPL Corporate Presentation Video
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>


              </div>
            </section>

            {/* SERVICES IN HIGH FIDELITY SERVICES PANEL */}
            <section className="pt-24 pb-[62px] bg-lavender/50 relative z-10 overflow-hidden" id="services-grid-section">
              {/* Premium edge-viewport visual fillers (Ref: Testimonials/Viewport Edges) */}
              <div className="absolute top-[8%] right-[-3%] w-[110px] h-[110px] opacity-[0.22] pointer-events-none select-none z-0 hidden lg:block">
                <img src={blueSquareImg} alt="" className="w-full h-full object-contain" loading="lazy" />
              </div>
              <div className="absolute bottom-[8%] left-[-2%] w-[160px] h-[32px] opacity-[0.3] text-brand-blue pointer-events-none select-none z-0 hidden lg:block">
                <img src={whiteSnakeImg} alt="" className="w-full h-full object-contain text-brand-blue" loading="lazy" />
              </div>

              <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8 text-left">
                
                {/* Header */}
                <div className="space-y-4 mb-16 text-center max-w-2xl mx-auto">
                  <span className="inline-block mb-5 text-xs font-bold uppercase tracking-widest text-[#002CCE] bg-[#002CCE]/10 px-3.5 py-1 rounded-full">
                    Specialized Solutions & Capabilities
                  </span>
                  <h2 className="text-3xl sm:text-4xl font-extrabold text-midnight-blue tracking-tight uppercase">
                    Our Core Business Services
                  </h2>
                  <p className="text-sm sm:text-base text-black-text leading-relaxed">
                    Scale your enterprise with domain-certified talent, standard operating procedures, and automated workflows engineered to deliver up to 60% operational savings.
                  </p>
                </div>

                {/* Main Interactive Category & Services Area */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                  
                  {/* Left Column / Top Row: Category sub-headings / Tabs */}
                  <div className="lg:col-span-4 space-y-3">
                    <div className="hidden lg:flex flex-col gap-2 p-2 bg-white/80 backdrop-blur-md rounded-2xl border-2 border-lavender">
                      <div className="mx-1 my-1 px-3.5 py-3 bg-[#002CCE]/10 border-l-[4px] border-[#002CCE] rounded-lg text-left">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-[#002CCE] animate-pulse shrink-0" />
                          <span className="text-xs sm:text-sm font-black uppercase text-[#002CCE] tracking-wider block">
                            SERVICE CATEGORIES
                          </span>
                        </div>
                      </div>
                      {SERVICES_MENU.map((category, idx) => {
                        const isActive = activeServiceCategory === idx;
                        return (
                          <button
                            key={category.title}
                            onClick={() => setActiveServiceCategory(idx)}
                            className={`w-full flex items-center gap-3.5 px-4 py-4 rounded-xl text-xs font-bold transition duration-305 text-left cursor-pointer ${
                              isActive
                                ? 'bg-midnight-blue text-white shadow-lg'
                                : 'text-black-text hover:text-midnight-blue hover:bg-lavender/50'
                            }`}
                          >
                            <div className={`p-1.5 rounded-lg shrink-0 ${isActive ? 'bg-white/10 text-white' : 'bg-lavender text-midnight-blue'}`}>
                              {getServiceCategoryIcon(category.title)}
                            </div>
                            <span className="truncate">{category.title}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Mobile Custom Premium Selection Menu (Toggles open dynamically) */}
                    <div className="lg:hidden w-full space-y-3">
                      <div className="mx-1 px-3.5 py-3 bg-[#002CCE]/10 border-l-[4px] border-[#002CCE] rounded-lg text-left">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-[#002CCE] animate-pulse shrink-0" />
                          <span className="text-xs sm:text-sm font-black uppercase text-[#002CCE] tracking-wider block">
                            SELECT BUSINESS CATEGORY
                          </span>
                        </div>
                      </div>

                      {/* Main Trigger Button */}
                      <button
                        onClick={() => setIsMobileCategoryOpen(!isMobileCategoryOpen)}
                        className="w-full flex items-center justify-between gap-3 px-4 py-4 rounded-2xl bg-white border-2 border-lavender shadow-md hover:shadow-lg transition duration-300"
                        id="mobile-services-menu-trigger"
                      >
                        <div className="flex items-center gap-3 text-left">
                          <div className="p-2 rounded-xl bg-midnight-blue/10 text-midnight-blue flex items-center justify-center shrink-0">
                            {getServiceCategoryIcon(SERVICES_MENU[activeServiceCategory].title)}
                          </div>
                          <div>
                            <span className="text-[10px] text-black-text/60 block font-medium leading-none mb-1">Active Category</span>
                            <span className="text-xs font-extrabold text-midnight-blue leading-tight">
                              {SERVICES_MENU[activeServiceCategory].title}
                            </span>
                          </div>
                        </div>
                        <motion.div
                          animate={{ rotate: isMobileCategoryOpen ? 180 : 0 }}
                          transition={{ duration: 0.25 }}
                          className="text-midnight-blue"
                        >
                          <ChevronDown className="w-4 h-4" />
                        </motion.div>
                      </button>

                      {/* Animated Dropdown Menu Items */}
                      <AnimatePresence>
                        {isMobileCategoryOpen && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.2, ease: "easeInOut" }}
                            className="overflow-hidden border-2 border-lavender rounded-2xl bg-white shadow-xl"
                          >
                            <div className="p-2 space-y-1 max-h-[350px] overflow-y-auto">
                              {SERVICES_MENU.map((category, idx) => {
                                const isActive = activeServiceCategory === idx;
                                return (
                                  <button
                                    key={category.title}
                                    onClick={() => {
                                      setActiveServiceCategory(idx);
                                      setIsMobileCategoryOpen(false);
                                    }}
                                    className={`w-full flex items-center justify-between gap-3 px-3.5 py-3 rounded-xl text-left transition duration-200 ${
                                      isActive
                                        ? 'bg-[#002CCE] text-white font-bold shadow-sm'
                                        : 'text-black-text hover:bg-lavender/50'
                                    }`}
                                  >
                                    <div className="flex items-center gap-3">
                                      <div className={`p-1.5 rounded-lg shrink-0 ${
                                        isActive 
                                          ? 'bg-white/20 text-white' 
                                          : 'bg-lavender text-midnight-blue'
                                      }`}>
                                        {getServiceCategoryIcon(category.title)}
                                      </div>
                                      <span className="text-xs font-bold leading-none">{category.title}</span>
                                    </div>
                                    
                                    {isActive && (
                                      <motion.div
                                        initial={{ scale: 0.8, opacity: 0 }}
                                        animate={{ scale: 1, opacity: 1 }}
                                        className="bg-white text-midnight-blue p-0.5 rounded-full shrink-0"
                                      >
                                        <Check className="w-3 h-3" strokeWidth={3} />
                                      </motion.div>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>

                  {/* Right Column: Grid displaying all the services inside the active category */}
                  <div className="lg:col-span-8">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={activeServiceCategory}
                        initial={{ opacity: 0, x: 15 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -15 }}
                        transition={{ duration: 0.3 }}
                        className="grid grid-cols-1 md:grid-cols-2 gap-6"
                      >
                        {(isServiceExpanded 
                          ? SERVICES_MENU[activeServiceCategory].items 
                          : SERVICES_MENU[activeServiceCategory].items.slice(0, 4)
                        ).map((sub, sIdx) => (
                          <div
                            key={sIdx}
                            className="bg-white rounded-2xl p-6 shadow-sm border-2 border-lavender hover:border-persian-blue hover:shadow-xl hover:-translate-y-1 transition duration-300 flex flex-col justify-between text-left group"
                          >
                            <div className="space-y-3.5">
                              <div className="flex items-center justify-between">
                                <div className="w-10 h-10 bg-midnight-blue/10 text-midnight-blue rounded-lg flex items-center justify-center font-black text-sm uppercase">
                                  {sub.name.slice(0, 2)}
                                </div>
                                <span className="text-[10px] font-bold text-black-text/60 uppercase tracking-widest bg-lavender px-2 py-0.5 rounded">
                                  Service {sIdx + 1}
                                </span>
                              </div>
                              <h3 className="text-base font-extrabold text-midnight-blue group-hover:text-persian-blue transition-colors leading-snug">
                                {sub.name}
                              </h3>
                              <p className="text-xs text-black-text leading-relaxed min-h-[36px]">
                                {sub.description || "Streamline your business core processes using custom integrations."}
                              </p>
                            </div>

                            <div className="pt-5 border-t border-lavender mt-5 flex items-center justify-between">
                              <button
                                onClick={() => handleNavigation(`/services/${sub.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`)}
                                className="inline-flex items-center gap-1 text-xs font-bold text-persian-blue group-hover:text-carrot-orange hover:underline group-hover:translate-x-1 transition-all"
                              >
                                Read details
                                <ChevronRight className="w-4 h-4 text-persian-blue group-hover:text-carrot-orange transition-colors" />
                              </button>
                            </div>
                          </div>
                        ))}

                        {/* Centered View More Button for Sub-Services greater than 4 */}
                        {SERVICES_MENU[activeServiceCategory].items.length > 4 && (
                          <div className="col-span-1 md:col-span-2 flex justify-center pt-6 pb-2">
                            <motion.button
                              whileHover={{ scale: 1.04, translateY: -2 }}
                              whileTap={{ scale: 0.98 }}
                              onClick={() => setIsServiceExpanded(!isServiceExpanded)}
                              className="group relative cursor-pointer px-8 py-3.5 rounded-xl font-bold text-xs tracking-wider uppercase bg-[#002CCE] text-white hover:bg-midnight-blue transition-all duration-300 shadow-md hover:shadow-xl flex items-center justify-center gap-2.5 overflow-hidden border border-[#002CCE]"
                            >
                              {/* Sliding decorative hover layer */}
                              <span className="absolute inset-x-0 bottom-0 h-0 w-full bg-midnight-blue group-hover:h-full transition-all duration-300 ease-out z-0" />
                              
                              <span className="relative z-10 flex items-center gap-2">
                                {isServiceExpanded ? (
                                  <>
                                    <span>Show Fewer Services</span>
                                    <ChevronUp className="w-4 h-4 text-white" />
                                  </>
                                ) : (
                                  <>
                                    <span>View More Services ({SERVICES_MENU[activeServiceCategory].items.length - 4} More)</span>
                                    <ChevronDown className="w-4 h-4 text-white animate-bounce" />
                                  </>
                                )}
                              </span>
                            </motion.button>
                          </div>
                        )}
                      </motion.div>
                    </AnimatePresence>
                  </div>
                </div>

              </div>
            </section>

            {/* WHY CHOOSE US CARDS (MNC-Standard Core Values and Addressed Business Challenges) */}
            <section className="py-[64px] mt-[18px] bg-white relative z-10 overflow-hidden">
              <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8 text-center">
                
                {/* Header info */}
                <div className="space-y-4 mb-20 text-center max-w-3xl mx-auto">
                  <span className="inline-block mb-5 text-xs font-bold uppercase tracking-widest text-[#002CCE] bg-midnight-blue/10 px-3.5 py-1 rounded-full">
                    Our Core Values
                  </span>
                  <h2 className="inline-flex items-center justify-center flex-wrap gap-2.5 text-3xl sm:text-4xl font-extrabold text-midnight-blue tracking-tight w-full">
                    <span className="pt-[10px]">Why Choose</span>
                    <img src={fbsplLogo} alt="FBSPL" width="190" height="48" className="h-[48px] pt-[10px] w-auto inline-block object-contain" loading="lazy" />
                    <span className="pt-[10px] h-[50px]">?</span>
                  </h2>
                  <p className="text-sm text-black-text">
                    We build resilient operational partnerships. Click or tap any card to explore the specific business headwinds we help mitigate.
                  </p>
                </div>

                {/* Interactive Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {[
                    {
                      id: "accounting",
                      stat: "82%",
                      valueTitle: "AI & Human Collaboration",
                      valueDesc: "A powerful synthesis of modern automation tools and specialized human oversight designed to optimize back-office speed and accuracy.",
                      challengeTitle: "Financial & Cash Flow Risks",
                      challengeDesc: "Data shows 82% of growing enterprises struggle with cash flow visibility and delayed financial reporting cycles.",
                      mitigationDesc: "Our coordinated human-in-the-loop workflows accelerate accounts receivables and maintain rigorous ledger tracking.",
                      pillar: "AI + Human Growth",
                      accentColor: "#001A7D",
                      themeClass: "from-[#001A7D]/10 via-[#001A7D]/5 to-transparent",
                      badgeText: "INTELLIGENT SCALING",
                      iconName: "support"
                    },
                    {
                      id: "insurance",
                      stat: "61%",
                      valueTitle: "Tailored Delivery & Timezone Sync",
                      valueDesc: "Operational resources configured specifically for your workflows and synchronized with your local business hours for real-time collaboration.",
                      challengeTitle: "Insurance Admin Constraints",
                      challengeDesc: "Studies indicate 61% of marketers and agents in Insurance identify lead generation and administrative overload as primary challenges.",
                      mitigationDesc: "By offloading structural back-office tasks, we free up key underwriters to focus on premium volume growth.",
                      pillar: "Your Way, Your Timezone",
                      accentColor: "#002CCE",
                      themeClass: "from-[#002CCE]/10 via-[#002CCE]/5 to-transparent",
                      badgeText: "CUSTOMIZED TEAMS",
                      iconName: "form"
                    },
                    {
                      id: "support",
                      stat: "70%",
                      valueTitle: "Multi-Tiered Service Continuity",
                      valueDesc: "Uninterrupted operation security supported by dedicated redundant backup personnel, guaranteeing seamless customer experience delivery.",
                      challengeTitle: "Journey Vulnerabilities",
                      challengeDesc: "70% of clients decide journey outcomes based on perceived brand care, making 24/7 responsiveness critical for retention.",
                      mitigationDesc: "Our proactive client desk teams provide direct, high-empathy customer journeys with zero drop-offs.",
                      pillar: "All-In-One Support",
                      accentColor: "#F29001",
                      themeClass: "from-[#F29001]/10 via-[#F29001]/5 to-transparent",
                      badgeText: "CONTINENTAL SLA",
                      iconName: "domain"
                    },
                    {
                      id: "marketing",
                      stat: "90%",
                      valueTitle: "Client-First Strategic Alignment",
                      valueDesc: "We act as an organic extension of your team, proactively tracking your macro growth and local performance milestones.",
                      challengeTitle: "Prestige & Authority Gaps",
                      challengeDesc: "90% of modern consumers rely extensively on local digital reviews before choosing their operational partners.",
                      mitigationDesc: "We engineer customized brand authority campaigns and search optimization workflows to elevate online conversion rates.",
                      pillar: "Client First, Always",
                      accentColor: "#001A7D",
                      themeClass: "from-[#001A7D]/10 via-[#001A7D]/5 to-transparent",
                      badgeText: "ENTERPRISE SYNERGY",
                      iconName: "scope"
                    }
                  ].map((card, idx) => {
                    const isFlipped = !!flippedCards[idx];
                    return (
                      <div
                        key={card.id}
                        onClick={() => setFlippedCards(prev => ({ ...prev, [idx]: !prev[idx] }))}
                        className="relative h-[370px] w-full cursor-pointer group [perspective:1200px]"
                        style={{ outline: 'none' }}
                      >
                        <motion.div
                          animate={{ rotateY: isFlipped ? 180 : 0 }}
                          transition={{ duration: 0.6, ease: "easeInOut" }}
                          style={{ transformStyle: "preserve-3d" }}
                          className="relative w-full h-full"
                        >
                          {/* FRONT SIDE (The Value Proposition) */}
                          <div 
                            style={{ 
                              backfaceVisibility: "hidden", 
                              WebkitBackfaceVisibility: "hidden" 
                            }}
                            className={`absolute inset-0 w-full h-full p-7 rounded-2xl border-2 bg-gradient-to-b ${card.themeClass} bg-white border-lavender hover:border-persian-blue flex flex-col justify-between shadow-sm hover:shadow-xl transition-all duration-300 ${
                              isFlipped ? "pointer-events-none" : ""
                            }`}
                          >
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <span 
                                  style={{ color: card.accentColor, backgroundColor: `${card.accentColor}10` }}
                                  className="text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider"
                                >
                                  {card.badgeText}
                                </span>
                                <div className="text-midnight-blue/50 group-hover:text-persian-blue transition-colors">
                                  {renderWhyUsIcon(card.iconName)}
                                </div>
                              </div>
                              
                              <div className="space-y-2 text-left">
                                <h3 className="text-base font-extrabold text-midnight-blue leading-tight">
                                  {card.valueTitle}
                                </h3>
                                <p className="text-xs text-black-text leading-relaxed font-medium">
                                  {card.valueDesc}
                                </p>
                              </div>
                            </div>

                            <div className="pt-4 border-t border-lavender flex items-center justify-between text-xs font-bold text-persian-blue group-hover:text-carrot-orange group-hover:underline">
                              <span>See Addressed Challenge</span>
                              <svg className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                              </svg>
                            </div>
                          </div>

                          {/* BACK SIDE (The Challenge & mitigation) */}
                          <div 
                            style={{ 
                              backfaceVisibility: "hidden", 
                              WebkitBackfaceVisibility: "hidden",
                              transform: "rotateY(180deg)"
                            }}
                            className={`absolute inset-0 w-full h-full p-7 rounded-2xl border-2 bg-gradient-to-br from-[#002CCE] via-[#001A7D] to-[#030285] border-persian-blue/30 text-white flex flex-col justify-between shadow-2xl ${
                              !isFlipped ? "pointer-events-none" : ""
                            }`}
                          >
                            <div className="space-y-4 text-left">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-extrabold uppercase tracking-widest text-white">
                                  {card.pillar}
                                </span>
                              </div>

                              <div className="space-y-1">
                                <div className="text-4xl font-extrabold leading-none text-[#F29001] mb-1">
                                  {card.stat}
                                </div>
                                <h4 className="text-xs font-bold uppercase tracking-wider text-[#F2994A]">
                                  {card.challengeTitle}
                                </h4>
                              </div>

                              <p className="text-[11px] text-white/90 leading-relaxed font-light">
                                {card.challengeDesc}
                              </p>

                              <p className="text-[11px] text-white/95 leading-relaxed border-l-2 border-[#F2994A] pl-2 font-medium">
                                <strong className="font-bold text-white">FBSPL Advantage:</strong> {card.mitigationDesc}
                              </p>
                            </div>

                            <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs font-bold text-white">
                              <span className="group-hover:text-[#F29001] transition-colors duration-300">Tap to Return ↩</span>
                              <span className="text-[10px] bg-[#F29001]/25 text-[#F2994A] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse">
                                {card.stat} IMPACT
                              </span>
                            </div>
                          </div>
                        </motion.div>
                      </div>
                    );
                  })}
                </div>

              </div>
            </section>

            {/* TESTIMONIALS SLIDING segment */}
            <Testimonials onNavigate={handleNavigation} />

            {/* INSIGHTS GRID OVERVIEW */}
            <section ref={learningSecRef} className="py-24 bg-white relative z-10 overflow-hidden">
              <div className="max-w-[1720px] mx-auto px-4 md:px-6 lg:px-8 text-left">
                
                {/* Title and Segmented category controller */}
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
                  <div className="space-y-3">
                    <span className="text-xs font-bold uppercase tracking-widest text-[#002CCE] bg-[#002CCE]/10 px-3.5 py-1 rounded-full inline-block">
                      Thought Leadership & Research
                    </span>
                    <h2 className="text-3xl sm:text-4xl font-extrabold text-midnight-blue tracking-tight uppercase">
                      Insights & Knowledge Hub
                    </h2>
                  </div>
                                   
                  {/* Category switcher tabs */}
                  <div className="flex bg-lavender p-1.5 rounded-full w-max text-xs font-bold select-none border border-lavender-alt">
                    <button
                      onClick={() => setActiveTab('caseStudies')}
                      className={`px-5 py-2.5 rounded-full transition cursor-pointer ${activeTab === 'caseStudies' ? 'bg-midnight-blue text-white shadow-md' : 'text-black-text hover:text-midnight-blue'}`}
                    >
                      Case Studies & Stories
                    </button>
                    <button
                      onClick={() => setActiveTab('clientStories')}
                      className={`px-5 py-2.5 rounded-full transition cursor-pointer ${activeTab === 'clientStories' ? 'bg-midnight-blue text-white shadow-md' : 'text-black-text hover:text-midnight-blue'}`}
                    >
                      Podcasts & Blogs
                    </button>
                  </div>
                </div>

                <AnimatePresence mode="wait">
                  {activeTab === 'caseStudies' ? (
                    <motion.div
                      key="case-grid"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 15 }}
                      className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left"
                      style={{ y: learningYTranslation }}
                    >
                      {/* Interleaved Case Studies & Success Stories: 1-2, 1-2 pattern */}
                      {(() => {
                        const list = [];
                        const len = Math.max(BRIEF_INSIGHTS.caseStudies.length, BRIEF_INSIGHTS.clientStories.length);
                        for (let i = 0; i < len; i++) {
                          if (i < BRIEF_INSIGHTS.caseStudies.length) {
                            list.push({ ...BRIEF_INSIGHTS.caseStudies[i], isCaseStudy: true });
                          }
                          if (i < BRIEF_INSIGHTS.clientStories.length) {
                            list.push({ ...BRIEF_INSIGHTS.clientStories[i], isCaseStudy: false });
                          }
                        }
                        return list.map((item) => (
                          <div 
                            key={item.id}
                            className="bg-white p-6 sm:p-8 rounded-3xl border-2 border-lavender hover:border-persian-blue shadow-md hover:shadow-xl hover:scale-[1.01] transition-all duration-300 h-full flex flex-col justify-between space-y-6"
                          >
                            <div className="space-y-4">
                              <div className="flex items-center gap-2.5">
                                <div className="p-2 bg-midnight-blue/10 text-midnight-blue rounded-xl">
                                  {item.isCaseStudy ? (
                                    <FileText className="w-4 h-4" />
                                  ) : (
                                    <Users2 className="w-4 h-4" />
                                  )}
                                </div>
                                <span className="text-[10px] uppercase font-black tracking-widest text-[#001A7D]">
                                  {item.isCaseStudy ? 'Case Study' : 'Success Story'}
                                </span>
                              </div>
                              
                              <h3 className="text-base sm:text-lg font-extrabold text-midnight-blue leading-snug hover:text-persian-blue transition-colors">
                                {item.title}
                              </h3>
                              <p className="text-xs sm:text-sm text-black-text leading-relaxed font-medium">
                                {item.snippet}
                              </p>
                            </div>

                            <div className="pt-4 border-t border-lavender flex items-center justify-between text-xs text-black-text/60">
                              <span className="flex items-center gap-1 font-medium">
                                <Clock className="w-3.5 h-3.5" /> {item.readTime}
                              </span>
                              <span 
                                onClick={() => handleNavigation(item.isCaseStudy ? `/insights/case-studies` : `/insights/client-stories`)}
                                className="font-bold text-persian-blue hover:text-carrot-orange inline-flex items-center gap-1 hover:underline cursor-pointer transition-colors"
                              >
                                {item.isCaseStudy ? 'Analyze Case' : 'Read Journey'} <ChevronRight className="w-4 h-4" />
                              </span>
                            </div>
                          </div>
                        ));
                      })()}
                    </motion.div>
                  ) : (
                    <motion.div
                      key="multimedia-grid"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 15 }}
                      className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left"
                      style={{ y: learningYTranslation }}
                    >
                      {/* Interleaved Podcasts & Blogs: 1-2, 1-2 pattern */}
                      {(() => {
                        const list = [];
                        const len = Math.max(BRIEF_INSIGHTS.podcasts.length, BRIEF_INSIGHTS.blogs.length);
                        for (let i = 0; i < len; i++) {
                          if (i < BRIEF_INSIGHTS.podcasts.length) {
                            list.push({ ...BRIEF_INSIGHTS.podcasts[i], isPodcast: true });
                          }
                          if (i < BRIEF_INSIGHTS.blogs.length) {
                            list.push({ ...BRIEF_INSIGHTS.blogs[i], isPodcast: false });
                          }
                        }
                        return list.map((item) => (
                          <div 
                            key={item.id}
                            className="bg-white p-6 sm:p-8 rounded-3xl border-2 border-lavender hover:border-persian-blue shadow-md hover:shadow-xl hover:scale-[1.01] transition-all duration-300 h-full flex flex-col justify-between space-y-6"
                          >
                            <div className="space-y-4">
                              <div className="flex items-center gap-2.5">
                                <div className="p-2 rounded-xl bg-persian-blue/10 text-persian-blue">
                                  {item.isPodcast ? (
                                    <Volume2 className="w-4 h-4" />
                                  ) : (
                                    <BookOpen className="w-4 h-4" />
                                  )}
                                </div>
                                <span className="text-[10px] uppercase font-black tracking-widest text-[#002CCE]">
                                  {item.isPodcast ? 'Podcast' : 'Expert Insights'}
                                </span>
                              </div>
                              
                              <h3 className="text-base sm:text-lg font-extrabold text-midnight-blue leading-snug hover:text-persian-blue transition-colors">
                                {item.title}
                              </h3>
                              <p className="text-xs sm:text-sm text-black-text leading-relaxed font-medium">
                                {item.snippet}
                              </p>
                            </div>

                            <div className="pt-4 border-t border-lavender flex items-center justify-between text-xs text-black-text/60">
                              <span className="flex items-center gap-1 font-medium">
                                <Clock className="w-3.5 h-3.5" /> {item.readTime}
                              </span>
                              <span 
                                onClick={() => handleNavigation(item.isPodcast ? `/insights/podcast` : `/insights/blogs`)}
                                className="font-bold text-persian-blue hover:text-carrot-orange inline-flex items-center gap-1 hover:underline cursor-pointer transition-colors"
                              >
                                {item.isPodcast ? 'Listen Now' : 'Read Article'} <ChevronRight className="w-4 h-4" />
                              </span>
                            </div>
                          </div>
                        ));
                      })()}
                    </motion.div>
                  )}
                </AnimatePresence>

              </div>
            </section>

            {/* CONTACT US FORM ON HOMEPAGE */}
            <ContactUs />

          </motion.main>
        ) : currentView === '/careers' || currentView === '/about/careers' ? (
          <React.Suspense fallback={
            <div className="min-h-screen flex flex-col items-center justify-center bg-white">
              <div className="w-12 h-12 border-4 border-[#001A7D] border-t-transparent rounded-full animate-spin"></div>
              <p className="mt-4 text-xs font-bold text-[#001A7D] uppercase tracking-widest animate-pulse">Loading Careers Module...</p>
            </div>
          }>
            <CareersPage />
          </React.Suspense>
        ) : currentView === '/cookie-portal' || currentView === '/about/cookie-portal' ? (
          <React.Suspense fallback={
            <div className="min-h-screen flex flex-col items-center justify-center bg-white">
              <div className="w-12 h-12 border-4 border-[#001A7D] border-t-transparent rounded-full animate-spin"></div>
              <p className="mt-4 text-xs font-bold text-[#001A7D] uppercase tracking-widest animate-pulse">Loading Cookie Portal...</p>
            </div>
          }>
            <CookiePortal />
          </React.Suspense>
        ) : (
          /* BLANK PAGES RENDERER: Direct integration with blank modules in directory */
          <motion.div
            key="blank-view"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="pt-32 pb-24 px-4 max-w-4xl mx-auto text-center space-y-8 min-h-[70vh] flex flex-col justify-center items-center"
          >
            <div className="w-20 h-20 bg-lavender rounded-full flex items-center justify-center text-midnight-blue animate-pulse">
              <Building2 className="w-9 h-9" />
            </div>

            <div className="space-y-3">
              <span className="text-xs font-bold text-persian-blue uppercase tracking-widest">
                FBSPL REDESIGN ROUTE
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#001A7D] tracking-tight">
                Section In Development
              </h2>
              <p className="text-sm text-black-text max-w-lg leading-relaxed">
                The mock view <span className="text-persian-blue font-mono font-bold">"{currentView}"</span> was mapped corresponding to the requested blank subpage hierarchy files. All associated blank files are physically constructed in the directory structure.
              </p>
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => handleNavigation('home')}
                className="group inline-flex items-center gap-2 bg-[#001A7D] text-white font-bold text-xs uppercase tracking-widest px-6 py-2.5 rounded-full border-2 border-[#002CCE] hover:bg-[#F29001] hover:border-[#F29001] transition-all duration-300 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" /> Back to Homepage
              </button>
              <button
                onClick={() => {
                  setCurrentView('home');
                  setTimeout(() => {
                     const contactEl = document.getElementById('contact-form-section');
                     if (contactEl) contactEl.scrollIntoView({ behavior: 'smooth' });
                  }, 100);
                }}
                className="group inline-flex items-center gap-1 bg-white border-2 border-lavender hover:bg-[#F29001] hover:border-[#F2994A] text-midnight-blue hover:text-white font-bold text-xs uppercase tracking-widest px-6 py-2.5 rounded-full transition-all duration-300 shadow-sm hover:shadow-lg cursor-pointer"
              >
                Quick Consultation Request
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FOOTER SECTION: Dynamic Column bindings */}
      <Footer onNavigate={handleNavigation} />

      {/* SECURE AI CHATBOT WITH DYNAMIC HOVER FEEDBACK & SEAMLESS INTERNAL ROUTING */}
      <AIChatBot 
         onBookConsultation={() => {
           setCurrentView('home');
           setTimeout(() => {
             const contactEl = document.getElementById('contact-form-section');
             if (contactEl) contactEl.scrollIntoView({ behavior: 'smooth' });
           }, 150);
         }}
         onViewServices={() => {
           handleNavigation('/services');
         }}
      />

      {/* DYNAMIC SCROLL-SPIED PROFESSIONAL COOKIE POLICY POPUP */}
      <CookieConsent />

    </div>
  );
}
